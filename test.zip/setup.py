"""
This module includes information about the requirements of the needed package and basic
information of the project for the setup.
"""
from setuptools import setup, find_packages
from codecs import open
from os import path


requires = [
    'applicationinsights==0.11.9',
    'numpy==1.17.3',
    'pandas==1.0.1',
    'click==7.0',
    'pyodbc==4.0.27',
    'SQLAlchemy==1.3.10',
    'Flask==1.1.1',
    'attrs==19.3.0',
    'connexion==2.4.0',
    'python-dateutil==2.8.0',
    'typing_extensions==3.7.2',
    'more-itertools==7.2.0',
    'msrestazure==0.6.2',
    'azure-storage-blob==2.1.0',
    'PyYAML==5.4.1',
    'datacompy'
]

tests_requires = [
    'pytest==5.2.2',
    'pytest-cov==2.8.1',
    'pytest-mock==1.11.2',
    'flake8==3.8.4',
    'tox==3.14.0',
    'behave==1.2.6',
    'PyHamcrest==1.9.0',
    'black==19.10b0',
    'Sphinx==2.2.1',
    'sphinx_rtd_theme==0.4.3',
    'alabaster==0.7.12',
    'm2r==0.2.1',
    'isort==4.3.21',
    'mypy==0.770',
]

here = path.abspath(path.dirname(__file__))
# Get the version info and anything else possibly defined in __version__.py
about = {}
with open(path.join(here, 'src', 'scenario_calculator', '__version__.py'),
          'r', 'utf-8') as f:
    exec(f.read(), about)

# Get the long description from the README file
with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name=about['__title__'],
    version=about['__version__'],
    description=about['__description__'],
    long_description=long_description,
    long_description_content_type='text/markdown',
    author=about['__author__'],
    author_email=about['__author_email__'],
    python_requires='>=3.7.5',
    classifiers=[
        'Programming Language :: Python :: 3.7.5',
        'Intended Audience :: Developers',
        'Natural Language :: English',
    ],
    packages=find_packages(
        'src',
        exclude=["*.tests", "*.tests.*", "tests.*", "tests"],
    ),
    package_dir={'': 'src'},
    package_data={'swagger_server/swagger': ['swagger.yaml']},
    include_package_data=True,
    install_requires=requires,
    tests_require=tests_requires,
    entry_points={
        'console_scripts': [
            'scenario-calculator=scenario_calculator.cli:cli',
        ],
    },
)
