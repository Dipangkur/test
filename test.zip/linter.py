# -*- coding: utf-8 -*-
"""
Script for handling pylint

When this script is called directly from tox, it will run Pylint without disabling the
warnings or errors. If the last score is not smaller than the THRESHOLD value, Pylint
will be passed successfully.
"""

import contextlib
import sys
from io import StringIO

from pylint import lint

from _ctypes import ArgumentError

THRESHOLD = 7.4

if len(sys.argv) < 3:
    raise ArgumentError("Arguments needed: Module to evaluate, verbose option (y/n)")

# Get verbose option as second argument and remove before adding other arguments
verbose = (sys.argv[2]).lower() in ["true", "1", "t", "y", "yes", "yeah"]
sys.argv.pop()

# Append extra arguments
sys.argv.append("--output-format=colorized")
sys.argv.append("--msg-template='{msg_id}:{line:3d},{column}: {obj}: {msg}'")
sys.argv.append("--persistent=y")
sys.argv.append("--reports=y")
sys.argv.append("--rcfile=pylintrc")
sys.argv.append("--load-plugins=pylint.extensions.docparams")


@contextlib.contextmanager
def capture():
    """
    Capture stdout
    """
    old_out, old_err = sys.stdout, sys.stderr
    try:
        out_list = [StringIO(), StringIO()]
        sys.stdout, sys.stderr = out_list
        yield out_list
    finally:
        sys.stdout, sys.stderr = old_out, old_err
        out_list[0] = out_list[0].getvalue()
        out_list[1] = out_list[1].getvalue()


# If verbose option is not selected, capture the stdout and run linter silently
if verbose:
    run = lint.Run(sys.argv, do_exit=False)
else:
    with capture() as out:
        run = lint.Run(sys.argv, do_exit=False)

score = run.linter.stats["global_note"]

if score < THRESHOLD:
    sys.exit(1)
