# Summary

This tool is part of MEISTER (i.e. Macro-Economic Indicators & Scenarios for
exTension, Enrichment and Release). The key idea of MEISTER is that one
central system is responsible for the storage and disclosing of forecasted
macroeconomic scenario data. 

This data is essential input for IFRS9 compliant risk calculations. Various
delivering parties upload scenario data to the system. MEISTER processes this
data and stores the original data files. After initial processing, the
application creates a raw scenario and stores the data in a database.
Subsequently, the application retrieves the raw data and applies time series
modelling techniques to project the scenarios into the future. After this
step, data enrichment steps are performed; namely new scenario data is
derived, or simple rules are used to handle missing data. The application
stores the output in a database and disclose data to various parties within
the bank.

Reference: *Enrichment of Macroeconomic Scenarios Methodology* - Plat, Richard.

## Dockerised calculator
Using Docker (Running it as a Dockerised Container App, as a REST-API
server)

With Docker, it is possible to select a Python 3.6 version as a base
for the runtime environment.

The `Dockerfile` and the `.dockerignore` files are the two (most)
relevant files.

You build it as follows:

```sh
docker build .
```

The Dockerfile takes a `http_proxy` and `https_proxy` argument,
which can be used to set the proxy when building the docker
container on a Rabobank machine.

To set these, use (assuming the proxy is
`http://proxy.eu.rabodev.com:8080`):

```sh
docker build \
  --build-arg http_proxy=http://proxy.eu.rabodev.com:8080 \
  --build-arg https_proxy=http://proxy.eu.rabodev.com:8080 \
  .
```

If the `http_proxy` and `https_proxy` environment variables are already
correctly set on your build machine, you can omit the values:

```sh
docker build --build-arg http_proxy --build-arg https_proxy .
```

You run the program in `api-mode` as follows:

```sh
docker run -p80:80 <docker-id-as-reported-back-from-build>
```

The `-p` option specifies the port mapping from outside the container
to exposed port on the inside.

##### Some additional advice for installing on Windows

On Confluence page
[Create a Virtual Machine on Azure - IT Systems - Risk & Finance - Risk Systems -](
https://confluence.dev.rabobank.nl/display/riskfin/Create+a+Virtual+Machine+on+Azure)
you will find some advice on what to install.

Now that we switched to Python-3.7.5 we could not re-install `numpy`.
The following commands in a Command Prompt (`cmd`) window with Administrator
privileges might be of help:

```cmd
choco upgrade vcredist140
choco install vcredist2017
choco install microsoft-visual-cpp-build-tools -y
```

Probably this last command is crucial to get the `numpy` installation problem
solved.


## Test

For `flake8`, `black`, (`pytest` based) unit tests, (`behave` based) component test,
code coverage checks as well as a Python version check, we use `tox`.
 Run `tox` to run these checks.

```sh
tox
```

An additional `--recreate`/`-r` option can be added to clear the cache.

`tox` can create multiple (python version) environments to run the
unit- and component tests. On Windows, the easiest way to install
additional versions of Python, findable by `tox`, is to issue a command like:

```cmd
choco install python --version=3.8.0 -my
``` 

The `-m` option indicates that you want to have multiple versions installed.
The `-y` option indicates that you pre-confirm any questions asked.

Please note this should be done in a cmd window with administrator rights.

### Black
Black is a rigorous Python code style reformatter. The `black` test run from `tox`
verifies whether all code is formatted according to Black's style. If not, the test
simply fails with a diagnostic.

For more information what it does, how to use it, and how to integrate it into your
IDE or Editor, check out https://black.readthedocs.io/en/latest/index.html.

You can safely reformat your code with the following command:
```bash
black src/scenario_calculator tests component_tests
```

Please note that - because of Black's default settings - it is advised to configure
your Editor/IDE to use a max line length of 88 for Python source files.


### Component Test

The component_tests test the calculator.py module and compares Calculated Scenario
with Expected Scenario. The component test is done in Gherkin style language using
the behave framework. The behave framework uses a step directory and a feature file.
For more information checkout the behave website 
https://behave.readthedocs.io/en/latest/index.html 

If, for any reason, one wants to skip the component test, the
following steps are needed:

* In the `tox.ini`, add `behave --tags=-slow` instead of the line `behave` in
the `[testenv]` commands.

Note, to get a more verbose version from the behave framework, one should write in the
tox.ini file the command `behave --verbose` and to get the screen capture one should
write `behave --no-capture`.

You can also set the logging level to filter on: `behave --logging-level=DEBUG`.

#### Test Files
For both component tests and unit tests, same simple naming conventions are followed:

- RawScenario Data files have `dynamic_df` in their names and kept under `dynamic` 
directory.
- Input files contain `input`, expected files to be compared contain `expected` in their 
names.
- Content specific files have the specifying part in their names, e.g. `agriland`, 
`other_country`, `baseline`, `plus`...
- File name mappings are done based on the dictionaries in `Settings`, `TestSettings` 
and `ComTestSettings` classes in related modules.

### Pylint
Pylint is a static code analysis tool which looks for programming errors,
helps enforcing a coding standard, sniffs for code smells and offers simple refactoring
suggestions.

Introducing pylint (for other projects as well) can be quite cumbersome.  The following
approach works rather nicely:

* Let `pylint` use a `pylintrc` file; you could use the one that this project is using,
  which on its turn is based on the `pylintrc` the pylint project itself is using.
* Invoke pylint via using linter.py as follows:
  ```bash
  linter.py src/scenario_calculator y
  ```

In this way linter script will call pylint with verbose option and a success threshold
score (7.4 out of 10 currently). If you want to run pylint silently, change tox.ini as 
follows:
  ```bash
  python linter.py src/scenario_calculator n
  ```
Exceptions: Warnings - 'bad-continuation' and 'invalid-name' are disabled in pylintrc.
'bad-continuation' is reported as a conflict between Flake8 and Pylint; 'invalid-name' 
warning conflicts the naming convetion adopted in the application.    
### Pre-commit

Pre-commit is a tool which is designed to reduce the time spent on the failed static 
code analyses in the CI pipeline. It can be installed via pip, curl, brew or conda. 

After installation it can be activated as follows:

    pre-commit install

The tools defined in `.pre-commit-config.yaml` file will be executed before you are able 
to commit your changes. 

### Version check
A test has been added to tox that checks the "standard" Python interpreter
version against the "required" one, as defined in `runtime.txt`.  When a version
mismatch is detected, it warns in the  development and CI environment, but errors
in the CD environment. 

## How to install and use Jupyter notebooks
To install jupyter notebook use the command:
```bash
# NOTE: make sure you have your virtual environment activated!
pip install jupyter
```
Install the right kernel with the commands:
```bash
pip install ipykernel
ipython kernel install --user --name="$(basename "$VIRTUAL_ENV")"
```
To activate the jupyter notebook write the following commands on the (bash)
command line:
```bash
(cd notebooks && jupyter notebook)
```

### Before you commit a new version of Jupyter notebook.
* Make sure that you have restarted the kernel and cleared the output.
* Subsequently save the notebook.

### Command-line swagger-server generation
The following command will generate the swagger_server code in the project's
`./src` directory, provided your Current Working Directory is the project
root:
```bash
(set -x &&
 mkdir -p "$TMP/swagger-scratch-$$" &&
 cd "$TMP/swagger-scratch-$$" &&
 java -jar .../some/path/to/swagger-codegen-cli.jar \
    generate -i ~-/libdata/scenario_creator.yaml -l python-flask &&
 cp -rp swagger_server ~-/src/. &&
 set +x &&
 echo "consider removing $PWD" >&2)
```
**NOTE:** It will overwrite any modifications you may have done in the generated code.

## Generating Sphinx Documentation from Docstrings

**NOTE:** This requires following packages to be installed:
```
'Sphinx==2.2.0',
'sphinx_rtd_theme==0.4.3',
'alabaster==0.7.12',
'm2r==0.2.1'
```

You can simply call `make html` from `docs` directory to create documentation under `docs/build/html`
```cmd
..\MSR.ScenarioCalculator.Py\docs> make html
```

### What does this `make` script?

- Removes the `docs/build` directory, recreates it again, copies `conf.py` and `index.rst` into it.
- Creates the `.rst` files using `sphinx-apidoc`.
- Creates the `html` output using `sphinx-build`.

Afterwards you can open the `index.html` file created under `/docs/build/html` directory using any browser.

### Manual way of creating the output:
- Create `.rst` files inside `source/_modules` directory using the codes under `src/raw_scenario_calculator` directory:
```cmd
..\MSR.ScenarioCalculator.Py\docs> sphinx-apidoc -o ./source/_modules ../src/raw_scenario_calculator
```

- Create output files (`html` formatted) into `build/html` directory from `.rst` files in `source` directory:
```cmd
..\MSR.ScenarioCalculator.Py\docs> sphinx-build -b html source build
```

### General TODO's by JHB:
* rename `end_year_extension` to `extension_end_year` and rephrase its description
  from "end year of extension" to "extension end year"
* likewise `start_year_extension`

**Note:** check if these field names are not part of an external interface
