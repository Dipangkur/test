Install the following dependencies before running the notebooks:

1. matplotlib
2. xlrd