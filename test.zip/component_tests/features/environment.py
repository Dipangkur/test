"""Define code to run before and after certain events during your Behave-based testing.

From https://behave.readthedocs.io/en/latest/tutorial.html#environmental-controls:

* ``before_step(context, step), after_step(context, step)``
  These run before and after every step.
* ``before_scenario(context, scenario), after_scenario(context, scenario)``
  These run before and after each scenario is run.
* ``before_feature(context, feature), after_feature(context, feature)``
  These run before and after each feature file is exercised.
* ``before_tag(context, tag), after_tag(context, tag)``
  These run before and after a section tagged with the given name. They are invoked
  for each tag encountered in the order they’re found in the feature file.
* ``before_all(context), after_all(context)``
  These run before and after the whole shooting match.

The feature, scenario and step objects represent the information parsed from the
feature file. They have a number of attributes:

* keyword
  “Feature”, “Scenario”, “Given”, etc.
* name
  The name of the step (the text after the keyword.)
* tags
  A list of the tags attached to the section or step. See controlling things with tags.
* filename and line
  The file name (or “<string>”) and line number of the statement.
"""
import logging

from behave.runner import Context

from scenario_calculator.thread_teeing_logging_handler import ThreadTeeingLoggingHandler


def before_all(context: Context) -> None:
    """This is run before any behave based test is run.

    Just following the recipe in
      https://behave.readthedocs.io/en/latest/api.html#logging-setup

    The ThreadTeeingLoggingHandler has been added, so that that particular
    functionality can be tested as well, when the Behave based tests are run
    with the `--no-logcapture` option.

    :param context: containing the configuration
    :return: None
    """
    if not context.config.log_capture:
        context.config.setup_logging()
        formatter = logging.Formatter(
            fmt="%(asctime)s %(name)-12s %(levelname)-8s %(message)s"
        )
        thread_teeing_logging_handler = ThreadTeeingLoggingHandler(level=logging.INFO)
        thread_teeing_logging_handler.setFormatter(formatter)
        root_logger = logging.getLogger()
        root_logger.addHandler(thread_teeing_logging_handler)
