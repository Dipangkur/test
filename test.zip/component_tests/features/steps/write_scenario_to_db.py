import builtins
import logging
import re
from contextlib import closing
from datetime import datetime, date
from itertools import zip_longest
from typing import Optional, Tuple, List, Type

import numpy as np
import pandas as pd
from behave import given, then, runner, use_step_matcher, step
from behave.model import Table
from dateutil.relativedelta import relativedelta
from hamcrest import assert_that, is_, equal_to, all_of
from more_itertools import one

from component_tests.behave_db_model import Base
from component_tests.behave_db_utils import make_test_db_url, DbTableInfo
from component_tests.features.steps.utility_component_tests import (
    _TEST_DB_INPUT_CONVERSION_MAP,
    open_database,
)
from scenario_calculator.io.db_writer import write_output_to_db
from scenario_calculator.io.reader import OneValuedInputData
from scenario_calculator.utility import (
    get_named_tuple_fields,
    parse_iso_ish_date,
    get_observation_type,
    standardize,
)
from scenario_calculator.modelling.enrichment import (
    set_value_and_date_index,
    drop_extra_columns,
)

_MONTHS_IN_QUARTER = 3

_log = logging.getLogger(__name__)


use_step_matcher("re")

_TIMESERIES_ATTR_TYPES = {
    "date": int,
    "source": str,
    "scenario": str,
    "series_code": str,
    "corep_code": str,
    "unit": str,
    "start_year_extension": int,
    "conversion_factor": float,
    "param_beta0": float,
    "param_beta1": float,
    "param_d": float,
    "transformation_type": str,
    "aggregation_type": str,
    "adjustment": str,
    "mapped_to_variable_code": str,
    "mapped_to_corep_code": str,
    "last_obs_date": parse_iso_ish_date,
    "originating_raw_scenario_time_series_id": np.int64,
    "period": str,
}


@given(
    r"that we have a NamedTuple (?P<named_tuple_name>\w+) with"
    r" field names, conversion functions, and values, resp. like"
)
def check_named_tuple_fields(context: runner.Context, named_tuple_name: str) -> None:
    # This module still has to import the respective symbols, but it makes this step
    # quite more flexible
    assert_that(named_tuple_name, is_(equal_to(OneValuedInputData.__qualname__)))
    named_tuple_cls = OneValuedInputData
    nt_attrs_expected = context.table.headings
    assert_that(
        list(get_named_tuple_fields(named_tuple_cls)), is_(equal_to(nt_attrs_expected))
    )
    table_iter = iter(context.table)
    attr_typs_as_strings = tuple(next(table_iter))
    current_globals = globals()
    attr_typs = tuple(
        current_globals.get(typ_str, None) or getattr(builtins, typ_str)
        for typ_str in attr_typs_as_strings
    )
    conv_funcs = tuple(
        _TEST_DB_INPUT_CONVERSION_MAP.get(attr_typ, attr_typ) for attr_typ in attr_typs
    )
    context.named_tuple_inst = named_tuple_cls(
        *(conv_func(value) for conv_func, value in zip(conv_funcs, one(table_iter)))
    )


_NEW_ENTRY_STEP_TEXT = r"we create a new entry in the list of quarterly scenarios"


@step(_NEW_ENTRY_STEP_TEXT)
def new_entry_in_scenario_quarterly_items(context: runner.Context) -> None:
    # Create a list of quarterly scenario items
    context.all_scenarios_quarterly: List = getattr(
        context, "all_scenarios_quarterly", []
    )


@step(r"we add a quarter value in list of quarterly scenarios")
def add_timeseries(context: runner.Context) -> None:
    # Calculate the timeseries dataframe from this behave table;
    # obtain attr names and ts indices
    attr_typ_list, series_index_list = _process_timeseries_table_hdr(context.table)
    # Fetch the single one (data) row
    table_row = list(one(iter(context.table)))
    # Determine the length of the 'regular' timeseries' dataframe
    regular_attrs_len = len(attr_typ_list)
    # And construct the keyword arguments from them
    timeseries_kwargs = {
        attr_name: attr_typ(val_str)
        for attr_name, attr_typ, val_str in zip(
            *zip(*attr_typ_list), table_row[:regular_attrs_len]
        )
    }
    # The remaining columns are the actual (pandas) Series values, where the
    #  column headings are the actual index values (the quarters of the years)
    tseries_values = [float(val_str) for val_str in table_row[regular_attrs_len:]]
    timeseries_kwargs["series"] = pd.Series(tseries_values, series_index_list)
    time_series = pd.DataFrame(timeseries_kwargs)
    # Populate default columns
    series_code = time_series.series_code.iloc[0]
    time_series["variable_code"] = series_code[2:]
    time_series["nigem_code"] = series_code[0:2]
    time_series["param_mu"] = np.math.nan
    time_series["param_sigma"] = np.math.nan
    time_series["mapped_to_variable_code"] = ""
    time_series["mapped_to_corep_code"] = ""
    context.all_scenarios_quarterly.append(time_series)


def _process_timeseries_table_hdr(
    table: Table,
) -> Tuple[List[Tuple[str, Type]], List[datetime]]:
    """Check the headings of the timeseries input step.

    Each header name should either be a:
    * name of an attribute of TimeSeries (except `timeseries`)
    * a shortened name of such an attribute (i.e. the name without the 'param_'-prefix)
    * a quarter in yyyyQd notation

    :param table: The behave model table, containing the header
    :return:
    """
    attr_typ_list = []
    series_index_list = []
    for short_attr_name in table.headings:
        if ("param_" + short_attr_name) in _TIMESERIES_ATTR_TYPES:
            attr_name = "param_" + short_attr_name
        else:
            attr_name = short_attr_name
        typ = _TIMESERIES_ATTR_TYPES.get(attr_name)
        if typ is not None:
            attr_typ_list.append((attr_name, typ))
        else:
            # The attr name is not known; then must be pd.Series index value
            value_date = _perhaps_date_from_yyyyqd(attr_name)
            if value_date is None:
                raise ValueError(
                    f"Unrecognised header {attr_name!r}from timeseries step"
                )
            series_index_list.append(
                datetime(value_date.year, value_date.month, value_date.day)
            )
    return attr_typ_list, series_index_list


def _perhaps_date_from_yyyyqd(yyyyqd_str: str) -> Optional[date]:
    """Match a string against 'yyyyQd' notation, returning date on success, else None

    If the argument is a string in yyyyQd format, convert it to a date containing
    the last day of the indicated quarter.

    If not, return None

    :param yyyyqd_str: the argument, possibly containing a date in yyyyQd format
    :return: the converted date or None
    """
    m = re.match(r"(?P<year_str>\d{4})Q(?P<quarter_digit_str>[1-4])", yyyyqd_str)
    if m:
        year = int(m.group("year_str"))
        quarter = int(m.group("quarter_digit_str"))
        result = date(year, quarter * _MONTHS_IN_QUARTER, 1) + relativedelta(day=31)
        _log.debug("_perhaps_date_from_yyyyqd(%r) -> %r", yyyyqd_str, result)
        return result
    return None


@then(
    r"the writing of the scenario with output batch size (?P<output_batch_size_str>\d+)"
    r" to the database should return scenario id equal to (?P<scenario_id_str>\d+)"
)
def check_scenario_id_from_write(
    context: runner.Context, output_batch_size_str: str, scenario_id_str: str
) -> None:
    context.db_url = make_test_db_url(context.temp_dir, context.database_name)
    expected_scenario_id = int(scenario_id_str)

    # Set value date and values
    all_scenarios_quarterly = set_value_and_date_index(
        context.all_scenarios_quarterly[0]
    )

    # Get observation type
    all_scenarios_quarterly = get_observation_type(all_scenarios_quarterly, 20181231)

    # Drop extra columns
    all_scenarios_quarterly = drop_extra_columns(all_scenarios_quarterly)

    # Standardize the values
    context.all_scenarios_quarterly[0] = standardize(all_scenarios_quarterly)

    actual_scenario_id = write_output_to_db(
        context.db_url,
        int(output_batch_size_str),
        context.all_scenarios_quarterly,
        context.named_tuple_inst,
    )
    assert_that(
        actual_scenario_id,
        is_(equal_to(expected_scenario_id)),
        "checking returned scenario_id",
    )


@then(
    r"the resulting table named (?P<table_name>\w+)"
    r" should exactly have the following rows"
)
def check_db_contents(context: runner.Context, table_name) -> None:
    open_database(context)
    with closing(context.db_session) as session:
        db_table_info = DbTableInfo(
            table_name, context.table, _TEST_DB_INPUT_CONVERSION_MAP
        )
        table_expected_rows_iter = db_table_info.make_db_row_iter_from_behave_table(
            Base
        )
        db_actual_rows_iter = db_table_info.make_contents_row_iter(Base, session)
        assert_that(
            all_of(
                *(
                    assert_that(db_actual_row, is_(equal_to(table_expected_row)))
                    for db_actual_row, table_expected_row in zip_longest(
                        db_actual_rows_iter, table_expected_rows_iter
                    )
                )
            )
        )
