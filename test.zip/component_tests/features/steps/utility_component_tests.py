"""
This module was created to handle all the repeated operation we do in the component test
and all the utility that a component test needs. For instance, setting the input
directory, setting the output directory and so on.
"""
import re
from contextlib import closing
from datetime import datetime, date

import datacompy
import pandas as pd
from pathlib import Path
from tempfile import TemporaryDirectory, NamedTemporaryFile
from typing import List, Optional

import logging

from behave import given, when, runner, use_step_matcher
from more_itertools import one

from component_tests.behave_db_model import Base
from component_tests.behave_db_utils import (
    INPUT_CONVERSION_MAP_TYPE,
    DbTableInfo,
    make_test_db_url,
)
from component_tests.component_tests_settings import ComTestSettings
from scenario_calculator.constants import (
    INPUT_DYNAMIC_DF,
    OUTPUT_DATA_CSV_BASENAME_FMT,
    GBV_PART,
)
from scenario_calculator.db import (
    create_engine_from_connection_string,
    new_session_base_tuple,
)
from scenario_calculator.io.fields import COMPONENT_TEST_OUTPUT_COLUMNS
from scenario_calculator.io.reader import OneValuedInputData
from scenario_calculator.thread_teeing_logging_handler import ThreadTeeingLoggingHandler
from scenario_calculator.utility import (
    make_datetime_filestamp,
    get_named_tuple_fields,
    parse_iso_ish_datetime,
    parse_iso_ish_date,
)

_log = logging.getLogger(__name__)

use_step_matcher("re")

scenario_timeseries_table = "Scenario TimeSeries"
scenario_info_table = "Scenario Info"


def _bool_from_str(bool_val_str: str) -> bool:
    """Create a Python bool instance from a str formatted as a bool representation

    :param bool_val_str: either 'False' or 'True'
    :return: bool instance with the associated value
    """
    if bool_val_str == "False":
        return False
    if bool_val_str == "True":
        return True
    raise ValueError(f"Not a valid bool representation: {bool_val_str!r}")


# The following table maps standard python types into a conversion func
#  mapping a string to a value of the given python type
_TEST_DB_INPUT_CONVERSION_MAP: INPUT_CONVERSION_MAP_TYPE = {
    datetime: parse_iso_ish_datetime,
    date: parse_iso_ish_date,
    bool: _bool_from_str,
}


def full_path_input(full_path: str = "default input") -> str:
    """Convert the full path of the input to a uri form, taking in account the file name
    convention I.csv

    The purpose of the function is to help the tester control which dynamic input file
    one would like to test.
    The function returns a default input full_path_name. However, in case the
    tester wish to pick other directory that can be done in the .feature file by
    changing the expression "default input" in the Given statement to the wanted one.

    :param full_path: str that contains the full_path or else it is set to default one.
    :return: the full path name in a uri form,
    e.g. file:///C:/Users/input_dynamic_df.csv
    """
    if full_path == "default input":
        return Path(
            ComTestSettings.COMPONENT_TEST_DYNAMIC_DATA_DIR / INPUT_DYNAMIC_DF
        ).as_uri()
    else:
        return (Path("./src") / full_path / INPUT_DYNAMIC_DF).as_uri()


def full_path_output(
    current_datetime: datetime, full_path: str = "default output"
) -> str:
    """Convert the full path of the output to a uri form, taking in account the file
    name convention Mes_STIB_GBV_CurrentDate.csv

    The purpose of the function is to help the tester control which output file one
    would like to test.
    The function returns a default output full_path_name. However, in case the
    tester wish to pick other directory that can be done in the .feature file by
    changing the expression "default output" in the Given statement to the wanted one.

    :param current_datetime: the current date and time, in UTC
    :param full_path: str that contains the full_path or else it is set to default one.
    :return: the full path name in a uri form,
    e.g. file:///C:/Users/calculated/Mes_STIB_GBV_201801281037.csv
    """
    gbv_csv_file = OUTPUT_DATA_CSV_BASENAME_FMT.format(
        datetime_str=make_datetime_filestamp(current_datetime)
    )

    if full_path == "default output":
        return (ComTestSettings.COMPONENT_TEST_OUTPUT_DIR / gbv_csv_file).as_uri()
    else:
        return (Path("./src") / full_path / gbv_csv_file).as_uri()


def exp_file_to_compare(output_file: str, uri_of_calc_output: str) -> str:
    """Convert the uri of the calculated files to the expected file, either the
    Scenario Info or the Scenario TimeSeries, taking in account the file
    name convention file:///C:/Users/expected/Exp_File.csv

    The function helps us set the full path name that is needed to choose in the
    comparison either the expected Scenario Info or the Scenario TimeSeries.
    In case the tester wish to pick other file name than the convension, that can be
    done in the .feature file by changing the expression after expected file in the
    Then statement to the wanted one.

    :param output_file: str that says whether we want to test Scenario Info or
    TimeSeries.
    :param uri_of_calc_output: gives the designated place where the output is stored
    :return: the full path name in a uri form,
    e.g. file:///C:/Users/expected/Exp_ScenarioInfo_201902061423.csv
    """
    m = re.search("calculated", uri_of_calc_output)
    if output_file == scenario_timeseries_table:
        return uri_of_calc_output[: m.start()] + "expected/Exp_ScenarioTimeseries.csv"
    elif output_file == scenario_info_table:
        return uri_of_calc_output[: m.start()] + "expected/Exp_ScenarioInfo.csv"
    else:
        return uri_of_calc_output[: m.start()] + "expected/" + output_file


def calc_file_to_compare(output_file_type: str, uri_of_calc_output: str) -> str:
    """Convert the dataframe name to the base name the file has in our system.

    The purpose of the function is to help the tester control the output file base name.
    If not stated otherwise, the function returns a default output base name the file
    has in the our system. However, in case the tester wish to pick other file base name
    that can be done in the .feature file by changing the expression in the Then
    statement.

    :param output_file_type: str that says whether we want to test Scenario Info or
    TimeSeries.
    :param uri_of_calc_output: gives the designated place where the output is stored
    :return: the name that is given to the expected file
    """
    if output_file_type == scenario_timeseries_table:
        return uri_of_calc_output
    if output_file_type == scenario_info_table:
        return re.sub(re.escape(GBV_PART), "_SCENARIO_INFO", uri_of_calc_output, 1)
    raise ValueError(f"Unknown output type {output_file_type!r}")


def set_columns_to_compare(output_file_type: str) -> List:
    """Give the right list of columns name to compare with.

    The purpose of the function is to help the tester control the output file base name.
    If not stated otherwise, the function returns a default output base name the file
    has in the our system. However, in case the tester wish to pick other file base name
    that can be done in the .feature file by changing the expression in the Then
    statement.

    :param output_file_type: str that says whether we want to test Scenario Info or
    TimeSeries.
    :return: the right list of columns name to compare with.
    """
    # We use this list in the component test, that way we can exclude the
    # "Data_Time" and "Originating_RawScenario_Timeseries_Id" columns from testing
    if output_file_type == scenario_timeseries_table:
        columns_name_to_test = COMPONENT_TEST_OUTPUT_COLUMNS
        columns_name_to_test.remove("OriginatingRawScenarioTimeSeriesId")
        return columns_name_to_test
    if output_file_type == scenario_info_table:
        # use OneValuedInputData._fields and convert this to list of strings in
        # Snamel_Case for sake of unity
        retval = [field.title() for field in get_named_tuple_fields(OneValuedInputData)]
        retval.remove("Calculator_Version")
        retval.remove("Scenario_Creation_Datetime")
        return retval
    raise ValueError(f"Unknown output type {output_file_type!r}")


def make_diagnostic_report(
    df_calculated: pd.DataFrame,
    df_expected: pd.DataFrame,
    columns_to_compare: List[str],
):
    """Create a txt file consists of the differences of two DataFrames given

    This function first merges two DataFrames, then deletes the duplicated values
    (both of them) and saves the remaining data to a csv file into the temp
    directory. Directory and filename is logged as info.

    :param columns_to_compare: column list to be compared
    :param df_calculated: Calculated DataFrame
    :param df_expected: Expected DataFrame to be compared
    :return: None

    """
    compare = datacompy.Compare(
        df_calculated,
        df_expected,
        df1_name="Calculated",
        df2_name="Expected",
        join_columns=columns_to_compare,
    )

    with NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as named_temp_file:
        named_temp_file.write(
            compare.report(sample_count=ComTestSettings.DATACOMPY_SAMPLE_SIZE)
        )
        named_temp_file.close()

        _log.info(
            "Differences of the expected file and the calculated files are saved into "
            "[%s]",
            named_temp_file.name,
        )


def open_database(context: runner.Context) -> None:
    """Open a database, given context.db_url.  Sets context.db_session/model_base.

    This is a procedure that opens the database, determined by context.db_url.
    After successful opening, context.db_session and context.model_base are
    being set.

    :param context: holding the aforementioned attributes.
    :return: None
    """
    # Let the verbosity of SqlAlchemy depend in whether we're running with -[v or w]
    engine = create_engine_from_connection_string(
        context.db_url, echo=(context.config.verbose or context.config.wip)
    )
    context.db_session, context.model_base = new_session_base_tuple(engine, None)


@given(r"a table named (?P<table_name>\w+) with rows")
def fill_table(context: runner.Context, table_name: str) -> None:
    db_table_info = DbTableInfo(
        table_name, context.table, _TEST_DB_INPUT_CONVERSION_MAP
    )
    context.db_tables = getattr(context, "db_tables", [])
    context.db_tables.append(db_table_info)


@given(r"we store these tables in the (?P<database_name>\w+) database")
def store_raw_scenario_tables(context: runner.Context, database_name: str) -> None:
    # First, create a temporary directory, and keep a reference to it, otherwise
    # it is cleaned up immediately
    context.temp_dir = TemporaryDirectory(prefix="compotest_")
    # Now synthesize a URL understandable by SqlAlchemy
    db_url = make_test_db_url(context.temp_dir, database_name)
    # Let the verbosity of SqlAlchemy depend in whether we're running with -[v or w]
    engine = create_engine_from_connection_string(
        db_url, echo=(context.config.verbose or context.config.wip)
    )
    db_session, *_ = new_session_base_tuple(engine, Base)
    # For each Behave-table saved in the previous steps, now store them in the db
    with closing(db_session) as db_session:
        for db_table_info in context.db_tables:
            _log.debug("Storing table %r", db_table_info.table_name)
            db_table_info.store_table(Base, db_session)


@when(r"we want to use the (?P<database_name>\w+) database")
def when_store_db_name(context: runner.Context, database_name: str) -> None:
    context.database_name = database_name


def get_installed_teeing_logging_handler() -> Optional[ThreadTeeingLoggingHandler]:
    """Return the installed ThreadTeeingLoggingHandler instance, iff installed.

    If it is not installed, `None` is being returned.

    :return: The installed ThreadTeeingLoggingHandler instance, if any.
    """
    try:
        thread_teeing_logging_handler = one(
            (
                handler
                for handler in logging.getLogger().handlers
                if isinstance(handler, ThreadTeeingLoggingHandler)
            ),
            too_short=IndexError("Not configured"),
        )
    except IndexError:
        thread_teeing_logging_handler = None
    return thread_teeing_logging_handler
