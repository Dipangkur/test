"""
This module was created to test the main part of the project, the calculator.py
module in Gherkin style language. First, we configure variables for the
calculate function so it will read from local sources a sample of dynamic files
and static files that were created especially for the component test.
With this configuration, we call the calculate function to create a Scenario.
As a last step, this Calculated Scenario is compared to an Expected Scenario,
where one should note that in a case that they differ, the code gives us the
location of the difference in the csv file.

If one wishes to skip the component tests for any reason, instructions are
written in the README.md file.
"""
from datetime import datetime
from typing import List

from behave import given, when, then, runner
from unittest.mock import patch

from hamcrest import equal_to
from hamcrest.core import assert_that
from hamcrest.core.core import is_
from pandas.testing import assert_frame_equal
import pandas as pd

from component_tests.features.steps.utility_component_tests import (
    exp_file_to_compare,
    set_columns_to_compare,
    full_path_input,
    full_path_output,
    calc_file_to_compare,
    get_installed_teeing_logging_handler,
    make_diagnostic_report,
)
from scenario_calculator.calculator import calculate
from scenario_calculator.config import GeneralConfig, RunParams, RunDefinition
from component_tests.component_tests_settings import ComTestSettings


@given("we configured the full_path of the input to {input} and output to {output}")
def retrieve_component_config_data(context: runner.Context, input, output) -> None:
    """"Set configuration for the calculate function.

    This function uses the component_test_setting file to set configurations of
    read and write directories that the calculate function uses and put them in
    the context variable.

    It also checks if a `ThreadTeeingLoggingHandler` instance is installed in
    the logging system, and adds this instance to the `GeneralConfig` structure
    if this is indeed the case.

    :param context: class behave uses to hand over variables in a feature.
    :return: None
    """
    thread_teeing_logging_handler = get_installed_teeing_logging_handler()
    context.general_config = GeneralConfig(
        thread_teeing_logging_handler=thread_teeing_logging_handler
    )
    raw_scenario_input_url_str = full_path_input(input)
    current_datetime = datetime.utcnow()
    scenario_output_url_str = full_path_output(current_datetime, output)
    blob_storage_account_key = "test_key"
    static_file_urls = None
    is_lab = False
    event_logger_url_str = None
    context.run_params = RunParams(
        raw_scenario_input_url_str,
        scenario_output_url_str,
        blob_storage_account_key,
        event_logger_url_str,
    )
    # set random RunDefinition parameters
    context.run_definition = RunDefinition(
        1,
        1,
        "201709 Plus",
        "RABONETEU\\DoeJ",
        "7.8.11-beta.23",
        datetime(2018, 9, 30, 13, 53, 5, 608),
        "Scenario for Component Test",
        current_datetime,
        is_lab,
        static_file_urls,
    )


@when("calculate function is used")
def simulate_calculate(context: runner.Context) -> None:
    """Simulate the calculate function using local files.

    The function run the calculate function using dynamic files and static
    files from the component_tests directory. The function does that via
    mocking of the setting.py file with component_tests_settings.py. That way
    the function will be manipulated to read from the wanted directory.

    :param context: object behave uses to hand over variables in a feature.
    :return: None
    """
    with patch("scenario_calculator.calculator.Settings", ComTestSettings):
        calculate(context.general_config, context.run_params, context.run_definition)


@then(
    "the calculated file {calculated_file} is equal to the expected file "
    "{expected_file} for selected {output_file} columns"
)
def compare(
    context: runner.Context, calculated_file: str, expected_file: str, output_file: str
) -> None:
    """Compare the Calculated Scenario to an Expected Scenario.

    The function compare the Calculated Scenario to an Expected Scenario not
    including columns that includes the current date

    :param output_file:
    :param expected_file:
    :param calculated_file:
    :param context: object behave uses to hand over variables in a feature.
    :return: None
    """
    df_calculated = pd.read_csv(
        calc_file_to_compare(
            calculated_file, context.run_params.scenario_output_url_str
        ),
        delimiter=";",
        encoding="utf-8",
    )
    df_expected = pd.read_csv(
        exp_file_to_compare(expected_file, context.run_params.scenario_output_url_str),
        delimiter=";",
        encoding="utf-8",
    )
    df_calculated = df_calculated.round(
        {"Mu": 8, "Sigma": 8, "Value": 8, "StandardizedValue": 8}
    )
    df_expected = df_expected.round(
        {"Mu": 8, "Sigma": 8, "Value": 8, "StandardizedValue": 8}
    )

    # Check the data frame column names are matching
    assert_that(
        sorted(list(df_calculated.columns)),
        is_(equal_to(sorted(list(df_expected.columns)))),
        "DataFrame column names are different",
    )
    # Check the column dtypes
    assert_that(
        sorted(list(df_calculated.dtypes)),
        is_(equal_to(sorted(list(df_expected.dtypes)))),
        "DataFrame column dtypes are different",
    )
    # Return the columns of the values that are not equal excluding the time column
    columns_to_compare = set_columns_to_compare(output_file)

    sort_list = [
        "MacroEconomicVariable",
        "Unit",
        "NigemCode",
        "ValueDate",
    ]

    try:
        # ScenarioTimeSeries Comparison
        if set(sort_list).issubset(set(df_calculated.columns)):
            df_right = _sort_reindex_transpose(
                df_calculated[columns_to_compare], sort_list
            )
            df_left = _sort_reindex_transpose(
                df_expected[columns_to_compare], sort_list
            )
        # Scenario Comparison
        else:
            df_right = df_calculated[columns_to_compare].transpose()
            df_left = df_expected[columns_to_compare].transpose()

        assert_frame_equal(df_left, df_right)

    except AssertionError:
        make_diagnostic_report(
            df_calculated[columns_to_compare],
            df_expected[columns_to_compare],
            columns_to_compare,
        )
        raise


def _sort_reindex_transpose(
    df_to_sort: pd.DataFrame, sort_list: List[str]
) -> pd.DataFrame:
    """ Order the expected and calculated DataFrames based on sort list and reset the
    indices in order to eliminate the assertion fails based on indices

    :param df_to_sort: DataFrame to be sorted
    :param sort_list: Column list to sort DataFrame
    :return: pd.DataFrame
    """
    return (
        df_to_sort.sort_values(by=sort_list,)
        .reset_index(drop=True)
        .reindex(axis=1)
        .transpose()
    )
