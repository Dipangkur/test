import logging

import pandas as pd
from behave import given, when, then, runner, use_step_matcher
from hamcrest import equal_to, assert_that, is_
from more_itertools import one
from pandas import DataFrame
from sqlalchemy import func
from sqlalchemy.ext.declarative import DeclarativeMeta

from component_tests.behave_db_utils import make_test_db_url
from component_tests.features.steps.utility_component_tests import open_database
from scenario_calculator.io.base_reader import read_raw_scenario_from_db

_log = logging.getLogger(__name__)

use_step_matcher("re")


@given(r"that we open the (?P<database_name>\w+) database")
def open_existing_database(context: runner.Context, database_name: str) -> None:
    context.db_url = make_test_db_url(context.temp_dir, database_name)
    open_database(context)


@when(r"we count the number of entries from the table named (?P<table_name>\w+)")
def count_entries_from_table(context: runner.Context, table_name: str) -> None:
    model_cls: DeclarativeMeta = one(
        (
            model_cls
            for model_cls in context.model_base.__subclasses__()
            if model_cls.__name__ == table_name
        )
    )
    # See https://docs.sqlalchemy.org/en/latest/orm/tutorial.html#counting
    context.count = context.db_session.query(func.count(model_cls.Id)).scalar()


@then(r"it will be (?P<count_str>\d+)")
def compare_count_outcome(context: runner.Context, count_str: str) -> None:
    assert_that(context.count, is_(equal_to(int(count_str))))
    context.db_session.close()
    del context.db_session


@given(r"that we want to use the (?P<database_name>\w+) database")
def given_store_db_name(context: runner.Context, database_name: str) -> None:
    context.database_name = database_name


@when(r"we read raw scenario with id (?P<id_str>\d+)")
def read_raw_scenario_by_id(context: runner.Context, id_str: str) -> None:
    context.df_actual = read_raw_scenario_from_db(
        make_test_db_url(context.temp_dir, context.database_name), int(id_str), 0
    )


@then(r"the resulting dataframe should have column names and types like")
def check_df_cols_and_types(context: runner.Context) -> None:
    df_columns_expected = context.table.headings
    df_actual: DataFrame = context.df_actual
    assert_that(df_actual.columns.values.tolist(), is_(equal_to(df_columns_expected)))
    types_str_expected = list(one(context.table))
    types_str_actual = [str(typ) for typ in df_actual.dtypes]
    assert_that(types_str_actual, is_(equal_to(types_str_expected)))


@then(r"the resulting dataframe should exactly have the following rows")
def check_df_contents(context: runner.Context) -> None:
    df_actual: DataFrame = context.df_actual
    dtypes = df_actual.dtypes
    df_expected_records_iter = (
        tuple((dtyp.type(val) for val, dtyp in zip(row, dtypes)))
        for row in context.table.rows
    )
    df_expected = DataFrame.from_records(
        df_expected_records_iter, columns=context.table.headings
    )
    pd.testing.assert_frame_equal(
        df_actual, df_expected, check_column_type=True, check_exact=True
    )
