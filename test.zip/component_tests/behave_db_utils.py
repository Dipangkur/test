import re
from itertools import zip_longest
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Mapping, Type, Callable, List, Any, Optional, TypeVar, Iterator

import attr
from behave.model import Table
from hamcrest import assert_that, is_, equal_to
from more_itertools import one
from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm import Session

from scenario_calculator.io.db_conv_utils import iter_db_field_attributes

_T = TypeVar("_T")
_SPECIAL_NULL_FORM = "<NULL>"

INPUT_CONVERSION_MAP_TYPE = Mapping[Type[_T], Callable[[str], _T]]


@attr.s(frozen=True, auto_attribs=True)
class DbTableInfo:
    """Contains relevant information for tables created in a Behave feature.

    The following attribute instance variables are defined:"""

    table_name: str
    __doc__ += """
    :ivar table_name: the name of the table"""

    table_contents: Table
    __doc__ += """
    :ivar table_contents: the contents of the table obtained from the feature file"""

    conversion_map: Mapping[Type[_T], Callable[[str], _T]]
    __doc__ += """
    :ivar conversion_map: a mapping how to convert the string value from the Behave
      table to a value compliant to the given `python_type`. The actual `python_type`
      used as the key in the mapping is the `python_type` associated with the column
      SqlType as given in the table model."""

    # Sentinel
    __doc__ += """
    """

    def _get_model(self, base_cls: DeclarativeMeta) -> DeclarativeMeta:
        """Return the model belonging to this object's table.

        :param base_cls: the declarative base in which this table was defined
        :return: the corresponding SqlAlchemy Table class
        """
        return one(
            (
                model_cls
                for model_cls in base_cls.__subclasses__()
                # This works as the table models have been defined in code
                # alternative?: if model_cls.metadata.sorted_tables[0].key == table_name
                if model_cls.__tablename__ == self.table_name
            )
        )

    def _check_model_header_fields(self, model_cls: DeclarativeMeta) -> None:
        """Check whether the column names match with the given database model.

        :param model_cls: the model class containing the instrumented attributes
          describing the data base fields (columns)
        """
        field_attributes_iterator = iter_db_field_attributes(model_cls)
        # Using zip_longest instead of zip in order to spot errors early (e.g. suppose
        # one of the arguments yields an emtpy iterable, everything would look fine)
        for col_name, field_attr in zip_longest(
            self.table_contents.headings, field_attributes_iterator
        ):
            assert_that(col_name, is_(equal_to(field_attr.key)))

    def _make_input_filters(
        self, model_cls: DeclarativeMeta
    ) -> List[Callable[[str], Any]]:
        """Setup the appropriate input filter for the test input fields.

        :param model_cls: the model class containing the instrumented attributes
          describing the data base fields (columns)
        :return: a list of conversion functions how to convert the string
          value from the Behave table to a value suitable for the respective column
          SqlType as given in the table model.
        """
        conversion_map = self.conversion_map
        return [
            conversion_map.get(python_type, python_type)
            for python_type in (
                # See https://stackoverflow.com/questions/11632513
                #  /sqlalchemy-introspect-column-type-with-inheritance
                field_attribute.property.columns[0].type.python_type
                for field_attribute in iter_db_field_attributes(model_cls)
            )
        ]

    def make_db_row_iter_from_behave_table(
        self, base_cls: DeclarativeMeta
    ) -> Iterator[DeclarativeMeta]:
        """Convert the contents of the Behave table into an iterator df table instances.

        :param base_cls: the base class of the database table models
        :return: an Iterator of database model instance objects
        """

        def _recognise_none(value_as_str: str) -> Optional[str]:
            """Recognise field values for special value '<NULL>', or return unchanged.

            Return None if the value is equal to '<NULL>'.

            :param value_as_str: the Behave feature field value (as string)
            :return: None or the passed argument unchanged
            """
            return None if value_as_str == _SPECIAL_NULL_FORM else value_as_str

        model_cls = self._get_model(base_cls)
        self._check_model_header_fields(model_cls)
        input_filters = self._make_input_filters(model_cls)
        for row in self.table_contents:
            kwargs = {
                field_name: None if field_str_val is None else conv_func(field_str_val)
                for field_name, field_str_val, conv_func in zip_longest(
                    self.table_contents.headings,
                    (_recognise_none(field_str_value) for field_str_value in row),
                    input_filters,
                )
            }
            db_row = model_cls(**kwargs)
            yield db_row

    def store_table(self, base_cls: DeclarativeMeta, db_session: Session) -> None:
        """Store the contents of the Behave table into the corresponding database table.

        :param base_cls: the base class of the database table models
        :param db_session: the SqlAlchemy session to use
        :return: None
        """

        db_row_iter = self.make_db_row_iter_from_behave_table(base_cls)
        db_session.add_all(db_row_iter)
        db_session.commit()

    def make_contents_row_iter(
        self, base_cls: DeclarativeMeta, db_session: Session
    ) -> Iterator[DeclarativeMeta]:
        """Return an iterator of the full (test) database contents.

        :param base_cls: the base class of the database table models
        :param db_session: the SqlAlchemy session to use
        :return: an Iterator of database model instance objects
        """
        model_cls = self._get_model(base_cls)
        return iter(db_session.query(model_cls))


def make_test_db_url(temp_dir: TemporaryDirectory, database_name: str) -> str:
    """Create a valid SqlAlchemy URL for a test database in a temporary directory

    :param temp_dir: the temporary directory to use
    :param database_name: the name of the database
    :return: the url string to be used for the SqlAlchemy connection
    """
    file_path = Path(temp_dir.name) / (database_name + "_sqlite.db")
    return "sqlite:///" + _str_fmt_quote(str(file_path))


def _str_fmt_quote(format_string: str) -> str:
    """Process the input string to protect it against the str.format functionality.

    :param format_string: the format string to process
    :return: the contents of the input with all the curly braces doubled
    """
    return re.sub(r"([{}])", r"\1\1", format_string)
