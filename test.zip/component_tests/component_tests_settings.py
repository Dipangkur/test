"""Settings for Component Test"""
from component_tests import COM_TEST_DATA_DIR
from scenario_calculator.settings import Settings


class ComTestSettings:
    # Component test paths
    COMPONENT_TEST_DYNAMIC_DATA_DIR = (
        COM_TEST_DATA_DIR / "input" / "dynamic_component_test"
    )
    COMPONENT_TEST_OUTPUT_DIR = COM_TEST_DATA_DIR / "output" / "calculated"
    COMPONENT_TEST_EXPECTED_DIR = COM_TEST_DATA_DIR / "output" / "expected"

    STATIC_DATA_DIR = COM_TEST_DATA_DIR / "input" / "static_data_component_test"

    DATACOMPY_SAMPLE_SIZE = 10000

    # A dict. we use to give the right name for each static data csv file
    STANDARD_FILE_MAPPING = Settings.STANDARD_FILE_MAPPING.copy()
