# -*- coding: utf-8 -*-
from pathlib import Path

COM_TEST_DATA_DIR = Path(__file__).parent / "data"
