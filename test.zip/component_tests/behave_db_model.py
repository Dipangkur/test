from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    String,
    Boolean,
    ForeignKey,
    FLOAT,
    CheckConstraint,
    Date,
)
from sqlalchemy.ext.declarative import declarative_base

from scenario_calculator.io.db_conv_utils import iter_db_field_attributes

Base = declarative_base()


class RawScenarioUnitTestModel(Base):
    """The model definition of the RawScenario table."""

    __tablename__ = "RawScenario"

    Id = Column(Integer, primary_key=True, nullable=False)
    CreationDateTime = Column(DateTime, nullable=False)  # Do not use MsSql DATETIME2
    RawScenarioName = Column(String(100), nullable=False)
    ReportingDate = Column(DateTime, nullable=False)
    Creator = Column(String(20), nullable=False)
    RawScenarioStatus = Column(String(20), nullable=False)
    ReviewedBy = Column(String(100), nullable=True)
    ReviewDate = Column(DateTime, nullable=True)
    MeisterVersion = Column(String(200), nullable=False)
    ReviewMessage = Column(String, nullable=True)
    RawScenarioDescription = Column(String(100), nullable=True)
    ScenarioDescriptionFile = Column(String, nullable=True)
    IsLab = Column(Boolean, nullable=False)  # Do not use MsSql BIT

    def __repr__(self):
        formatted_kwargs_iter = (
            f"{field_name}={getattr(self, field_name)!r}"
            for field_name in (
                field_attr.key
                for field_attr in iter_db_field_attributes(self.__class__)
            )
        )
        return f"<{self.__class__.__qualname__}{', '.join(formatted_kwargs_iter)}>"


class RawScenarioTimeSeriesUnitTestModel(Base):
    """The model definition of the RawScenarioTimeSeries table."""

    __tablename__ = "RawScenarioTimeSeries"

    # Column `Id`: The IDENTITY(1,1) is automatically taken care of by SqlAlchemy ORM
    Id = Column(Integer, primary_key=True, nullable=False)
    RawScenarioId = Column(Integer, ForeignKey("RawScenario.Id"), nullable=False)
    CreationDateTime = Column(DateTime, nullable=False)  # Do not use MsSql DATETIME2
    TimeSeriesCode = Column(String(12), nullable=False)
    RawScenarioTimeSeriesPeriod = Column(String(6), nullable=False)
    RawScenarioTimeSeriesValue = Column(FLOAT(53), nullable=False)
    RawScenarioTimeSeriesType = Column(String(12), nullable=False)
    RawScenarioTimeSeriesUnit = Column(String(12), nullable=False)
    RawScenarioTimeSeriesSource = Column(String(100), nullable=False)
    RawScenarioTimeSeriesDescription = Column(String(255), nullable=True)

    def __repr__(self):
        formatted_kwargs_iter = (
            f"{field_name}={getattr(self, field_name)!r}"
            for field_name in (
                field_attr.key
                for field_attr in iter_db_field_attributes(self.__class__)
            )
        )
        return f"<{self.__class__.__qualname__}{', '.join(formatted_kwargs_iter)}>"


class ScenarioUnitTestModel(Base):
    """The model definition of the Scenario table."""

    __tablename__ = "Scenario"

    Id = Column(Integer, primary_key=True, nullable=False)
    ScenarioName = Column(String(100), nullable=False)
    ScenarioCreationDatetime = Column(DateTime, nullable=True)
    # Do not use MsSql DATETIME2
    OriginatingRawScenarioId = Column(Integer, nullable=False)
    ReportingDate = Column(DateTime, nullable=False)
    ScenarioStartDate = Column(DateTime, nullable=False)
    ScenarioEndDate = Column(DateTime, nullable=False)
    ScenarioCreator = Column(String(255), nullable=False)
    Status = Column(
        String(20),
        CheckConstraint(
            "Status IN ("
            "'New', 'Accepted', 'Declined', 'Approved',"
            " 'Declined by SSTC')"
        ),
        nullable=False,
    )
    ReviewedBy = Column(String(100), nullable=True)
    ReviewDate = Column(DateTime, nullable=True)
    ApprovedBy = Column(String(100), nullable=True)
    ApprovalDate = Column(DateTime, nullable=True)
    SSTCApprovalDate = Column(DateTime, nullable=True)
    ModelVersion = Column(String(255), nullable=False)
    ModelDescription = Column(String(255), nullable=False)
    CalculatorVersion = Column(String(255), nullable=False)
    MeisterVersion = Column(String(255), nullable=False)
    CalculationDate = Column(DateTime, nullable=True)
    ScenarioDescription = Column(String(100), nullable=True)
    Comment = Column(String, nullable=True)
    QAFile = Column(String, nullable=True)
    RawScenarioGraph = Column(String, nullable=True)
    ApprovalReport = Column(String, nullable=True)
    IsLab = Column(Boolean, nullable=False)  # Do not use MsSql BIT

    def __repr__(self) -> str:
        formatted_kwargs_iter = (
            f"{field_name}={getattr(self, field_name)!r}"
            for field_name in (
                field_attr.key
                for field_attr in iter_db_field_attributes(self.__class__)
            )
        )
        return f"<{self.__class__.__qualname__}{', '.join(formatted_kwargs_iter)}>"

    def __eq__(self, other: "ScenarioUnitTestModel") -> bool:
        return (self.__class__ is other.__class__) and all(
            getattr(self, field_name) == getattr(other, field_name)
            for field_name in (
                field_attr.key
                for field_attr in iter_db_field_attributes(self.__class__)
            )
        )


class ScenarioTimeSeriesTestModel(Base):
    """The model definition of the ScenarioTimeSeries table."""

    __tablename__ = "ScenarioTimeSeries"

    Id = Column(Integer, primary_key=True, nullable=False)
    ScenarioId = Column(Integer, ForeignKey("Scenario.Id"), nullable=False)
    OriginatingRawScenarioTimeSeriesId = Column(Integer, nullable=True)
    MacroEconomicVariable = Column(String(50))
    Value = Column(FLOAT(53), nullable=False)
    Unit = Column(String(12), nullable=False)
    ValueDate = Column(Date)
    Type = Column(String(50), nullable=False)
    StandardizedValue = Column(FLOAT(53))
    Sigma = Column(FLOAT(53))
    Mu = Column(FLOAT(53))
    CorepCode = Column(String(2), nullable=False)
    NigemCode = Column(String(2))
    MappedToVariableCode = Column(String(50))
    MappedToCorepCode = Column(String(50))
    ToolDataAdjustment = Column(String(50), nullable=False)

    def __repr__(self) -> str:
        formatted_kwargs_iter = (
            f"{field_name}={getattr(self, field_name)!r}"
            for field_name in (
                field_attr.key
                for field_attr in iter_db_field_attributes(self.__class__)
            )
        )
        return f"<{self.__class__.__qualname__}{', '.join(formatted_kwargs_iter)}>"

    def __eq__(self, other: "ScenarioTimeSeriesTestModel") -> bool:
        return (self.__class__ is other.__class__) and all(
            getattr(self, field_name) == getattr(other, field_name)
            for field_name in (
                field_attr.key
                for field_attr in iter_db_field_attributes(self.__class__)
            )
        )
