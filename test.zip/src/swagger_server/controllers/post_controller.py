import connexion
import six

from scenario_calculator.main_rest_api_mode import \
    handle_post_start_calculate_scenario
from swagger_server.models.accepted_calculate_scenario import AcceptedCalculateScenario  # noqa: E501
from swagger_server.models.job_params_and_job_definition import JobParamsAndJobDefinition  # noqa: E501
from swagger_server import util


def post_start_calculate_scenario(job_params_and_job_definition):  # noqa: E501
    """Start calculate scenario

    Starts the calculation of a scenario, given an id defining the raw scenario. # noqa: E501

    :param job_params_and_job_definition: Job parameters and job definition
    :type job_params_and_job_definition: dict | bytes

    :rtype: AcceptedCalculateScenario
    """
    if connexion.request.is_json:
        job_params_and_job_definition = JobParamsAndJobDefinition.from_dict(connexion.request.get_json())  # noqa: E501
    # Please note that this code is generated, hence the dispatch to another
    #     function.
    return handle_post_start_calculate_scenario(job_params_and_job_definition)
