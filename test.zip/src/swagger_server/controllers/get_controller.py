import connexion
import six

from scenario_calculator.main_rest_api_mode import handle_get_ping
from swagger_server.models.ping_response import PingResponse  # noqa: E501
from swagger_server import util


def get_ping():  # noqa: E501
    """Returns the status of the application

    Some info about the application # noqa: E501


    :rtype: PingResponse
    """
    # Please note that this code is generated, hence the dispatch to another
    #     function.
    return handle_get_ping()
