# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.accepted_calculate_scenario import AcceptedCalculateScenario  # noqa: E501
from swagger_server.models.job_params_and_job_definition import JobParamsAndJobDefinition  # noqa: E501
from swagger_server.test import BaseTestCase


class TestPostController(BaseTestCase):
    """PostController integration test stubs"""

    def test_post_start_calculate_scenario(self):
        """Test case for post_start_calculate_scenario

        Start calculate scenario
        """
        job_params_and_job_definition = JobParamsAndJobDefinition()
        response = self.client.open(
            '/start_calculate_scenario',
            method='POST',
            data=json.dumps(job_params_and_job_definition),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
