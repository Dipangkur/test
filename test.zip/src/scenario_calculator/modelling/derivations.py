# type: ignore[attr-defined]
"""This module 'derives' new time series from existing time series.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""
import logging
from copy import deepcopy
from typing import Optional

import pandas as pd
from more_itertools import one

from scenario_calculator.modelling import adjustment
from scenario_calculator.utility import common_dataframe_error_handler

# Globals:
logger = logging.getLogger(__name__)
SRC = "MES Generator Tool"
UNIT = "ABS_ACT"


def get_gdp_per_cappopt(
    df_variables: pd.DataFrame,
    country_code: str,
    scenario_name: str,
    single_scenario_df: pd.DataFrame,
    unit: str = UNIT,
) -> Optional[pd.DataFrame]:
    """Computes GDPperCapPOPT series.

    :param df_variables: Defining the macroeconomic variables.
    :param country_code: NIGEM country code
    :param scenario_name: scenario name
    :param single_scenario_df: DataFrame containing time series belonging
      to a scenario
    :param unit: unit (currently set to ABS_ACT)
    :return: derived gdp_per_cappopt series
    """
    return compute_gdp_per_capita_time_series(
        df_variables,
        country_code,
        scenario_name,
        single_scenario_df,
        unit=unit,
        capita_type="POPT",
    )


def get_gdp_per_popwa(
    df_variables: pd.DataFrame,
    country_code: str,
    scenario_name: str,
    single_scenario_df: pd.DataFrame,
    unit: str = UNIT,
) -> Optional[pd.DataFrame]:
    """Computes GDPperCapPOPWA series.

    :param df_variables: Defining the macroeconomic variables.
    :param country_code: NIGEM country code
    :param scenario_name: scenario name
    :param single_scenario_df: DataFrame containing time series belonging
      to a scenario
    :param unit: unit (currently set to ABS_ACT)
    :raises ValueError: if POPWA is NULL.
    :return: derived gdp_per_popwa series
    """
    # TODO [AB]: Fixes after SingleScenario Removal - eval is the best in terms of
    #  performance, but not particularly good for the readibility. Investigate for a
    #  possible solution (more examples among the code base).
    # Fallback: if POPWA series do not exist, fail the calculation
    if pd.eval(
        'single_scenario_df[((single_scenario_df["nigem_code"] == country_code) & '
        '(single_scenario_df["variable_code"] == "POPWA") & (single_scenario_df["unit"]'
        " == unit))]"
    ).empty:
        err = (
            country_code
            + "POPWA, "
            + unit
            + " is not part of "
            + str(single_scenario_df)
        )
        logger.error("%s", err, exc_info=True)
        raise ValueError("POPWA cannot be NULL")

    return compute_gdp_per_capita_time_series(
        df_variables,
        country_code,
        scenario_name,
        single_scenario_df,
        unit=unit,
        capita_type="POPWA",
    )


@common_dataframe_error_handler
def compute_gdp_per_capita_time_series(
    df_variables: pd.DataFrame,
    country_code: str,
    scenario_name: str,
    single_scenario_df: pd.DataFrame,
    unit: str = UNIT,
    capita_type: str = "POPT",
) -> Optional[pd.DataFrame]:
    """Computes gdp per capita.

    Returns `None` if the Timeseries objects needed to compute RR3M are not found.

    :param df_variables: Defining the macroeconomic variables.
    :param country_code: NIGEM country code
    :param scenario_name: scenario name
    :param single_scenario_df: dictionary containing time series belonging
                            to a scenario
    :param unit: unit ("ABS_ACT" if not specified)
    :param capita_type: either POPT or POPWA ("POPT" if not specified)
    :return: gdp per capital time series or None
    """
    # Retrieve timeseries needed to compute gpd_per_cappopwa:
    tseries1 = pd.eval(
        'single_scenario_df[((single_scenario_df["nigem_code"] == country_code) & '
        '(single_scenario_df["variable_code"] == "Y") & (single_scenario_df["unit"]'
        " == unit))]"
    )

    tseries2 = pd.eval(
        'single_scenario_df[(single_scenario_df["nigem_code"] == country_code) &'
        ' (single_scenario_df["variable_code"] == capita_type) &'
        ' (single_scenario_df["unit"] == unit)]'
    )

    # Retrieve attributes of resulting Timeseries object:
    corep_code = tseries1["corep_code"].iloc[0]
    period = tseries1["period"].iloc[0]

    # Determine derived series:
    series = adjustment.calculate_ratio(tseries1.series, tseries2.series)

    # Determine start of extension and last observed value:
    start_year = _start_year_from_series_seq([tseries1, tseries2])
    last_obs_date = _last_obs_date_from_series_seq([tseries1, tseries2])

    derived_variable_code = "GDPperCAP" + capita_type
    aggregation_type = _get_aggregation_type_for_variable_code(
        df_variables, derived_variable_code
    )
    # Construct the timeseries dataframe
    time_series = deepcopy(pd.DataFrame(tseries1))
    time_series["series"] = series
    time_series["source"] = SRC
    time_series["scenario"] = scenario_name
    series_code = country_code + derived_variable_code
    time_series["series_code"] = series_code
    time_series["variable_code"] = series_code[2:]
    time_series["unit"] = unit
    time_series["start_year_extension"] = start_year
    time_series["aggregation_type"] = aggregation_type
    time_series["conversion_factor"] = 1.0
    time_series["last_obs_date"] = last_obs_date
    time_series["period"] = period
    time_series["corep_code"] = corep_code
    # Return new timseries dataframe:
    return time_series.dropna(subset=["series"])


@common_dataframe_error_handler
def get_real_rate(
    df_variables: pd.DataFrame,
    country_code: str,
    scenario_name: str,
    single_scenario_df: pd.DataFrame,
    unit: str = UNIT,
) -> Optional[pd.DataFrame]:
    """Computes RR3M series.

    Returns `None` if the Timeseries objects needed to compute RR3M are not found.

    :param df_variables: Defining the macroeconomic variables.
    :param country_code: NIGEM country code
    :param scenario_name: scenario name
    :param single_scenario_df: dataframe containing time series belonging
                            to a scenario
    :param unit: unit ("ABS_ACT" if not specified)
    :return: derived real_interest_rate series or None
"""
    # Retrieve Timeseries objects needed to compute RR3M:
    tseries1 = pd.eval(
        'single_scenario_df[((single_scenario_df["nigem_code"] == country_code) & '
        '(single_scenario_df["variable_code"] == "R3M") & '
        '(single_scenario_df["unit"] == unit))]'
    )
    tseries2 = pd.eval(
        'single_scenario_df[((single_scenario_df["nigem_code"] == country_code) & '
        '(single_scenario_df["variable_code"] == "CED") & '
        '(single_scenario_df["unit"] == unit))]'
    )

    # Determine derived series:
    series = adjustment.calculate_real_interest_rate(tseries1.series, tseries2.series)

    # Determine start of extension and last observed value:
    start_year = _start_year_from_series_seq([tseries1, tseries2])
    last_obs_date = _last_obs_date_from_series_seq([tseries1, tseries2])

    derived_variable_code = "RR3M"
    aggregation_type = _get_aggregation_type_for_variable_code(
        df_variables, derived_variable_code
    )
    # Construct the timeseries dataframe
    time_series = deepcopy(pd.DataFrame(tseries1))
    series_code = country_code + derived_variable_code
    time_series["series"] = series
    time_series["source"] = SRC
    time_series["scenario"] = scenario_name
    time_series["derived_variable_code"] = derived_variable_code
    time_series["series_code"] = series_code
    time_series["variable_code"] = series_code[2:]
    time_series["unit"] = unit
    time_series["start_year_extension"] = start_year
    time_series["aggregation_type"] = aggregation_type
    time_series["conversion_factor"] = 1.0
    time_series["last_obs_date"] = last_obs_date

    # Return new timseries dataframe:
    return time_series.dropna(subset=["series"])


def _get_aggregation_type_for_variable_code(
    df_variables: pd.DataFrame, variable_code: str
) -> str:
    """Lookup the aggregation type that should be applied for this variable code.

    :param df_variables: Defining the macroeconomic variables
      (amongst others: the aggregation (transformation) type)
    :param variable_code: the code to do the lookup for
    :return: the aggregation type (should be 'AVG' or 'SUM')
    """
    return one(
        df_variables[
            df_variables["variable_code"] == variable_code
        ].aggregation_transformation_type.values
    )


def _last_obs_date_from_series_seq(time_series_lst: pd.DataFrame,) -> pd.Timestamp:
    """Determine the earliest last observation of all series in input

    :param time_series_lst: list of TimeSeries objects of which the last
      observation date is requested
    :type time_series_lst: list
    :return: Date of the earliest last observation date in the list of \
             TimeSeries
    :rtype:  TimeStamp
    """
    lst = [tseries["last_obs_date"].dropna().min() for tseries in time_series_lst]
    return min(lst)


def _start_year_from_series_seq(time_series_lst: pd.DataFrame) -> int:
    """Determine start year of extensions"""
    lst = [
        tseries["start_year_extension"].dropna().min() for tseries in time_series_lst
    ]
    return min(lst)
