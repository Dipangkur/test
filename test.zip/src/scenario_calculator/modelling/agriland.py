# type: ignore[attr-defined]
"""
Implements agriland modelling functionality.

Agriland prices are an important variable for Rabobank stress tests, but are missing in
the data delivery. This means no scenarios are provided. The MES team is responsible to
deliver historical agriland timeseries to the application. Using standard shocks (from
static_agriland_params), this  module updates the related values of the required
scenarios by applying the "Agriland Model" which consists consecutive steps as:
    - Filter/Select data to apply model
    - Convert ABS_ACT to ABS (based on reporting date)
    - Convert ABS to cumulative growth
    - Apply shocks (to filtered data)
    - Convert cumulative growth back to ABS
    - Convert ABS back to ABS_ACT

>> Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""
import logging
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from pandas._libs.tslibs.period import Period

from scenario_calculator.constants import (
    DATE_FMT,
    QUARTERS_TO_HAVE_AFTER,
    QUARTERS_TO_HAVE_BEFORE,
    ObservationType,
)
from scenario_calculator.event_logger import IncompleteRawScenarioError
from scenario_calculator.io.pre_process import get_frequency
from scenario_calculator.modelling.adjustment import (
    inverse_transform,
    sample_to_quarterly,
    sample_to_yearly,
    transform,
)
from scenario_calculator.other_country import pass_if_first_arg_is_none_or_empty
from scenario_calculator.utility import generate_quarter_format

_log = logging.getLogger(__name__)


@pass_if_first_arg_is_none_or_empty
def transform_to_cumulative_growth(series_yoy_df: pd.DataFrame) -> pd.DataFrame:
    """ Converts year on year data to cumulative growth
    :param series_yoy_df:
    :return: series_cumulative_yoy_df: cumulative year on year data
    """

    series_cumulative_yoy_df = series_yoy_df.copy()

    for i, row in enumerate(series_cumulative_yoy_df.itertuples()):
        if i != 0:
            series_cumulative_yoy_df.loc[row.Index, "value"] = (
                1 + series_cumulative_yoy_df.loc[row.Index - 1, "value"]
            ) * (1 + row.value) - 1

    return series_cumulative_yoy_df


@pass_if_first_arg_is_none_or_empty
def apply_shock(
    series_cumulative_yoy_df: pd.DataFrame, filtered_agriland_df: pd.DataFrame
) -> pd.DataFrame:
    """ Using the filtered agriland parameters, applies shock and creates cumulative
    shocked data
    :param series_cumulative_yoy_df:
    :param filtered_agriland_df: filtered and yearly adapted static agriland parameters
    :return: cumulative_shocked_df
    """
    time_series_code = series_cumulative_yoy_df["time_series_code"].unique()[0]
    filtered_agriland_df = filtered_agriland_df.loc[
        filtered_agriland_df["time_series_code"] == time_series_code
    ]
    cumulative_shocked_df = series_cumulative_yoy_df.copy()
    for row in cumulative_shocked_df.itertuples():
        year_column = generate_quarter_format(row.period)
        cumulative_shocked_df.loc[row.Index, "value"] = (
            row.value + filtered_agriland_df[year_column].iloc[0]
        )
    return cumulative_shocked_df


@pass_if_first_arg_is_none_or_empty
def inverse_transform_from_cumulative_growth(shocked_df: pd.DataFrame) -> pd.DataFrame:
    """
    Converts shocked data to cumulative shocked growth
    :param shocked_df:
    :return: inversed_shocked_yoy_df
    """
    inversed_shocked_yoy_df = shocked_df.copy()

    for i, row in enumerate(inversed_shocked_yoy_df.itertuples()):
        if i != 0:
            inversed_shocked_yoy_df.loc[row.Index, "value"] = (1 + row.value) / (
                1 + shocked_df.loc[row.Index - 1, "value"]
            ) - 1

    return inversed_shocked_yoy_df.reset_index(drop=True)


@pass_if_first_arg_is_none_or_empty
def get_abs_shocked_df(
    inversed_shocked_yoy_df: pd.DataFrame, abs_starting_point: float
) -> pd.Series:
    """
    Converts cumulative shocked data to ABS
    :param inversed_shocked_yoy_df:
    :param abs_starting_point:
    :return: abs_shocked
    """
    inversed_shocked_yoy_df["period"] = pd.to_datetime(
        inversed_shocked_yoy_df["period"]
    )
    inversed_shocked_yoy_df.set_index("period", inplace=True)

    # to calculate abs_shocked, abs_starting_point and the first value of
    # inversed_shocked_yoy_df is needed to calculate "start" argument for
    # inverse_transform function
    transform_starting_point = abs_starting_point * (
        1 + inversed_shocked_yoy_df["value"][0]
    )
    abs_shocked = inverse_transform(
        inversed_shocked_yoy_df["value"], "YOY", transform_starting_point,
    )
    return abs_shocked


@pass_if_first_arg_is_none_or_empty
def apply_agriland_model(
    dynamic_df: pd.DataFrame,
    static_data_dict: Dict[str, pd.DataFrame],
    reporting_date: str,
) -> Tuple:
    """
    Applies all the steps of the Agriland Model and returns "dynamic_df"s with and
    without agriland data
    :param dynamic_df:
    :param static_data_dict:
    :param reporting_date:
    :return: dynamic_agriland_df, dynamic_df
    """
    # get unique agriland time series codes
    filtered_agriland_df = static_data_dict["agriland"]
    dynamic_agriland_df, dynamic_df = split_and_truncate_dynamic_df(
        dynamic_df, filtered_agriland_df
    )

    if dynamic_agriland_df.empty:
        return dynamic_agriland_df, dynamic_df, static_data_dict

    model_applied_agriland_df = pd.DataFrame()
    for tsc in dynamic_agriland_df["time_series_code"].unique():
        sub_dynamic_agriland_df, abs_starting_point = _get_sub_dynamic_agriland_df(
            dynamic_agriland_df, tsc, reporting_date
        )
        if sub_dynamic_agriland_df.empty:
            continue
        series_absact = _get_series_absact(sub_dynamic_agriland_df)
        series_abs = _get_series_abs(series_absact, reporting_date, abs_starting_point)
        # Step 4: transform series, remove the rows equal or smaller than reporting_date
        transformed_series_yoy = transform(series_abs, "YOY")
        series_yoy_df = _get_series_yoy_df(transformed_series_yoy, reporting_date, tsc)
        # Step 6: Transform series_yoy to cumulative growth
        series_cumulative_yoy_df = transform_to_cumulative_growth(series_yoy_df)
        # Step 7: Apply shock
        shocked_df = apply_shock(series_cumulative_yoy_df, filtered_agriland_df)
        shocked_series_absact = _get_new_yearly_converted_series(
            shocked_df, abs_starting_point
        )
        model_applied_agriland_df = _append_model_applied_slices(
            model_applied_agriland_df, shocked_series_absact, tsc
        )
        model_applied_agriland_df = model_applied_agriland_df[
            model_applied_agriland_df["period"]
            > pd.to_datetime(reporting_date, format=DATE_FMT)
        ]
    dynamic_df = _merge_new_agriland_to_dynamic_df(
        dynamic_df, model_applied_agriland_df
    )

    return model_applied_agriland_df, dynamic_df, static_data_dict


def _merge_new_agriland_to_dynamic_df(
    dynamic_df: pd.DataFrame, model_applied_agriland_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Merges model applied agriland data back to dynamic_df
    :param dynamic_df:
    :param model_applied_agriland_df:
    :param dynamic_agriland_df:
    :return: dynamic_df
    """
    # Convert periods to quarter format
    model_applied_agriland_df["period"] = model_applied_agriland_df["period"].apply(
        lambda x: generate_quarter_format(x)
    )

    # left join dynamic_df with model applied agriland data
    dynamic_df = dynamic_df.merge(
        model_applied_agriland_df, how="left", on=["period", "time_series_code"],
    )

    # Update dynamic_df's "value" with model_applied_agriland_df's "value" if exists.
    dynamic_df["value_y"] = dynamic_df["value_y"].fillna(dynamic_df["value_x"])
    dynamic_df["value_x"] = dynamic_df["value_y"]
    dynamic_df.drop(["value_y"], inplace=True, axis=1)
    dynamic_df.rename(columns={"value_x": "value"}, inplace=True)

    dynamic_df["id"] = dynamic_df.index.values
    return dynamic_df


def _append_model_applied_slices(
    model_applied_agriland_df: pd.DataFrame, new_series: pd.Series, tsc: str
):
    """
    Step 9: Merge related time_series_code-MEV to each other
    :param model_applied_agriland_df:
    :param new_series:
    :param tsc:
    :return: model_applied_agriland_df
    """
    model_applied_agriland_df = model_applied_agriland_df.append(
        pd.DataFrame(
            {
                "period": new_series.index,
                "value": new_series.values,
                "time_series_code": tsc,
            }
        )
    )
    return model_applied_agriland_df


@pass_if_first_arg_is_none_or_empty
def _get_new_yearly_converted_series(
    shocked_df: pd.DataFrame, abs_starting_point: pd.Series
):
    """
    Step 8: Convert Back to YOY & ABS, append starting point, convert to quarterly data
    :param shocked_df:
    :param abs_starting_point:
    :return: new_series: model applied yearly data
    """
    # Step 8.1: Convert Back to YOY as inversed_shocked_df
    inversed_shocked_df = inverse_transform_from_cumulative_growth(shocked_df)
    # Step 8.2.1: Convert Back to ABS
    abs_shocked = get_abs_shocked_df(inversed_shocked_df, abs_starting_point[0])
    # Step 8.2.2: Append starting point to the beginning of the abs_shocked
    abs_shocked = pd.concat([abs_starting_point, abs_shocked])
    # Step 8.3: Convert yearly values back to quarterly
    new_series = sample_to_quarterly(abs_shocked, "AVG")
    return new_series


@pass_if_first_arg_is_none_or_empty
def _get_series_yoy_df(
    transformed_series_yoy: pd.Series, reporting_date: str, tsc: str
):
    """
    Step 5: Convert series_yoy to DataFrame
    :param transformed_series_yoy:
    :param reporting_date:
    :param tsc: time_series_code
    :return: series_yoy_df
    """
    series_yoy = transformed_series_yoy[
        transformed_series_yoy.index > str(reporting_date)
    ]
    series_yoy_df = pd.DataFrame(
        {
            "period": series_yoy.index,
            "value": series_yoy.values,
            "time_series_code": tsc,
        }
    )
    return series_yoy_df


def _get_series_abs(
    series_absact: pd.Series, reporting_date: str, abs_starting_point: float
):
    """
    Step 3: Convert series_absact to yearly and add the starting point to series_abs
    :param series_absact:
    :param reporting_date:
    :param abs_starting_point:
    :return: series_abs
    """
    # Step 3.1: Convert quarterly data to yearly
    series_abs = sample_to_yearly(series_absact, "AVG", get_frequency(reporting_date))
    # Step 3.2 add the starting point to series_abs:
    series_abs = pd.concat([abs_starting_point, series_abs])
    return series_abs


@pass_if_first_arg_is_none_or_empty
def _get_series_absact(sub_dynamic_agriland_df: pd.DataFrame):
    """
    Step 2: Get Series ABS_ACT
    :param sub_dynamic_agriland_df: related slice of the dynamic_agriland_df
    :return: series_absact, abs_starting_point
    """
    # Step 2.1:
    series_absact = pd.Series(
        sub_dynamic_agriland_df["value"].values,
        index=pd.to_datetime(sub_dynamic_agriland_df["period"])
        + pd.offsets.QuarterEnd(0),
    )
    # Step 2.2 Define starting point
    # abs_starting_point = series_absact[0:1]
    return series_absact  # , abs_starting_point


@pass_if_first_arg_is_none_or_empty
def _get_sub_dynamic_agriland_df(
    dynamic_agriland_df: pd.DataFrame, tsc: str, reporting_date: str
) -> Tuple:
    """
    Step 1: get the dataframes as slices diveded by time_series_code/country
    :param dynamic_agriland_df:
    :param tsc: time_series_code to be sliced
    :return: sub_dynamic_agriland_df: sliced dataframe, abs_starting_point: pd.Series
    """
    # abs_starting_point is the last Historical type value of the related MEV (tsc)
    abs_starting_year = dynamic_agriland_df.loc[
        (dynamic_agriland_df["time_series_code"] == tsc)
        & (dynamic_agriland_df["type"] == ObservationType.Historical.name)
    ][-4:]

    # sub_dynamic_agriland_df to apply model is the ones which are not the Historical
    # types out of related MEV (tsc)
    sub_dynamic_agriland_df = dynamic_agriland_df.loc[
        (dynamic_agriland_df["time_series_code"] == tsc)
    ]

    if not is_complete_dynamic_df(sub_dynamic_agriland_df, reporting_date):
        _log.error(
            "dynamic_df for %s is not complete for the agriland model", tsc,
        )
        raise IncompleteRawScenarioError

    sub_dynamic_agriland_df = sub_dynamic_agriland_df.loc[
        (sub_dynamic_agriland_df["type"] != ObservationType.Historical.name)
    ]

    series_abs_starting_year = pd.Series(
        abs_starting_year["value"].mean(),
        index=pd.to_datetime(abs_starting_year[-1:]["period"])
        + pd.offsets.QuarterEnd(0),
    )
    return abs_starting_year.append(sub_dynamic_agriland_df), series_abs_starting_year


@pass_if_first_arg_is_none_or_empty
def get_first_and_last_quarters_with_shock_value(
    filtered_agriland_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Creates a mapping that contains the latest quater with a valid shock_value per each
    time_series_code
    :param filtered_agriland_df:
    :return:
    """
    # Initialize mapping_df
    mapping_df = filtered_agriland_df[["time_series_code"]]
    mapping_df["last_shock_quarter"] = np.nan
    mapping_df["first_shock_quarter"] = np.nan

    for index, row in filtered_agriland_df.iterrows():
        if row.last_valid_index() is not None:
            mapping_df.loc[
                mapping_df["time_series_code"] == row["time_series_code"],
                "last_shock_quarter",
            ] = str(row.last_valid_index())
        if row[2:].first_valid_index() is not None:
            mapping_df.loc[
                mapping_df["time_series_code"] == row["time_series_code"],
                "first_shock_quarter",
            ] = str(row[2:].first_valid_index())

    return mapping_df


@pass_if_first_arg_is_none_or_empty
def split_and_truncate_dynamic_df(
    dynamic_df: pd.DataFrame, filtered_agriland_df: pd.DataFrame
) -> pd.DataFrame:
    """
    Splits dynamic_df into two DataFrames as with and without agriland data

    :param dynamic_df:
    :param filtered_agriland_df:
    :return: dynamic_agriland_df, dynamic_df
    """
    if filtered_agriland_df.empty:
        return pd.DataFrame(), dynamic_df

    dynamic_df = dynamic_df.sort_values(
        by=["time_series_code", "period"], ignore_index=True
    )
    agriland_time_series_codes = filtered_agriland_df["time_series_code"].unique()
    tsc_quarter_mapping_df = get_first_and_last_quarters_with_shock_value(
        filtered_agriland_df
    )

    mask_apply_agriland = dynamic_df["time_series_code"].isin(
        agriland_time_series_codes
    )
    dynamic_agriland_df = dynamic_df[mask_apply_agriland]

    dynamic_agriland_df = dynamic_agriland_df.merge(
        tsc_quarter_mapping_df, on="time_series_code", how="left"
    )
    mask_apply_agriland = (
        dynamic_agriland_df["period"] <= dynamic_agriland_df["last_shock_quarter"]
    )
    redundant_rows_df = dynamic_agriland_df[~mask_apply_agriland][
        ["time_series_code", "period"]
    ]
    dynamic_df = dynamic_df.loc[
        ~dynamic_df.index.isin(
            dynamic_df.merge(redundant_rows_df.assign(a="key"), how="left")
            .dropna()
            .index
        )
    ]
    dynamic_agriland_df = dynamic_agriland_df[mask_apply_agriland].drop(
        ["last_shock_quarter", "first_shock_quarter"], axis=1
    )
    _print_shock_value_mapping(tsc_quarter_mapping_df)
    return dynamic_agriland_df, dynamic_df


def _print_shock_value_mapping(tsc_quarter_mapping_df: pd.DataFrame):
    warning_str = "Agriland Model is Applied for the Following Years:\n"
    mapping_str = ""
    for row in tsc_quarter_mapping_df.itertuples():
        temp_str = " ".join(
            [
                row.time_series_code,
                ": Between ",
                row.first_shock_quarter,
                " - ",
                row.last_shock_quarter,
                "\n",
            ]
        )
        mapping_str += temp_str

    _log.info(warning_str + mapping_str)


def add_months(reporting_date: str, months: int) -> str:
    """
    Adds specific amount of months to the date
    :param reporting_date:
    :param months:
    :return:
    """
    return pd.to_datetime(reporting_date, format=DATE_FMT) + pd.offsets.MonthEnd(months)


def add_quarter(date: str, n: int):
    """
    Adds n Quarters to the date
    :param date:
    :param n:
    :return:
    """
    date_period = Period(date)
    return add_months(date_period.strftime(DATE_FMT), (n * 3))


def is_complete_dynamic_df(dynamic_df: pd.DataFrame, reporting_date: str):
    """
    Data is considered incomplete for the Agriland calculation if it does not contain
    data in the range of [reporting_date – 2 year + 1 quarter, reporting_date + 1 year].
    For example, for reporting date 2020Q3, we should have Agriland data in the
    RawScenario for periods in the range of [2019Q4, 2021Q3]
    :param dynamic_df:
    :param reporting_date:
    :return:
    """
    # Define range to be checked
    start_period = add_quarter(reporting_date, QUARTERS_TO_HAVE_BEFORE)
    end_period = add_quarter(reporting_date, QUARTERS_TO_HAVE_AFTER)
    check_range = pd.date_range(start=start_period, end=end_period, freq="Q",)

    # merge the defined check_range with dynamic_df[period] column (with left join) and
    # check if all the values in the range are subset of dynamic_df[period] column
    return (
        check_range.size
        == pd.merge(
            pd.DataFrame({"period": check_range}),
            pd.DataFrame(
                {
                    "period": pd.to_datetime(dynamic_df["period"])
                    + pd.offsets.QuarterEnd(0)
                }
            ),
            how="inner",
            on="period",
        ).size
    )
