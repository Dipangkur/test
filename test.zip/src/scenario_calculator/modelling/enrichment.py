# type: ignore[attr-defined]
"""
This module 'enriches' time series; e.g. new time series
are derived from existing time series and mappings rules are
applied to deal with missing series/countries etc.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""
import copy as cp
import logging
from typing import Any, List

import pandas as pd

from scenario_calculator.io.fields import (
    OUTPUT_DATAFRAME_COLUMS,
    SCENARIO_ITEM_TO_OUTPUT_DATAFRAME_MAPPING,
)
from scenario_calculator.modelling.adjustment import sample_to_yearly, transform
from scenario_calculator.modelling.derivations import (
    get_gdp_per_cappopt,
    get_gdp_per_popwa,
    get_real_rate,
)
from scenario_calculator.utility import FREQ_TO_QUARTER

# Globals:
logger = logging.getLogger(__name__)
SRC = "MES Generator Tool"
UNIT = "ABS_ACT"


# =============================================================================
# Derivations of new series:
# =============================================================================


def derive_new_series(
    df_variables: pd.DataFrame,
    countries: List[str],
    scenarios_df: pd.DataFrame,
    unit: str = UNIT,
) -> pd.DataFrame:
    """
    This function derives new series based on the time series in the
    dictionary. Derive additional macro-economic variables: GDPperCapPOPT,
    GDPperCapPOPWA, RRM3. If the working age population (POPWA) exists
    for a country, then the GDP per capita is calculated as
    the GDP divided by POPWA, otherwise the total population is used.

    :param df_variables: Defining the macroeconomic variables.
    :param countries: unique countries
    :param scenarios_df: DataFrame containing the scenarios
    :param unit: unit (currently set to ABS_ACT)
    :return: updated scenarios dataframe
    """
    # TODO [AB]: Fixes after SingleScenario Removal - : Consider merging directly with
    #  the  _add_derived_series function
    for country in countries:
        scenarios_df = _add_derived_series(
            df_variables, country, scenarios_df["scenario"].iloc[0], scenarios_df, unit
        )

    # Return updated scenarios dataframe:
    return scenarios_df


def _add_derived_series(
    df_variables: pd.DataFrame,
    country: str,
    scenario_name: str,
    df_single_scenario: pd.DataFrame,
    unit: str,
) -> pd.DataFrame:
    """Helper function to add derived series to single_scenario for a country

    :param df_variables: input dataframe containing all time series data
    :param country: the specific country to add derived series for
    :param scenario_name: the name of the scenario
    :param df_single_scenario: the single scenario to extend
    :param unit: unit (currently set to ABS_ACT)
    :return: updated scenario dataframe
    """
    tseries_lst = (
        get_gdp_per_cappopt(df_variables, country, scenario_name, df_single_scenario),
        get_gdp_per_popwa(df_variables, country, scenario_name, df_single_scenario),
        get_real_rate(df_variables, country, scenario_name, df_single_scenario),
    )
    for tseries in tseries_lst:
        if tseries is not None:
            tseries["adjustment"] = "derived"
            df_single_scenario = df_single_scenario.append(tseries)
    return df_single_scenario


# =============================================================================
# Conversion:
# =============================================================================
def convert_series(scenarios_df: pd.DataFrame) -> pd.DataFrame:
    """
    This function converts the unit for the time series in the dictionary. Four
    variables are converted from percentage to decimal: LR, R3M, RR4M and U.
    The variables GDP and PSI are expressed in millions for some countries
    and in billions for others. For the most recent conversion factors we
    refer to "Macro-economic data used for IFRS9 & Stress Testing".

    :param scenarios_df:  containing single scenarios
    :type scenarios_df: pd.DataFrame
    :return: updated scenarios
    :rtype: pd.DataFrame
    """
    scenarios_df.series *= scenarios_df.conversion_factor

    return scenarios_df


# =============================================================================
# Aggregation:
# =============================================================================
def aggregate_series(df_scenarios: pd.DataFrame, freq: str) -> pd.DataFrame:
    """
    This function "converts" quarterly data to yearly data for the time series
    in the dictionary. Quarterly data is delivered while yearly data is used
    by the models. The process of converting quarterly data to
    yearly data is called "aggregation".

    :param df_scenarios: DataFrame containing single scenarios
    :param freq: quarter in {"A-MAR", "A-JUNE", "A-SEP", "A-DEC"}
    :return: updated scenarios
    """
    new_df = pd.DataFrame()
    for code in df_scenarios.series_code.unique():
        new_df = pd.concat(
            [
                new_df,
                _get_yearly_sampled_tseries(
                    df_scenarios[df_scenarios["series_code"] == code], freq
                ),
            ]
        )
    return _drop_columns(new_df)


def _get_yearly_sampled_tseries(tseries, freq, unit="ABS"):
    """
    Make a hard copy, and return a Timeseries object having a yearly
    frequency.

    :param tseries: Timeseries object
    :type tseries: TimeSeries
    :param freq: quarter in {"A-MAR", "A-JUNE", "A-SEP", "A-DEC"}
    :type freq: str
    :param unit: unit
    :type unit: str
    :return: new Timeseries object
    :rtype: TimeSeries
    """
    tseries["unit"] = unit
    # Get yearly data (i.e. sample to yearly frequency):
    tseries["series"] = sample_to_yearly(
        tseries.series, tseries["aggregation_type"].iloc[0], freq
    )
    return tseries.dropna(subset=["series"])


# =============================================================================
# Get quarterly subset:
# =============================================================================


def create_quarterly_subset(df: pd.DataFrame, freq: str) -> pd.DataFrame:
    """
    This function subsets a dataframe with a datetime index on the quarter.

    :param scenarios: Dataframe with a datetime index.
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :return: pandas Dataframe with the required quarter data.
    """
    return _drop_columns(df[(df.series.index.quarter == FREQ_TO_QUARTER[freq])])


# TODO [AB]: Fixes after SingleScenario Removal - consider getting column list from a
# config/settings file
def _drop_columns(df):
    """ This will reduce the dataframe size by dropping unwanted columns"""
    colm_list = [
        "series",
        "corep_code",
        "variable_code",
        "mapped_to_corep_code",
        "mapped_to_variable_code",
        "param_mu",
        "nigem_code",
        "originating_raw_scenario_time_series_id",
        "param_sigma",
        "adjustment",
        "unit",
        "series_code",
        "scenario",
        "time_series_code",
        "last_obs_date",
    ]

    return df.drop(df.columns.difference(colm_list), 1)


# =============================================================================
# Transforming:
# =============================================================================
def add_transformed_series(df_single_scenario: pd.DataFrame) -> pd.DataFrame:
    """Adds transformed timeseries to single_scenario"""
    df_single_scenario["unit"] = "ABS"
    df_delta = pd.DataFrame()
    grouped_scenario = df_single_scenario.groupby(["series_code", "unit"])
    for group_tuple, tseries in grouped_scenario:
        for unit in ["YOY", "Y-Y"]:
            new_tseries = cp.deepcopy(tseries)
            new_tseries["unit"] = unit
            new_tseries["series"] = transform(new_tseries["series"], unit)
            df_delta = pd.concat([df_delta, new_tseries])
    return pd.concat([df_single_scenario, df_delta])


# =============================================================================
# Set standardization parameters:
# =============================================================================
def set_standardization_params(
    df: pd.DataFrame, df_standardization: pd.DataFrame
) -> pd.DataFrame:
    """
    This function sets the standardisation parameters for the time series dataframe.
    The PD and LGD business loans typically use so-called standardised macro-economic
    variables as input for their models. A standardised variable has zero-mean and unit
    standard deviation. Furthermore, standardisation makes relative comparison of the
    variables between countries possible.

    :param df: dataframe containing timeseries data for a quarter.
    :param df_standardization: data frame with standardization parameters
    :return: updated dataframe
    """
    for time_series, unit, param_mu, param_sigma in df_standardization.loc[
        :, ["time_series_code", "unit", "model_param_mu", "model_param_sigma"],
    ].itertuples(index=False):
        df.loc[
            (df.series_code == time_series) & (df.unit == unit),
            ["param_sigma", "param_mu"],
        ] = (param_sigma, param_mu)

    return df


# =============================================================================
# Mappings (Series mapping):
# =============================================================================
def map_missing_series(
    df_missing_series_mapping: pd.DataFrame, df_quarterly_scenario: pd.DataFrame
) -> pd.DataFrame:
    """
        This functions maps missing series to one of the time series in the
        dataframe. For the most current mapping w.r.t. missing macro-economic
        variables we refer to "Macro-economic data used for IFRS9 & Stress
        Testing".

        :param df_missing_series_mapping: data frame with mappings for missing series
        :param df_quarterly_scenario: dataframe containing quarterly data
        :return: appended dataframe with the newly mapped series data
        """
    delta_df = pd.DataFrame()
    lst_unit = ["ABS", "ABS_ACT", "YOY", "Y-Y"]
    for time_series in df_missing_series_mapping.loc[
        :, ["time_series_code", "corep_country_code", "mapped_to_time_series_code"],
    ].itertuples(index=False):

        # for unit in lst_unit:
        delta_df = pd.concat(
            [
                delta_df,
                map_missing_series_values(
                    time_series,
                    df_quarterly_scenario[
                        (df_quarterly_scenario["unit"].isin(lst_unit))
                        & (
                            df_quarterly_scenario["series_code"]
                            == time_series.mapped_to_time_series_code
                        )
                    ],
                ),
            ]
        )

    return df_quarterly_scenario.append(delta_df)


def map_missing_series_values(time_series: Any, df: pd.DataFrame) -> pd.DataFrame:
    """
        This function helps to update dataframe column values.

        :param time_series: named tuple with series code
        :param df: dataframe to be updated
        :return: updated dataframe with values from time_series.
        """

    df.loc[:, "mapped_to_variable_code"] = df.variable_code
    df.loc[:, "series_code"] = time_series.time_series_code
    df.loc[:, "variable_code"] = time_series.time_series_code[2:]
    df.loc[:, "nigem_code"] = time_series.time_series_code[:2]
    df.loc[:, "corep_code"] = time_series.corep_country_code
    df.loc[:, "source"] = SRC
    df.loc[:, "adjustment"] = "mapped - missing series"

    return df


# =============================================================================
# Mappings (country mapping):
# =============================================================================
def map_missing_countries(
    df_missing_countries_mapping: pd.DataFrame, df_quarterly_scenario: pd.DataFrame
) -> pd.DataFrame:
    """
        This function maps missing time series for missing countries to time
        series in the dataframe.

        :param df_missing_countries_mapping: data frame with mappings for missing
                                            countries
        :param df_quarterly_scenario: data frame with quarterly data
        :return: appended quarterly dataframe
        """

    delta_df = pd.DataFrame()
    for corep_code, mapped_to_code in df_missing_countries_mapping.loc[
        :, ["corep_country_code", "mapped_to_nigem_country_code"],
    ].itertuples(index=False):

        delta_df = pd.concat(
            [
                delta_df,
                map_missing_countries_values(
                    df_quarterly_scenario[
                        df_quarterly_scenario["nigem_code"] == mapped_to_code
                    ],
                    corep_code,
                ),
            ]
        )

    return df_quarterly_scenario.append(delta_df)


def map_missing_countries_values(df: pd.DataFrame, corep_code: str) -> pd.DataFrame:
    """
    This function helps to update dataframe column values.

    :param df: dataframe with selected data based on mapped_to_code
    :param corep_code: corep code
    :return: updated scenarios
    """

    df.loc[:, "mapped_to_variable_code"] = df.variable_code
    df.loc[:, "mapped_to_corep_code"] = df.corep_code
    df.loc[:, "series_code"] = corep_code + df.series_code.str[2:]
    df.loc[:, "nigem_code"] = ""  # no NIGEM code is set
    df.loc[:, "corep_code"] = corep_code
    df.loc[:, "source"] = SRC
    df.loc[:, "adjustment"] = "mapped - missing country"

    return df


def set_value_and_date_index(df: pd.DataFrame) -> pd.DataFrame:

    df["value"] = df["series"].values
    df["date_index"] = df["series"].index
    column_mapping = SCENARIO_ITEM_TO_OUTPUT_DATAFRAME_MAPPING
    df = df.rename(columns=column_mapping)

    return df


def drop_extra_columns(df: pd.DataFrame) -> pd.DataFrame:
    # Remove extra columns.
    df = df[OUTPUT_DATAFRAME_COLUMS]
    # Clean DataFrame from the rows with nan "Value"
    df = df.dropna(subset=["Value"])

    return df
