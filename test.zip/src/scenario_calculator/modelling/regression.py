# type: ignore[attr-defined]

# TODO [DS]: SingleScenario once aliases.py is fixed.

"""
Implements regression modelling functionality.

For several variables a regression modelling approach is used.
No scenarios are provided for these variables. The MES team is responsible to
deliver relevant (historical) time series to the application to use this
features. Using model specifications (defined in a steering data table),
this module computes the required scenarios.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""

import logging
import typing
from copy import deepcopy
from typing import NamedTuple, Optional, Sequence

import pandas as pd

from scenario_calculator.utility import common_dataframe_error_handler, generate_date

from .adjustment import (
    clean_series,
    derive_actual_series,
    interpolate_series,
    inverse_transform,
    linear_combination,
    sample_to_yearly,
    subset_per_quarter,
    sum_last_values,
    transform,
)

# Globals
logger = logging.getLogger(__name__)
SRC = "MES Generator Tool - Regression"
UNIT = "ABS_ACT"


def apply_model(
    df_scenarios: pd.DataFrame, df: pd.DataFrame, freq: str, unit: str = UNIT,
) -> pd.DataFrame:
    """
    This functions applies a regression model for missing time series and
    returns an ABS_ACT series. From the ABS_ACT series, the modelled series can
    be retrieved again for dates defined by freq (i.e. freq = "A-DEC" =>
    modelled series can be retrieved again for dates end of december etc.).

    The independent variable in the regression model depends on (max.)
    4 independent variables plus a constant. The independent variables can be
    lagged. Moreover, a lagged dependent variable can be used as well.

    :param df_scenarios: DataFrame containing scenario data
    :param df: data frame with regression model parameters
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :param unit: unit (currently set to ABS_ACT)
    :return: DataFrame with regressed series added

    .. note:: number of items in scenario_dict has increased (or stayed the same)
    """
    df_list = []
    for row_nt in df.itertuples(index=False):
        series_code = row_nt.time_series_code
        time_series = compute_modelled_act_series(
            row_nt,
            series_code,
            df_scenarios,
            unit,
            freq,
            df_scenarios["scenario"].iloc[0],
        )

        df_scenarios = pd.eval(
            "df_scenarios[~(df_scenarios.series_code == series_code) & "
            "(df_scenarios.unit == unit)]"
        )
        df_list.append(time_series)
    df_list.append(df_scenarios)

    return pd.concat(df_list)


@common_dataframe_error_handler
@typing.no_type_check
def compute_modelled_act_series(
    row_nt: NamedTuple,
    series_code: str,
    single_scenario_df: pd.DataFrame,
    unit: str,
    freq: str,
    scenario_name: str,
) -> Optional[pd.DataFrame]:
    """
    Helper function to compute modelled act time series.

    :param row_nt: contains information to do regression modelling (as namedtuple)
    :param series_code: time series code
    :param single_scenario_df: DataFrame containing time series belonging to a scenario
    :param unit: {"YOY", "Y-Y", "ABS"}
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :param scenario_name: scenario name
    :raises KeyError:
    :return: resulting time series in dataframe
    """
    ts = pd.eval(
        'single_scenario_df[(single_scenario_df["series_code"] == series_code) & '
        '( single_scenario_df["unit"] == unit)]'
    )

    ts1 = pd.eval(
        'single_scenario_df[(single_scenario_df["series_code"] =='
        ' row_nt.time_series_code1) & (single_scenario_df["unit"] == unit)]'
    )

    ts2 = pd.eval(
        'single_scenario_df[(single_scenario_df["series_code"] == '
        'row_nt.time_series_code2) & (single_scenario_df["unit"] == unit)]'
    )

    ts3 = pd.eval(
        'single_scenario_df[(single_scenario_df["series_code"] == '
        'row_nt.time_series_code3) & (single_scenario_df["unit"] == unit)]'
    )

    ts4 = pd.eval(
        'single_scenario_df[(single_scenario_df["series_code"] == '
        'row_nt.time_series_code4) & (single_scenario_df["unit"] == unit)]'
    )

    modelled_series = _model(ts1, ts2, ts3, ts4, row_nt, freq)
    act_series = derive_index(
        ts.series,
        modelled_series,
        ts.last_obs_date,
        row_nt.unit,
        row_nt.aggr_type,
        freq,
    )
    # Construct the timeseries dataframe
    time_series = deepcopy(ts1)
    time_series["series"] = act_series
    time_series["start_year_extension"] = _start_year([ts1, ts2, ts3, ts3])
    time_series["last_obs_date"] = _last_date([ts1, ts2, ts3, ts3])
    time_series["source"] = SRC
    time_series["scenario"] = scenario_name
    time_series["series_code"] = series_code
    time_series["variable_code"] = series_code[2:]
    time_series["nigem_code"] = series_code[0:2]
    time_series["corep_code"] = row_nt.corep_country_code
    time_series["unit"] = unit
    time_series["conversion_factor"] = 1.0
    time_series["aggregation_type"] = row_nt.aggr_type
    time_series["adjustment"] = "modelled"

    return time_series.dropna(subset=["series"])


# =============================================================================
# Helper functions to evaluate (regression) model:
# =============================================================================


@typing.no_type_check
def _model(
    ts1: pd.DataFrame,
    ts2: pd.DataFrame,
    ts3: pd.DataFrame,
    ts4: pd.DataFrame,
    row_nt: NamedTuple,
    freq: str,
) -> Optional[pd.Series]:
    """
    Helper function to determine a modelled series given 4 time series in dataframe and
    a row with relevant data (e.g. coefficients of model) to perform regression
    modelling.

    :param ts1: A timeseries in dataframe object (1)
    :param ts2: A timeseries in dataframe object (2)
    :param ts3: A timeseries in dataframe object (3)
    :param ts4: A timeseries in dataframe object (4)
    :param row_nt: dataframe row as namedtuple containing data needed for modelling
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :return: modelled series
    """

    # Get series needed in the regression modelling step:
    s1 = _transform_series(ts1, row_nt.unit1, row_nt.lag1, row_nt.coeff1, freq)
    s2 = _transform_series(ts2, row_nt.unit2, row_nt.lag2, row_nt.coeff2, freq)
    s3 = _transform_series(ts3, row_nt.unit3, row_nt.lag3, row_nt.coeff3, freq)
    s4 = _transform_series(ts4, row_nt.unit4, row_nt.lag4, row_nt.coeff4, freq)

    # Make sure all series start at the same (start) year:
    start_year = row_nt.start_year
    s1 = preprocess(s1, start_year)
    s2 = preprocess(s2, start_year)
    s3 = preprocess(s3, start_year)
    s4 = preprocess(s4, start_year)

    # Apply regression model (basically, a linear combination of four
    # series) to find result series:
    p1 = row_nt.constant_coeff
    p2 = row_nt.lag_coeff
    return linear_combination(p1, p2, s1, s2, s3, s4)


def _transform_series(
    ts: pd.DataFrame, unit: str, lag: int, coeff: float, freq: str
) -> pd.Series:
    """
    Helper function to get series needed in the regression modelling step.

    :param ts: A TimeSeries object
    :param unit: {"YOY", "Y-Y", "ABS"}
    :param lag: time lag
    :param coeff: coefficient
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :return: series to be used in the modelling step
    """
    # Get (Pandas) series:
    series = ts.series

    # Sample to yearly series (and overwrite 'series'):
    series = sample_to_yearly(series, ts.aggregation_type.iloc[0], freq)

    # Transform series (and overwrite 'series'):
    series = transform(series, unit)

    # Shift and multiply with coeff (and overwrite 'series'):
    series = coeff * series.shift(lag)
    return clean_series(series)


def preprocess(series: pd.Series, start_year: int) -> Optional[pd.Series]:
    """Helper function to make sure all series start at the same (start) year.

    :param series: original timeseries
    :param start_year: start year for result series
    :return: preprocessed timeseries or None in case of error
    """
    # Get first year and last year of series:
    t1 = series.index[0].year
    t2 = series.index[-1].year
    if not t1 <= start_year <= t2:
        logger.error("Invalid start year of series!")
        return None
    else:
        series = series[series.index.year >= start_year]
        return clean_series(series)


# =============================================================================
# Helper functions to derive abs_act series:
# =============================================================================


def derive_index(
    historical_series: pd.Series,
    modelled_series: pd.Series,
    date: pd.Timestamp,
    unit: str,
    aggr_type: str,
    freq: str,
) -> Optional[pd.Series]:
    """
    Helper function to derive an ABS ACT series from a modelled series
    expressed in ABS, YOY or Y-Y unit.

    :param historical_series: original historical abs_act timeseries
    :param modelled_series: original timeseries expressed in ABS, YOY or Y-Y
    :param date: date last historical observation
    :param unit: {"YOY", "Y-Y", "ABS"}
    :param aggr_type: {"SUM", "AVG"}
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :return: modelled abs_act series (historical abs_act data added)
    """
    # Checks:
    if (
        unit not in ["ABS", "YOY", "Y-Y"]
        or aggr_type not in ["SUM", "AVG"]
        or freq not in ["A-MAR", "A-JUN", "A-SEP", "A-DEC"]
    ):
        logger.error(
            "unit (%r), aggr_type (%r), freq (%r) must be valid", unit, aggr_type, freq
        )
        return None
    else:
        # Determine start date:
        start_date = generate_date(date.iloc[0].year, freq)

        # Determine initial ABS_ACT series:
        # TODO [JHB]: shouldn't this be `historical_series.index < start_date`?
        act_series = historical_series[historical_series.index <= start_date]
        start_val = _aggregate(sum_last_values(act_series, 4), aggr_type)

        # Modify modelled series; i.e. subset per quarter and make sure that
        # the series starts at start date:
        _series_subset = subset_per_quarter(modelled_series, freq)
        _series_subset = _series_subset[_series_subset.index >= start_date]

        # Derive ABS series from modelled series:
        abs_series = inverse_transform(_series_subset, unit, start_val)
        abs_series = interpolate_series(abs_series, freq="Q")

        # Derive and return ABS_ACT series:
        act_series = derive_actual_series(abs_series, act_series, aggr_type)
        return act_series


# =============================================================================
# Small Private helper functions:
# =============================================================================


def _aggregate(val: float, aggr_type: str) -> float:  # pragma: no cover
    """Helper function to calculate value based on the aggregation type.

    :param val: value
    :param aggr_type: {"SUM", "AVG"}
    :return: value based on aggregation type
    """
    if aggr_type == "AVG":
        val *= 0.25
    return val


def _last_date(ts_lst: Sequence[pd.DataFrame]) -> pd.Timestamp:
    """Determine the earliest last observation of all series in input

    :param ts_lst: list of dataframe objects of which the last
      observation date is requested
    :return: Date of the earliest last observation date in the list of
      TimeSeries
    """
    date_lst = [ts["last_obs_date"].dropna().min() for ts in ts_lst]
    return min(date_lst)


def _start_year(ts_lst: Sequence[pd.DataFrame]) -> int:
    """Determine start year of extensions"""
    date_lst = [ts["start_year_extension"].dropna().min() for ts in ts_lst]
    return min(date_lst)
