# type: ignore[attr-defined]
# -*- coding: utf-8 -*-
"""

Implements operations that can be operated on (or with) series. Essentially,
this module contains of a collection of functions having Pandas series as
input (and output).

>> Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
>> Reference: https://pandas.pydata.org/pandas-docs/stable/timeseries.html
"""
import logging
from typing import Optional

import pandas as pd

from scenario_calculator.utility import FREQ_TO_QUARTER, count_quarters

_MY_EPSILON = 1e-12

logger = logging.getLogger(__name__)


def calculate_ratio(
    numerator: pd.Series, denominator: pd.Series, drop_na: bool = True
) -> pd.Series:
    """Divides the values of two series element-wise.

    :param numerator: numerator_series series
    :param denominator: denominator series
    :param drop_na: drop NA's (or not), default = True
    :return: series with quotient of numerator on denominator element-wise
    """
    # Replace zeros with Epsilon so we can calculate division by zero  We replace both
    # numerator denominator because the calculation is later done as ratio-1
    no_zeros_denominator = clean_series(denominator, cs_drop_na=False)
    no_zeros_numerator = clean_series(numerator, cs_drop_na=False)
    ratio = no_zeros_numerator / no_zeros_denominator
    if drop_na:
        ratio.dropna(inplace=True)
    return ratio


def calculate_change(series: pd.Series, lag: int = 1) -> pd.Series:
    """Calculates absolute change between two consecutive time series observations.

    :param series: original timeseries
    :param lag: lag of the observation relative to which the change is calculated.
      Default value is 1.
    :return: series - series.shift(lag), of which the first value is NaN.
    """
    return series - series.shift(lag)


def calculate_relative_change(
    series: pd.Series, lag: int = 1, drop_na: bool = False
) -> pd.Series:
    """Calculates relative change between two consecutive time series observations.

    :param series: original timeseries in ABS units
    :param lag: lag of the observation relative to which the change is
      calculated. Default value is 1.
    :param drop_na: drop NA's (or not)
    :return: series / series.shift(lag) – 1. The first [lag] values of the
      returned time series are NaN.
    """
    ratio = calculate_ratio(series, series.shift(lag), drop_na=drop_na)
    return ratio.sub(1)


def calculate_inverse_change(series: pd.Series, start_value: float) -> pd.Series:
    """Inverse of calculate_change function.

    :param series: original timeseries in Y-Y unit.
    :param start_value: start value of the new series in ABS unit.
    :return: time series computed by applying inverse of calculate_change
    """
    # Initialize fixed size array
    val = [start_value] * len(series)
    for i in range(1, len(series)):
        val[i] = val[i - 1] + series.iloc[i]
    result = pd.Series(val, series.index)
    return result


def calculate_inverse_relative_change(
    series: pd.Series, start_value: float
) -> pd.Series:
    """Inverse of calculate_relative_change function.

    :param series: original timeseries in YOY unit.
    :param start_value: start value of the series.
    :return: time series in ABS units, calculated from its YOY difference.
    """
    # Initialize fixed size array
    val = [start_value] * len(series)
    for i in range(1, len(series)):
        val[i] = val[i - 1] * (1 + series.iloc[i])
    result = pd.Series(val, series.index)
    return result


def standardize(series: pd.Series, mu: float, sigma: float) -> pd.Series:
    """Computes standardized values for time series.

    :param series: original timeseries
    :param mu: mean
    :param sigma: standard deviation
    :return: time series with standardized (z-scores) variables.
    """
    return series.sub(mu).truediv(sigma)


def calculate_real_interest_rate(
    three_month_interest_rate: pd.Series, price_deflator: pd.Series, lag: int = 4
) -> pd.Series:
    """Computes the real (3 month) interest rate.

    :param three_month_interest_rate: series containing nominal 3 month interest rates
    :param price_deflator: Pandas time series containing price deflator.
    :param lag: time lag (use 1 for yearly data, use 4 for quarterly data)
    :return: time series for real (3 month) interest rate. The first [lag] \
             values of the returned time series are NaN.
    """
    result = three_month_interest_rate - calculate_relative_change(price_deflator, lag)
    result = result.dropna()
    return result


def sample_to_yearly(
    series: pd.Series, aggr_type: str, freq: str = "A-DEC"
) -> pd.Series:
    """Aggregate to yearly data.

    :param series: original quarterly timeseries
    :param aggr_type: {"SUM", "AVG"}
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"},
      "A-DEC" if not provided
    :return: Pandas time series with yearly data
    """
    if aggr_type == "AVG":
        result = series.resample(freq).mean()
        result = result[result.index <= series.index[-1]]
    else:
        result = 4 * series.resample(freq).mean()
        result = result[result.index <= series.index[-1]]
    if freq == "A-DEC":
        return result
    else:
        return result[1:]


def sample_to_quarterly(series: pd.Series, aggr_type: str) -> pd.Series:
    """Aggregate yearly data (ABS) to quarterly data.

    :param series: original yearly timeseries
    :param aggr_type: {"SUM", "AVG"}
    :return: Pandas time series with quarterly data.
    """
    if aggr_type == "AVG":
        return series.resample("Q").bfill()
    else:
        return series.resample("Q").bfill() / 4


def subset_per_quarter(series: pd.Series, freq: str) -> Optional[pd.Series]:
    """Creates a subset of a pandas series with a datetime index on the quarter.

    :param series: original timeseries
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :raises KeyError:
    :return: Pandas time series data for a certain quarter.
    """
    try:
        quarter = FREQ_TO_QUARTER[freq]
    except KeyError as err:
        logger.error("%s", err, exc_info=True)
        raise
    else:
        return series[(series.index.quarter == quarter)]


def transform(series: pd.Series, trans_type: str) -> pd.Series:
    """Transform to YOY or Y-Y units.

    :param series: original timeseries
    :param trans_type: {"YOY", "Y-Y"}
    :return: Pandas time series transformed to YOY (or Y-Y).
    """
    if trans_type == "YOY":
        return calculate_relative_change(series)
    elif trans_type == "Y-Y":
        return calculate_change(series)
    return series


def inverse_transform(series: pd.Series, trans_type: str, start: float) -> pd.Series:
    """Transform from YOY (or Y-Y) to ABS unit.

    :param series: original timeseries
    :param trans_type: {"YOY", "Y-Y"}
    :param start: start value of the series
    :return: Pandas time series transformed to ABS.
    """
    if trans_type == "YOY":
        return calculate_inverse_relative_change(series, start)
    elif trans_type == "Y-Y":
        return calculate_inverse_change(series, start)
    return series


def interpolate_series(series: pd.Series, freq="Q") -> pd.Series:
    """Linearly interpolate missing values.

    :param series: original timeseries
    :param freq: frequency
    :return: interpolated Pandas time series
    """
    return series.resample(freq).interpolate()


def extrapolate_series(series: pd.Series) -> pd.Series:
    """Constantly extrapolate missing values.

    :param series: original timeseries
    :return: extrapolated Pandas time series
    """
    val, date = series[-1], series.index[-1] + pd.offsets.YearEnd()
    series[date] = val
    return interpolate_series(series)


def correct_series(series: pd.Series, code: str) -> pd.Series:
    """Perform checks on series and if needed correct 'problems'; log these.

    Issue logs on WARNING level for the problems detected.

    :param series: series (potentially with problems)
    :param code: time series code
    :return: corrected series
    """
    # Extra check to verify that series does not contain any
    # gaps. If the series contains gaps, the missing data is
    # linearly interpolated and a message is written to the LOGGER:
    if contains_gaps(series):
        logger.warning("Series contained gaps %s", code)
        series = interpolate_series(series)  # Apply correction!

    # Extra check to verify that series always end at Q4. If this is
    # not the case missing quarters are extrapolated and a message is
    # written to the LOGGER:
    if unexpected_last_date(series):
        logger.warning("Series not ending at Q4 %s", code)
        series = extrapolate_series(series)  # Apply correction!
    return series


def linear_combination(
    param1: float,
    param2: float,
    series1: pd.Series,
    series2: pd.Series,
    series3: pd.Series,
    series4: pd.Series,
) -> Optional[pd.Series]:
    """
    Returns the linear combination of four regressor series, a constant and
    an autoregressive term, given by:

    y[i] = a_1 + a_2*y[i-1] + b_1*x_1 + b_2*x_2 + b_3*x_3 + b_4*x_4.

    Input series need to contain the regressor, already multiplied by their
    respective coefficient.

    Returns `None` if the indeces of any of the given series is different from another.

    :param param1: constant coefficient
    :param param2: lag coefficient
    :param series1: timeseries1
    :param series2: timeseries2
    :param series3: timeseries3
    :param series4: timeseries4
    :raises ValueError:
    :return: linear combination of four time series or None
    """
    if (
        (series1.index == series2.index).all()
        and (series2.index == series3.index).all()
        and (series3.index == series4.index).all()
    ):
        # Apply model:
        val = [0] * len(series1.values)  # Init. fixed size array.
        x1 = series1.iloc[0]
        x2 = series2.iloc[0]
        x3 = series3.iloc[0]
        x4 = series4.iloc[0]
        val[0] = param1 + x1 + x2 + x3 + x4
        for i in range(1, len(series1.values)):
            x1 = series1.iloc[i]
            x2 = series2.iloc[i]
            x3 = series3.iloc[i]
            x4 = series4.iloc[i]
            val[i] = param1 + param2 * val[i - 1] + x1 + x2 + x3 + x4
        return pd.Series(val, series1.index)
    else:
        logger.warning("Series indices not equal")
        raise ValueError


def derive_actual_series(
    series1: pd.Series, series2: pd.Series, aggr_type: str = "AVG"
) -> pd.Series:
    """Derive a series with non-aggregated data from a series with aggregated data.

    :param series1: series with (yearly) aggregated data
    :param series2: series with (quarterly) actual data
    :param aggr_type: {"AVG", "SUM"}
    :return: updated series2
    """
    dates1 = series1.index
    dates2 = series2.index
    for date in dates1:
        if date not in dates2:  # Only update for new dates:
            val1 = series1[date]
            val2 = sum_last_values(series2, 3)
            series2[date] = value_based_on_aggr_type(val1, val2, aggr_type)
    return series2


def contains_gaps(series: pd.Series) -> bool:
    """Check whether series contains gaps.

    Please note that this function assumes the series are sorted year quarters.

    :param series: series with (yearly) aggregated data
    :return: True, False
    """
    date1 = series.index[0]  # Get first date of series.
    date2 = series.index[-1]  # Get last date of series.
    return not count_quarters(date1, date2) == len(series)


def clean_series(series: pd.Series, cs_drop_na: bool = True) -> pd.Series:
    """
    Zero values are set to eps << 1 to prevent problems with division by zero.

    Series could contain zeros and the calculator would otherwise be dividing by zero.
    One could of course make those algorithm resistant against zero's, and break the
    session to return an error value. However, by changing zeros to epsilon, it will
    allow to trace back to the original value when needed. Also will give a smooth
    graph, without any undefined values.
    If needed, the function also remove NA's from series attribute of TimeSeries object.

    :param series: series (potentially with NAs)
    :param cs_drop_na: drop NA's (or not), default = True for all cases except for
        calculate_ratio()
    :return: cleaned series
    """
    series = pd.to_numeric(series, errors="coerce")
    if cs_drop_na:
        series.dropna(inplace=True)
    return pd.to_numeric(series, errors="coerce").replace(0.0, _MY_EPSILON)


def sum_last_values(series: pd.Series, n: int) -> float:
    """Helper function to calculate sum of last n values of a series.

    :param series: timeseries
    :param n: number of values
    :return: sum of last n values
    """
    return sum(series[-n:].values)


def unexpected_last_date(series: pd.Series) -> bool:
    """Determine whether the last date is not a Q4 date.

    :param series: series (potentially not ending at Q4)
    :return: True if the last date is not Q4 (and False otherwise)
    """
    date = series.index[-1]  # get last date
    if date.quarter != 4:
        return True
    return False


# =============================================================================
# Helper functions:
# =============================================================================


def value_based_on_aggr_type(val1: float, val2: float, aggr_type: str = "AVG") -> float:
    """Helper function needed to find new actual value.

    :param val1: first value
    :param val2: second value
    :param aggr_type: aggregation type (values: "AVG" or "SUM"; "AVG" if not provided)
    :return: either (4 * val1 - val2) or (val1 - val2)
    """
    if aggr_type == "AVG":
        return 4 * val1 - val2
    return val1 - val2
