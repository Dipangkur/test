"""Settings for this application."""

import tempfile
from pathlib import Path

TEMP_DIR = Path(tempfile.gettempdir())


class Settings:
    PY_SRC_ROOT = Path(__file__).resolve().parents[1]
    # The forward slash can join several paths or a mix of paths and strings
    # as long as there is at least one Path object.
    INPUT_DATA_DIR = PY_SRC_ROOT / "scenario_calculator" / "data"
    STATIC_DATA_DIR = INPUT_DATA_DIR / "static"
    # TODO: once we implement the cloud we can remove the mock
    MOCK_CLOUD_DIR = INPUT_DATA_DIR / "dynamic"
    DATA_OUT_DIR = TEMP_DIR / "meister_calc_output"

    # To test the static data
    SCENARIO_TYPES = [
        "Baseline",
        "Minus",
        "Plus",
        "ICAAP Baseline",
        "ICAAP Adverse",
        "MY ST Baseline",
        "MY ST Adverse",
        "Adverse",
    ]

    # A dict. we use to give the right name for each static data csv file
    STANDARD_FILE_MAPPING = {
        "agriland_org": "static_agriland_params.csv",
        "extension": "static_arima_params.csv",
        "standardization": "static_standardization_params.csv",
        "variables": "static_macroeconomic_variable.csv",
        "nbrof_years_extension": "static_end_year_extension.csv",
        "missing_series_mapping": "static_series_mapping.csv",
        "missing_countries_mapping": "static_country_mapping.csv",
        "regression_modelling": "static_regression_params.csv",
        "model_info": "static_model_info.csv",
        "other_country_euro_countries": "static_euro_countries.csv",
        "other_country_price_variables": "static_price_variables.csv",
        "other_country_start_year": "static_start_year.csv",
        "other_country_weights": "static_weights.csv",
    }
