# type: ignore[attr-defined]
"""Code specific for processing request from Rest API calls."""
import logging
import os
import threading
from datetime import datetime
from pathlib import Path
from typing import Tuple

import connexion
import flask
from applicationinsights.flask.ext import AppInsights

from scenario_calculator import __version__
from scenario_calculator.aliases import MainReturnType
from scenario_calculator.calculator import calculate
from scenario_calculator.config import GeneralConfig, RunDefinition, RunParams
from scenario_calculator.constants import (
    APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME,
    EXIT_OK,
)
from scenario_calculator.io.base_reader import URL_SCHEME_FILE
from scenario_calculator.io.file_reader import FileReader
from scenario_calculator.utility import swagger_model_to_repr
from swagger_server import encoder
from swagger_server.models import (
    AcceptedCalculateScenario,
    JobDefinition,
    JobParams,
    JobParamsAndJobDefinition,
    PingResponse,
)

# TODO [JHB]: think of how to unit-test this file, excluded for now

HTTP_OK = 200
HTTP_ACCEPTED = 202
_MSR_GENERAL_CFG_NAME = "MSR_GENERAL_CONFIG"
_MSR_API_STARTED_NAME = "MSR_API_STARTED"
_ASYNC_MODE = True

_log = logging.getLogger(__name__)


def start_api(general_config: GeneralConfig, port: int) -> MainReturnType:
    """Start the REST API.

    :param general_config: General configuration.
    :param port: the port number to listen to.
    :return: None
    """
    _log.debug(
        "starting the api, pid: %d, mode: %s",
        os.getpid(),
        "ASYNCHRONOUS" if _ASYNC_MODE else "SYNCHRONOUS",
    )
    app = connexion.App(
        __name__,
        specification_dir=(
            Path(__file__)
            # travel back to the 'src' directory
            .parents[1]
            / "swagger_server"
            / "swagger"
        ),
    )
    app.app.json_encoder = encoder.JSONEncoder
    app.add_api(Path("swagger.yaml"), arguments={"title": "Meister Scenario Creator"})
    # Pass on the general_config to the start_create() handler
    app.app.config[_MSR_GENERAL_CFG_NAME] = general_config
    app.app.config[_MSR_API_STARTED_NAME] = datetime.utcnow()
    appinsights_instrumentation_key = general_config.appinsights_instrumentation_key
    if appinsights_instrumentation_key is not None:
        app.app.config[
            APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME
        ] = appinsights_instrumentation_key
        appinsights = AppInsights(app.app)
    else:
        appinsights = None
    app.run(port=port)
    del appinsights
    return EXIT_OK


def _calculate_scenario_task(
    job_params: JobParams,
    job_definition: JobDefinition,
    general_config: GeneralConfig,
    current_datetime: datetime,
) -> None:
    """Main kickoff of calculate scenario functionality, run as a thread-task.

    :param job_params: The (partially secret) parameters for this job
    :param job_definition: The specific parameters, combined unique for the job
    :param general_config: General configuration options
    :param current_datetime: the date and time this jobs started
    :raises AssertionError: an internal inconsistency occurred
    :raises KeyboardInterrupt: keyboard interrupt in the underlying functions occurred
      (caught, logged and re-raised)
    :raises Exception: some exception in the underlying functions occurred
      (caught, logged and re-raised)
    """
    thread_name = threading.current_thread().name
    try:
        _log.debug("_calculate_scenario_task (%s) started", thread_name)
        # Convert the swagger-generated model parameters into own-defined ones
        raw_scenario_input_url_str = (
            event_logger_url_str
        ) = job_params.raw_scenario_sql_connection_url
        if event_logger_url_str.startswith(URL_SCHEME_FILE):
            # This allows for specifying a file as dynamic input
            event_logger_url_str = None
        scenario_output_url_str = job_params.scenario_sql_connection_url
        blob_storage_account_key = job_params.blob_storage_account_key
        FileReader.set_account_key(job_params.blob_storage_account_key)
        run_params = RunParams(
            raw_scenario_input_url_str=raw_scenario_input_url_str,
            scenario_output_url_str=scenario_output_url_str,
            blob_storage_account_key=blob_storage_account_key,
            event_logger_url_str=event_logger_url_str,
        )
        # RunDefinition has the same attribute names as JobDefinition has
        run_definition = RunDefinition(
            **job_definition.to_dict(), current_datetime=current_datetime
        )  # type: ignore
        result = calculate(general_config, run_params, run_definition)
        if result not in {None, 0}:
            # This is a "should not happen" situation, so an AssertionError
            #   seems to be a rightful choice.
            raise AssertionError(f"calculate() returned error: {result!r}")
        _log.debug("_calculate_scenario_task (%s) normal exit", thread_name)
    except (KeyboardInterrupt, RuntimeError):
        _log.exception("_calculate_scenario_task (%s) exception", thread_name)
        raise


def handle_post_start_calculate_scenario(
    job_params_and_job_definition: JobParamsAndJobDefinition,
) -> Tuple[AcceptedCalculateScenario, int]:
    """Actual 'Start calculate scenario' POST controller.

    :param job_params_and_job_definition:
      The (job) configuration and definition(s) for the scenario(s)
    :return: An AcceptedCalculateScenario instance and http return code.
    """
    job_params = job_params_and_job_definition.job_params
    # NOTE: DO NOT log job_params, it contains secret information
    job_definition = job_params_and_job_definition.job_definition
    _log.info("api request: Job Definition: %s", swagger_model_to_repr(job_definition))
    app = flask.current_app
    # Pick up the general configuration items
    general_config: GeneralConfig = app.config[_MSR_GENERAL_CFG_NAME]
    _log.debug("api request: General Config: %s", general_config)
    current_datetime = datetime.utcnow()
    task_args: Tuple[JobParams, JobDefinition, GeneralConfig, datetime] = (
        job_params,
        job_definition,
        general_config,
        current_datetime,
    )
    accepted_calculate_scenario = AcceptedCalculateScenario(
        __version__.__version__, job_definition.event_id, current_datetime
    )
    if _ASYNC_MODE:
        thread = threading.Thread(
            target=_calculate_scenario_task,
            name=f"parent_id-{job_definition.event_id:d}",
            args=task_args,
            daemon=True,
        )
        thread.start()
        _log.debug(
            "Thread %s (%r) created and started, API handler returning 202",
            thread.ident,
            thread.name,
        )
        return accepted_calculate_scenario, HTTP_ACCEPTED

    # Not _ASYNC_MODE, hence synchronous mode
    _calculate_scenario_task(*task_args)
    return accepted_calculate_scenario, HTTP_OK


def handle_get_ping() -> Tuple[PingResponse, int]:
    """Actual implementation of the 'Ping' GET controller.

    :return: The filled ping request and http return code.
    """
    app = flask.current_app
    api_started: datetime = app.config[_MSR_API_STARTED_NAME]
    datetime_now = datetime.utcnow()
    resp = PingResponse(
        __version__.__version__ + f" (Build {__version__.__build__})",
        "Uptime {!s}".format(datetime_now - api_started),
    )
    # TODO: show this process' open fds, memory, wall/user/sys time (psutil)
    return resp, HTTP_OK
