# type: ignore[attr-defined]
# -*- coding: utf-8 -*-
"""

Main module for this project. Essentially, various logical sequential steps
are taken. The final output is written to SIS SBV compliant flat-files. It is
also possible to write data to the database. However, this is currently
not recommended due to performance issues.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""
import gc
import logging
import re
from contextlib import closing, nullcontext
from typing import Any, ContextManager, List, Mapping, NamedTuple, Optional, Tuple

import pandas as pd
from sqlalchemy.engine.url import make_url

import scenario_calculator.io.csvwriter
from scenario_calculator.aliases import MainReturnType
from scenario_calculator.config import GeneralConfig, RunDefinition, RunParams
from scenario_calculator.constants import EXIT_OK, GBV_PART
from scenario_calculator.event_logger import EventLogger
from scenario_calculator.events import (
    ADD_MISSING_RXEU_VALUES_EVENT,
    AGGREGATION_TO_YEARLY_ABS_DATA_EVENT,
    APPLY_AGRILAND_MODEL_EVENT,
    APPLY_REGRESSION_MODELLING_EVENT,
    CALCULATE_AND_APPEND_OTHER_COUNTRY_EVENT,
    CALCULATE_LAB_SCENARIO_EVENT,
    CALCULATE_SCENARIO_EVENT,
    COMBINE_TRANSFORMED_AGGREGATED_DATA_EVENT,
    CONVERT_UNIT_OF_SERIES_EVENT,
    DERIVE_NEW_SERIES_EVENT,
    EXTEND_TIME_SERIES_EVENT,
    LAST_EVENT,
    MAKE_READY_TO_WRITE_EVENT,
    MAKE_THE_FIRST_EXTENSION_EVENT,
    MAP_MISSING_COUNTRIES_EVENT,
    MAP_MISSING_SERIES_EVENT,
    RETRIEVE_INPUT_DATA_EVENT,
    SET_STANDARDIZATION_PARAMETER_EVENT,
    TRANSFORM_FROM_ABS_TO_YOY_DELTA_Y_EVENT,
    WRITE_OUTPUT_EVENT,
)
from scenario_calculator.io.base_reader import URL_SCHEME_FILE, sqlalch_url2path
from scenario_calculator.io.db_writer import write_output_to_db
from scenario_calculator.io.reader import (
    OneValuedInputData,
    calculate_and_append_other_country,
    make_the_first_extension,
    read_dynamic_and_static_data,
)
from scenario_calculator.modelling.agriland import apply_agriland_model
from scenario_calculator.modelling.enrichment import (
    add_transformed_series,
    aggregate_series,
    convert_series,
    create_quarterly_subset,
    derive_new_series,
    drop_extra_columns,
    map_missing_countries,
    map_missing_series,
    set_standardization_params,
    set_value_and_date_index,
)
from scenario_calculator.modelling.regression import apply_model
from scenario_calculator.other_country import add_missing_rxeu_values
from scenario_calculator.processing import extend_time_series
from scenario_calculator.settings import Settings
from scenario_calculator.thread_teeing_logging_handler import ThreadTeeingLoggingHandler
from scenario_calculator.utility import (
    clean_list,
    get_named_tuple_fields,
    get_observation_type,
    standardize,
    time_context,
)

_log = logging.getLogger(__name__)

# Globals
QUARTERS = ("A-MAR", "A-JUN", "A-SEP", "A-DEC")


class InputData(NamedTuple):
    """Holds all relevant input data.

    | The following attribute instance variables are defined:
    | extension_df the extention dataframe
    | missing_series_mapping_df the missing series mapping dataframe
    | missing_countries_mapping_df the missing series countries dataframe
    | regression_modelling_df the regression modelling dataframe
    | standardization_df the standardization dataframe
    | model_info_df the model information dataframe
    | variables_df the macroeconomic variables dataframe
    | other_country_euro_countries_df other country euro countries dataframe
    | other_country_price_variables_df other country prices dataframe
    | other_country_start_year_df the other country start years dataframe
    | other_country_weights_df the other country weights dataframe
    | one_valued_input_data a namedtuple of basic info of the scenario
    """

    extension_df: pd.DataFrame
    missing_series_mapping_df: pd.DataFrame
    missing_countries_mapping_df: pd.DataFrame
    regression_modelling_df: pd.DataFrame
    standardization_df: pd.DataFrame
    model_info_df: pd.DataFrame
    variables_df: pd.DataFrame
    other_country_euro_countries_df: pd.DataFrame
    other_country_price_variables_df: pd.DataFrame
    other_country_start_year_df: pd.DataFrame
    other_country_weights_df: pd.DataFrame
    one_valued_input_data: OneValuedInputData


def _read_dynamic_and_static_data(
    input_batch_size, raw_scenario_input_url_str, run_definition
):
    # Read data from database tables / csv files needed to
    # start the calculations.
    dynamic_df, reporting_date, static_data_dict = read_dynamic_and_static_data(
        input_batch_size,
        Settings.STANDARD_FILE_MAPPING,
        Settings.STATIC_DATA_DIR,
        raw_scenario_input_url_str,
        run_definition,
    )

    return dynamic_df, reporting_date, static_data_dict


def _apply_agriland_model(dynamic_df, static_data_dict, reporting_date):
    return apply_agriland_model(dynamic_df, static_data_dict, reporting_date)


def _add_missing_rxeu_values(dynamic_df):
    dynamic_df = add_missing_rxeu_values(dynamic_df)
    return dynamic_df


def _calculate_and_append_other_country(dynamic_df, static_data_dict):
    dynamic_df, oc_appended_dynamic_df = calculate_and_append_other_country(
        dynamic_df, static_data_dict
    )
    return dynamic_df, oc_appended_dynamic_df


def _make_the_first_extension(
    dynamic_df, oc_appended_dynamic_df, reporting_date, run_definition, static_data_dict
):
    read_and_extended_input_data_with_other_country = make_the_first_extension(
        dynamic_df,
        oc_appended_dynamic_df,
        reporting_date,
        run_definition,
        static_data_dict,
    )
    frames = read_and_extended_input_data_with_other_country.frames
    return frames, read_and_extended_input_data_with_other_country


def _arrange_input_data_from_frames(
    frames, read_and_extended_input_data_with_other_country
):
    # only select those dataframes that can be stored in the InputData
    kwargs = {
        kw + "_df": arg
        for kw, arg in frames.items()
        if kw + "_df" in get_named_tuple_fields(InputData)
    }
    _log.debug(
        "Dropping the following frames: %s",
        {key + "_df" for key in frames.keys()} - kwargs.keys(),
    )
    # subsequently add the other (non-dataframe) value to it
    kwargs[
        "one_valued_input_data"
    ] = read_and_extended_input_data_with_other_country.one_valued_input_data
    return InputData(**kwargs)


def _calc_extend_time_series(
    df_extension: pd.DataFrame, end_year_extension: int, frequency: str
) -> pd.DataFrame:
    """Create a dictionary of Extended Timeseries, for each scenario found.

    Pls. refer to ``scenario_calculator.processing.extend_time_series()``
    for a more elaborate description of the functionality.

    :param df_extension: input dataframe containing all time series data
    :param end_year_extension: end year of extension
    :param frequency: frequency
    :return: a dict of extended timeseries
    """
    with time_context("[2] Extending TimeSeries"):
        # Compute extended series:
        scenarios_df = extend_time_series(df_extension, end_year_extension, frequency)
        return scenarios_df


def _calc_convert_unit_of_series(scenarios_df: pd.DataFrame) -> pd.DataFrame:
    with time_context("[3] Converting unit of series"):
        # Convert the unit of certain series:
        scenarios_df = convert_series(scenarios_df)
        return scenarios_df


def _calc_derive_new_series(
    df_extension: pd.DataFrame, df_variables: pd.DataFrame, scenarios_df: pd.DataFrame
) -> pd.DataFrame:
    """Add derived new series and new macro-economic variables to Scenarios DataFrame.

    For each unique country in the 'nigem_country_code' in the extension
    data frame, derive new series based on the time series in the extension
    data frame derive additional macro-economic variables.

    See ``enrichment.derive_new_series()`` for a more elaborate explanation.
    TODO [JHB] - add better description (needs deeper understanding)

    :param df_extension: Defining the extension data.
    :param df_variables: Defining the macroeconomic variables.
    :param scenarios_df: the DataFrame of extended timeseries
    :return: DataFrame of extended timeseries
    """
    with time_context("[4] Deriving new series"):
        # Compute derived series (based on existing ones):
        countries = df_extension["nigem_country_code"].unique()
        countries_list: List[str] = clean_list(countries)
        return derive_new_series(df_variables, countries_list, scenarios_df)


def _calc_apply_regression_modelling(
    df_regression_modelling: pd.DataFrame, df_scenarios: pd.DataFrame, frequency: str
) -> pd.DataFrame:
    with time_context("[5] Applying regression modelling"):
        # Apply regression modelling to derive new series:
        return apply_model(df_scenarios, df_regression_modelling, frequency)


def _calc_aggregation_to_yearly_abs_data(
    df_scenarios: pd.DataFrame,
) -> List[pd.DataFrame]:
    with time_context("[6] Aggregation to yearly ABS data"):
        # Convert quarterly data to yearly data:
        df_scenarios_quarterly = [
            aggregate_series(df_scenarios, quarter) for quarter in QUARTERS
        ]
        return df_scenarios_quarterly


def _calc_transform_from_abs_to_yoy_and_deltay(
    df_scenarios_quarterly: pd.DataFrame,
) -> List[pd.DataFrame]:
    with time_context("[7] Transforming from ABS to YOY and Y-Y"):
        # Transform to YOY and Y-Y (yearly) data:
        df_scenarios_quarterly = (
            add_transformed_series(df_quarter) for df_quarter in df_scenarios_quarterly
        )

        return df_scenarios_quarterly


def _calc_combine_transformed_aggregated_data(
    scenarios: pd.DataFrame, scenarios_quarterly: List[pd.DataFrame]
) -> List[pd.DataFrame]:
    with time_context("[8] Combining transformed-aggregated data"):
        # Combine original (extended) scenario data with computed
        # scenario data:
        # make subsets a generator comprehension instead of list comprehension
        #  ('()' vs. '[]')
        df_subsets_quarterly = (
            create_quarterly_subset(scenarios, quarter) for quarter in QUARTERS
        )
        scenarios_quarterly = (  # type: ignore # noqa
            pd.concat([df_quarterly_scenario, subset])
            for df_quarterly_scenario, subset in zip(
                scenarios_quarterly, df_subsets_quarterly
            )
        )
        return scenarios_quarterly


def _calc_set_standardization_parameter(
    df_standardization: pd.DataFrame, scenarios_quarterly: pd.DataFrame
) -> Any:
    with time_context("[9] Setting standardization parameter"):
        # Set standardization parameters:
        df_scenarios_quarterly = (
            set_standardization_params(quarterly_scenario, df_standardization)
            for quarterly_scenario in scenarios_quarterly
        )
        return df_scenarios_quarterly


def _calc_map_missing_series(
    df_missing_series_mapping: pd.DataFrame, df_scenarios_quarterly: Any
) -> Any:
    with time_context("[10] Mapping missing series"):
        # # Map missing series to existing series. The
        # # mapped series are added to the existing dataframe:

        df_scenarios_quarterly = (
            map_missing_series(df_missing_series_mapping, df_quarterly_scenario)
            for df_quarterly_scenario in df_scenarios_quarterly
        )
        return df_scenarios_quarterly


def _calc_map_missing_countries(
    df_missing_countries_mapping: pd.DataFrame, df_scenarios_quarterly: Any,
) -> Any:
    with time_context("[11] Mapping missing countries"):
        df_scenarios_quarterly = (
            map_missing_countries(df_missing_countries_mapping, df_quarterly_scenario)
            for df_quarterly_scenario in df_scenarios_quarterly
        )

        return df_scenarios_quarterly


def _make_ready_to_write_timeseries(
    df_scenarios_quarterly: Any, scenario_start_date
) -> Any:
    with time_context("[12.1] Set value and date index"):
        # Get value and the date index
        df_scenarios_quarterly = (
            set_value_and_date_index(df_quarterly_scenario)
            for df_quarterly_scenario in df_scenarios_quarterly
        )

    with time_context("[12.2] Get observation type"):
        # Get observation type
        df_scenarios_quarterly = (
            get_observation_type(df_quarterly_scenario, scenario_start_date)
            for df_quarterly_scenario in df_scenarios_quarterly
        )
    with time_context("[12.3] Drop extra columns"):
        # Drop extra columns
        df_scenarios_quarterly = (
            drop_extra_columns(df_quarterly_scenario)
            for df_quarterly_scenario in df_scenarios_quarterly
        )
    with time_context("[12.4] Set standardize values"):
        # Standardize the values
        df_scenarios_quarterly = (
            standardize(df_quarterly_scenario)
            for df_quarterly_scenario in df_scenarios_quarterly
        )

    return df_scenarios_quarterly


def _calc_write_output(
    scenario_output_url_str: str,
    output_batch_size: Optional[int],
    mapped_scenarios_quarterly: list,
    scenario_info: OneValuedInputData,
) -> int:
    """Write out all the calculated scenario.

    :param scenario_output_url_str: Specifies where to write the output to.
      Can either be an URL with 'file' as the scheme-part, or an SqlAlchemy-
      compatible URL
    :param output_batch_size: the number of output records to collect in one chunk
    :param mapped_scenarios_quarterly: The list of quarterly mapped scenarios
    :param scenario_info:  Namedtuple with the info of the quarterly scenarios
    :param current_datetime: The actual datetime the calculator started the calculation
    :param scenario_start_date: Scenario start date, retrieved from dynamic df
    :return: the id of this scenario, or 0 when written to csv-file
    """
    with time_context("[13] Writing output"):
        # Write GBV and SBV output to flat files. For debug-mode only
        # EOY (Q4) data is writen to file:
        # # output list:
        scenario_out_url = make_url(scenario_output_url_str)
        scheme = scenario_out_url.drivername
        if scheme == URL_SCHEME_FILE:
            path_gbv = sqlalch_url2path(scenario_out_url)
            basename_gbv = path_gbv.name
            output_dir = path_gbv.parent
            # create the file base name for the scenario_info_dict
            basename_si = re.sub(re.escape(GBV_PART), "_SCENARIO_INFO", basename_gbv, 1)
            scenario_calculator.io.csvwriter.write_output_to_csv(
                basename_gbv,
                basename_si,
                mapped_scenarios_quarterly,
                scenario_info,
                output_dir,
            )
            return 0
        # No "file"-scheme, hence it must be an SqlAlchemy db URL.
        return write_output_to_db(
            scenario_output_url_str,
            output_batch_size,
            mapped_scenarios_quarterly,
            scenario_info,
        )


def calculate(
    general_config: GeneralConfig, run_params: RunParams, run_definition: RunDefinition
) -> MainReturnType:
    """Implements the scenario generation pipeline.

    First the input data is read from an external data source.
    Next, time series are extended and data enrichment is performed.
    Finally, SBV compliant output is produced.

    :param general_config: contains more static-like configuration
    :param run_params: contains parameters that *could* be valid for more
      than one run
    :param run_definition: parameters only valid for this particular run
    :return:
    """
    _log.debug("Instantiating EventLogger")
    event_data_dict = {
        "ScenarioName": run_definition.scenario_name,
        "CreationDate": run_definition.current_datetime,
    }
    logging_ctx_mgr, logging_info_dict = _handle_optional_logging_to_major_event(
        general_config.thread_teeing_logging_handler
    )
    event_data_dict.update(logging_info_dict)
    event_logger = EventLogger(
        run_params.event_logger_url_str, run_definition.event_id, event_data_dict
    )
    with closing(event_logger):
        try:
            with event_logger.log_event(
                CALCULATE_SCENARIO_EVENT
            ) if run_definition.is_lab is False else event_logger.log_event(
                CALCULATE_LAB_SCENARIO_EVENT
            ), logging_ctx_mgr:
                # fmt: off
                with event_logger.log_event(RETRIEVE_INPUT_DATA_EVENT):
                    dynamic_df, reporting_date, static_data_dict = \
                        _read_dynamic_and_static_data(
                            general_config.input_batch_size,
                            run_params.raw_scenario_input_url_str,
                            run_definition,
                        )

                with event_logger.log_event(APPLY_AGRILAND_MODEL_EVENT):
                    _, dynamic_df, static_data_dict = \
                        _apply_agriland_model(
                            dynamic_df,
                            static_data_dict,
                            reporting_date
                        )

                with event_logger.log_event(ADD_MISSING_RXEU_VALUES_EVENT):
                    dynamic_df = _add_missing_rxeu_values(dynamic_df)

                with event_logger.log_event(CALCULATE_AND_APPEND_OTHER_COUNTRY_EVENT):
                    dynamic_df, oc_appended_dynamic_df = \
                        _calculate_and_append_other_country(
                            dynamic_df, static_data_dict
                        )

                with event_logger.log_event(MAKE_THE_FIRST_EXTENSION_EVENT):
                    frames, read_and_extended_input_data_with_other_country = \
                        _make_the_first_extension(
                            dynamic_df,
                            oc_appended_dynamic_df,
                            reporting_date,
                            run_definition,
                            static_data_dict,
                        )
                    input_data = _arrange_input_data_from_frames(
                        frames, read_and_extended_input_data_with_other_country
                    )
                # fmt: on
                with event_logger.log_event(EXTEND_TIME_SERIES_EVENT):
                    scenarios_df = _calc_extend_time_series(
                        input_data.extension_df,
                        input_data.one_valued_input_data.end_year_extension,
                        input_data.one_valued_input_data.frequency,
                    )

                with event_logger.log_event(CONVERT_UNIT_OF_SERIES_EVENT):
                    scenarios_df = _calc_convert_unit_of_series(scenarios_df)

                with event_logger.log_event(DERIVE_NEW_SERIES_EVENT):
                    scenarios_df = _calc_derive_new_series(
                        input_data.extension_df, input_data.variables_df, scenarios_df,
                    )

                with event_logger.log_event(APPLY_REGRESSION_MODELLING_EVENT):
                    scenarios_df = _calc_apply_regression_modelling(
                        input_data.regression_modelling_df,
                        scenarios_df,
                        input_data.one_valued_input_data.frequency,
                    )

                with event_logger.log_event(AGGREGATION_TO_YEARLY_ABS_DATA_EVENT):
                    df_scenarios_quarterly = _calc_aggregation_to_yearly_abs_data(
                        scenarios_df
                    )

                with event_logger.log_event(TRANSFORM_FROM_ABS_TO_YOY_DELTA_Y_EVENT):
                    df_scenarios_quarterly = _calc_transform_from_abs_to_yoy_and_deltay(
                        df_scenarios_quarterly
                    )

                with event_logger.log_event(COMBINE_TRANSFORMED_AGGREGATED_DATA_EVENT):
                    df_scenarios_quarterly = _calc_combine_transformed_aggregated_data(
                        scenarios_df, df_scenarios_quarterly
                    )

                with event_logger.log_event(SET_STANDARDIZATION_PARAMETER_EVENT):
                    df_scenarios_quarterly = _calc_set_standardization_parameter(
                        input_data.standardization_df, df_scenarios_quarterly
                    )

                with event_logger.log_event(MAP_MISSING_SERIES_EVENT):
                    df_scenarios_quarterly = _calc_map_missing_series(
                        input_data.missing_series_mapping_df, df_scenarios_quarterly
                    )

                with event_logger.log_event(MAP_MISSING_COUNTRIES_EVENT):
                    df_mapped_scenarios_quarterly = _calc_map_missing_countries(
                        input_data.missing_countries_mapping_df, df_scenarios_quarterly
                    )

                with event_logger.log_event(MAKE_READY_TO_WRITE_EVENT):
                    df_mapped_scenarios_quarterly = _make_ready_to_write_timeseries(
                        df_mapped_scenarios_quarterly,
                        input_data.one_valued_input_data.scenario_start_date,
                    )

                with event_logger.log_event(WRITE_OUTPUT_EVENT):
                    scenario_id = _calc_write_output(
                        run_params.scenario_output_url_str,
                        general_config.output_batch_size,
                        df_mapped_scenarios_quarterly,
                        input_data.one_valued_input_data,
                    )

                # Add the scenario id just before the successful event is written out
                event_logger.event_data_dict.update({"ScenarioId": scenario_id})

        finally:
            with event_logger.log_event(LAST_EVENT):
                # If we only have written our event logs to an in-core database,
                # then dump the events to the logger
                if run_params.event_logger_url_str is None:
                    event_logger.dump_to_log(logging.DEBUG)
                gc.collect()
    return EXIT_OK


def _handle_optional_logging_to_major_event(
    thread_teeing_handler: Optional[ThreadTeeingLoggingHandler],
) -> Tuple[ContextManager[None], Mapping[str, Any]]:
    """Maybe setup context manager and info dict to tailor for logging to major event.

    If no ThreadTeeingLoggingHandler is installed (i.e. the passed parameter is None),
    a dummy context and an empty dict are returned; otherwise a context enabling the
    actual logging and additional information items in a dictionary are returned.

    :param thread_teeing_handler: contains more static-like configuration; used
    :return: a context manager and an logging information dict
    """
    if thread_teeing_handler is None:
        _log.info("Log renderings are *not* duplicated to Major EventLog record")
        logging_ctx_mgr = nullcontext()
        logging_info_dict = {}
    else:
        log_lines: List[str] = []
        log_level_threshold = logging.NOTSET  # could be set in the RunDefinition
        effective_level = max(log_level_threshold, thread_teeing_handler.level)
        _log.info(
            "Log renderings are duplicated to Major EventLog record"
            " from (effectively) level %s and higher",
            logging.getLevelName(effective_level),
        )
        logging_ctx_mgr = thread_teeing_handler.capture_log_lines_for_current_thread(
            log_lines.append, log_level_threshold
        )
        logging_info_dict = {
            "LogLevelThreshold": logging.getLevelName(effective_level),
            "Logging": log_lines,
        }
    return logging_ctx_mgr, logging_info_dict
