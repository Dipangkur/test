# -*- coding: utf-8 -*-
# type: ignore

"""
Module for Other/Global Country Functionality

As a part of new country mapping method, a new module is added as OTHER factor/country,
which represents the global economy. The module mainly exists of two logical phases as
data preparation and calculation. In the data preparation phase the extension_df is
manipulated within three steps: truncation according to the date, applying conversion
factor and converting the currencies. In the calculation phase the other country is
created by using the country weights for all MEVs. After the calculation the calculator
runs with the new country mapping and with the original dataframes/MEV values.

Reference: 20190719 MES country mapping - OTHER factor_v0.2
"""
import datetime
from typing import Any, List, Optional

import pandas as pd

from scenario_calculator.constants import DEFAULT_DATA_FREQ, OC_CONSTANT_YEAR
from scenario_calculator.utility import (
    extend_dynamic_df_columns,
    remove_columns,
    time_context,
)


# TODO [AB] fix "error: "None" not callable" from mypy comes from the decorator and the
#  functions when the decorator is used
def pass_if_first_arg_is_none_or_empty(func: Any) -> Optional[Any]:
    """ Return None or Empty first argument of the function if it is None or Empty

    Decorator for the first argument check.

    @:param func: function itself to be decorated
    @:return: None or first argument of the function
    """

    def inner1(first_arg: pd.DataFrame, *args, **kwargs):
        if first_arg is None or first_arg.empty:
            return first_arg
        return func(first_arg, *args, **kwargs)

    return inner1


@pass_if_first_arg_is_none_or_empty
def add_missing_rxeu_values(dynamic_df: pd.DataFrame) -> pd.DataFrame:
    """ Add exceptional RXEU values for Indonesia and USA

     dynamic_df will be updated as USRXEU = ELRX and IDRXEU = USRXEU / IDRX
    :param dynamic_df: pd.DataFrame having the raw dynamic_df
    :return: dynamic_df: pd.DataFrame with USRXEU and IDRXEU values, without ELRX and
    IDRX

    :raises KeyError: time_series_code
    """
    with time_context("[1.2] Adding missing rxeu values"):
        if not set(["time_series_code"]).issubset(set(dynamic_df.columns)):
            error_message = "time_series_code column does not exist"
            raise KeyError(error_message)

        _convert_elrx_to_usrxeu(dynamic_df)
        usrxeu_df = _create_usrxeu_df(dynamic_df)
        dynamic_df = dynamic_df.merge(usrxeu_df, on=["period"], how="left")
        _calculate_idrxeu(dynamic_df)

    return remove_columns(dynamic_df, ["usrxeu"])


@pass_if_first_arg_is_none_or_empty
def _calculate_idrxeu(dynamic_df: pd.DataFrame):
    """ Calculate IDRXEU variable inplace

     Converts IDRX values into IDRXEU values after calculating it with USRXEU

    :param dynamic_df: pd.DataFrame having the raw dynamic_df
    IDRX
    """

    dynamic_df.loc[dynamic_df["time_series_code"] == "IDRX", "value"] = (
        dynamic_df["usrxeu"] / dynamic_df["value"]
    )
    dynamic_df.loc[
        dynamic_df["time_series_code"] == "IDRX", "time_series_code"
    ] = "IDRXEU"


@pass_if_first_arg_is_none_or_empty
def _create_usrxeu_df(dynamic_df: pd.DataFrame) -> pd.DataFrame:
    """ Create usrxeu_df from dynamic_df

    Extracts the USRXEU values from the dynamic_df and returns a new DataFrame
    containing the USRXEU values for each period

    :param dynamic_df: pd.DataFrame having the raw dynamic_df
    IDRX
    :return: dataframe
    """

    usrxeu_df = dynamic_df[dynamic_df["time_series_code"] == "USRXEU"][
        ["period", "value"]
    ]
    usrxeu_df.rename(columns={"value": "usrxeu"}, inplace=True)
    return usrxeu_df


@pass_if_first_arg_is_none_or_empty
def _convert_elrx_to_usrxeu(dynamic_df: pd.DataFrame):
    """ Convert elrx values to usrxeu values in dynamic_df

    Changes all ELRX time_seris_code values to USRXEU

    :param dynamic_df: pd.DataFrame having the raw dynamic_df
    IDRX
    """
    dynamic_df.loc[dynamic_df["time_series_code"] == "ELRX", "value"] = dynamic_df[
        "value"
    ]
    dynamic_df.loc[
        dynamic_df["time_series_code"] == "ELRX", "time_series_code"
    ] = "USRXEU"


@pass_if_first_arg_is_none_or_empty
def truncate_dynamic_df(
    dynamic_df: pd.DataFrame, start_years_df: pd.DataFrame
) -> pd.DataFrame:
    """Truncate extension_df according to the start year of the countries

    Filters the extension_df from the data which is older than the start year for each
    corresponding country

    :param dynamic_df: The input DataFrame in Raw Scenario Time Series structure
    :param start_years_df: DataFrame that keeps country/starting year pairs
    :return: truncated_extension_df: Filtered dynamic data frame
    """

    dynamic_df = extend_dynamic_df_columns(dynamic_df)

    merged_dynamic_df = dynamic_df.merge(
        start_years_df, on="nigem_country_code", how="left"
    )

    return remove_columns(
        merged_dynamic_df[merged_dynamic_df["year"] > merged_dynamic_df["start_year"]],
        ["nigem_country_code", "year", "variable_code", "start_year"],
    )


@pass_if_first_arg_is_none_or_empty
def apply_conversion_factor(
    truncated_dynamic_df: pd.DataFrame, arima_params_df: pd.DataFrame
) -> pd.DataFrame:
    """ Multiply each MEV with the correct conversion factor.

    Applies the conversion factor coming from arima parameters to the corresponding
    MEV value

    :param truncated_dynamic_df: filtered data frame coming from the truncation step
    :param arima_params_df: arima parameters df for conversion factor
    :return: truncated_dynamic_df: converted extension_df
    """

    truncated_dynamic_df = extend_dynamic_df_columns(truncated_dynamic_df)
    truncated_dynamic_df = _append_conversion_factor_column(
        truncated_dynamic_df, arima_params_df
    )
    truncated_dynamic_df.loc[:, "value"] *= truncated_dynamic_df["conversion_factor"]

    return remove_columns(
        truncated_dynamic_df,
        ["nigem_country_code", "year", "variable_code", "conversion_factor"],
    )


@pass_if_first_arg_is_none_or_empty
def _append_conversion_factor_column(
    truncated_dynamic_df: pd.DataFrame, arima_params_df: pd.DataFrame
) -> pd.DataFrame:
    """ Add conversion factor to dynamic_df

        Appends a new  conversion factor column after merging dynamic_df with
        arima_params_df

        :param truncated_dynamic_df: The DataFrame in Raw Scenario Time Series structure
        :param arima_params_df: extension DataFrame from static files dictionary that
        keeps conversion factor value
        :return: truncated_dynamic_df: Result DataFrame with conversion factor column
    """

    return truncated_dynamic_df.merge(
        arima_params_df[["time_series_code", "conversion_factor"]],
        on="time_series_code",
        how="inner",
    )


@pass_if_first_arg_is_none_or_empty
def apply_currency_conversion(
    conversion_applied_dynamic_df: pd.DataFrame,
    price_variables_df: pd.DataFrame,
    other_country_euro_countries_df: pd.DataFrame,
) -> pd.DataFrame:
    """ Multiply each MEV with the correct conversion factor.

        Applies the currency conversion if the MEV is a price variable

        :param price_variables_df: The dataframe that keeps a list of the MEVs to be
        calculated
        :param conversion_applied_dynamic_df: input DataFrame
        :param other_country_euro_countries_df: DataFrame from static files dictionary
        that keeps the euro countries
        :return: merged_euro_dynamic_df: result DataFrame
    """

    conversion_applied_dynamic_df = extend_dynamic_df_columns(
        conversion_applied_dynamic_df
    )
    rxeu_df = _extract_rxeu_df(conversion_applied_dynamic_df)

    merged_euro_dynamic_df = _append_rxeu_column(
        conversion_applied_dynamic_df,
        rxeu_df,
        price_variables_df,
        other_country_euro_countries_df,
    )

    merged_euro_dynamic_df["value"] *= merged_euro_dynamic_df["rxeu"]

    return remove_columns(
        merged_euro_dynamic_df, ["nigem_country_code", "year", "variable_code", "rxeu"]
    )


@pass_if_first_arg_is_none_or_empty
def _append_rxeu_column(
    dynamic_df: pd.DataFrame,
    rxeu_df: pd.DataFrame,
    price_variables_df: pd.DataFrame,
    other_country_euro_countries_df: pd.DataFrame,
) -> pd.DataFrame:
    """ Add rxeu to dynamic_df

        Merges dynamic_df with rxeu_df and redefines rxeu column in dynamic_df according
        to the price_variables_df

        :param dynamic_df: The DataFrame in Raw Scenario Time Series structure
        :param rxeu_df: The DataFrame which is created via extracting Rxeu MEVs from
        dynamic_df
        :param price_variables_df: DataFrame from static files dictionary that keeps if
        the MEV is a price MEV or not
        :param other_country_euro_countries_df: DataFrame from static files dictionary
        that keeps the euro countries
        :return: merged_euro_dynamic_df: Result DataFrame with rxeu column

        :raises KeyError: nigem_country_code, period, variable_code
    """

    if not set(["nigem_country_code", "period", "variable_code"]).issubset(
        set(dynamic_df.columns)
    ):
        error_message = (
            "nigem_country_code or period or variable_code column does not exist"
        )
        raise KeyError(error_message)

    merged_euro_dynamic_df = dynamic_df.merge(
        rxeu_df, on=["nigem_country_code", "period"], how="left"
    )

    mask_price_variable = ~merged_euro_dynamic_df["variable_code"].isin(
        price_variables_df["variable_code"]
    )
    merged_euro_dynamic_df.loc[mask_price_variable, "rxeu"] = 1.0

    mask_euro_countries = merged_euro_dynamic_df["nigem_country_code"].isin(
        other_country_euro_countries_df["nigem_country_code"]
    )
    merged_euro_dynamic_df.loc[mask_euro_countries, "rxeu"] = 1.0

    return merged_euro_dynamic_df


@pass_if_first_arg_is_none_or_empty
def _extract_rxeu_df(dynamic_df: pd.DataFrame) -> pd.DataFrame:
    """ Create DataFrame from RXEU MEV timeseries.

    Filters the input according to the variable code ("RXEU") and returns a new
    DataFrame containing country code, period and the rxeu value

    :param dynamic_df: input data frame in Raw Scenario Time Series structure
    :return: rxeu_df: output data frame identified with country/period pairs

    :raises KeyError: nigem_country_code, period, value, variable_code
    """

    if not set(["nigem_country_code", "period", "value", "variable_code"]).issubset(
        set(dynamic_df.columns)
    ):
        error_message = (
            "nigem_country_code or period or value or variable_code "
            "column does not exist "
        )
        raise KeyError(error_message)

    rxeu_df = dynamic_df[dynamic_df["variable_code"] == "RXEU"][
        ["nigem_country_code", "period", "value"]
    ]
    rxeu_df.rename(columns={"value": "rxeu"}, inplace=True)
    return rxeu_df


@pass_if_first_arg_is_none_or_empty
def _filter_invalid_countries(
    single_mev_df: pd.DataFrame,
    other_country_weights_df: pd.DataFrame,
    minimum_data_freq: int,
) -> pd.DataFrame:
    """ Filter the data of the invalid countries from the DataFrame

    Filter the countries which have less data from the minimum_data_freq

    :param single_mev_df: dynamic data contains only one particular MEV
    :param other_country_weights_df: weights list
    :param minimum_data_freq: int value keeps the minimum range of the data in years
    :return: single_mev_df: Output Dataframe filtered data
    """

    country_years_df = _create_country_years_df(single_mev_df, minimum_data_freq)
    # Reset minimum_data_freq if it is a unit_test run (if min_data_freq < 0)
    minimum_data_freq = (
        DEFAULT_DATA_FREQ if (minimum_data_freq < 0) else minimum_data_freq
    )

    countries_to_keep = country_years_df[
        (country_years_df["series_length"] >= minimum_data_freq)
        & (
            country_years_df.nigem_country_code.isin(
                other_country_weights_df["nigem_country_code"]
            )
        )
    ]

    single_mev_df = single_mev_df[
        (single_mev_df["period"] >= countries_to_keep["period_first"].max())
        & (
            single_mev_df.nigem_country_code.isin(
                countries_to_keep.nigem_country_code.unique()
            )
        )
        & (single_mev_df["value"].notnull())
    ]

    return single_mev_df


@pass_if_first_arg_is_none_or_empty
def _create_country_years_df(
    single_mev_df: pd.DataFrame, minimum_data_freq: int
) -> pd.DataFrame:
    """ Calculate first and last period for each country

    Gets the first and the last period for each country from the single mev DataFrame
    then calculates the length of the series as year difference between first and the
    last period. In the end returns first period, last period and the length of the
    series for each country as a DataFrame

    :param: single_mev_df: pd.DataFrame contains the weight-country pairs
    :param: minimum_data_freq: flag for deciding if current_year should be static or not
    :return: country_years_df: pd.DataFrame
    """

    # drop duplicates  is faster than other methods to order and group by
    country_years_df = pd.merge(
        single_mev_df.sort_values(by="period").drop_duplicates(
            subset=["nigem_country_code"], keep="first"
        )[["nigem_country_code", "period"]],
        single_mev_df.sort_values(by="period").drop_duplicates(
            subset=["nigem_country_code"], keep="last"
        )[["nigem_country_code", "period"]],
        on="nigem_country_code",
        suffixes=("_first", "_last"),
        how="left",
    )
    current_year = (
        OC_CONSTANT_YEAR if (minimum_data_freq < 0) else datetime.datetime.now().year
    )
    country_years_df.loc[:, "series_length"] = current_year - country_years_df[
        "period_first"
    ].astype(str).str[:4].astype("int64")

    return country_years_df


@pass_if_first_arg_is_none_or_empty
def _apply_weights(
    filtered_single_mev_df: pd.DataFrame, other_country_weights_df: pd.DataFrame
) -> pd.DataFrame:
    """ Apply weights on single MEV DataFrame

    Apply the weights on the MEV, calculate the total value based on the period,
    append the remaining columns to the calculated value DataFrame in order to create
    Other Country DataFrame

    :param filtered_single_mev_df: pd.DataFrame containing a single MEV in raw
    scenario data format
    :param other_country_weights_df: pd.DataFrame contains the weight-country pairs
    :return: total_value_df: pd.DataFrame
    """

    filtered_single_mev_df = pd.merge(
        filtered_single_mev_df,
        other_country_weights_df,
        on="nigem_country_code",
        how="left",
    )
    filtered_single_mev_df.loc[:, "value"] *= filtered_single_mev_df["weight"]

    total_value_df = _calculate_total_value_based_on_period(
        filtered_single_mev_df, other_country_weights_df
    )

    total_value_df = pd.merge(
        total_value_df,
        remove_columns(
            filtered_single_mev_df,
            ["value", "nigem_country_code", "time_series_code", "id", "weight"],
        ).drop_duplicates(),
        on="period",
        how="left",
    )

    total_value_df["id"] = total_value_df.index
    total_value_df.loc[:, "time_series_code"] = "OT" + total_value_df["variable_code"]

    return total_value_df


@pass_if_first_arg_is_none_or_empty
def _calculate_total_value_based_on_period(
    filtered_single_mev_df: pd.DataFrame, other_country_weights_df: pd.DataFrame
) -> pd.DataFrame:
    """ Make the total value calculation in a filtered DataFrame

    Apply the following formula on the filtered MEV DataFrame based on period
    considering (MEV value * weight factor) multiplication is already done:
    (SUM OF (MEV value * weight factor)) / TOTAL weight of the countries for this MEV

    :param filtered_single_mev_df: pd.DataFrame containing a single MEV in raw
    scenario data format
    :param other_country_weights_df: pd.DataFrame contains the weight-country pairs
    :return: result_df: pd.DataFrame
    """

    incomplete_period_mask = _get_incomplete_period_mask(filtered_single_mev_df)

    filtered_single_mev_df = (
        filtered_single_mev_df.groupby(["period"])["value"].sum()
        / other_country_weights_df[
            other_country_weights_df["nigem_country_code"].isin(
                filtered_single_mev_df["nigem_country_code"].unique()
            )
        ]["weight"].sum()
    )
    result_df = pd.DataFrame(filtered_single_mev_df)
    result_df.loc[incomplete_period_mask, "value"] = None
    result_df.reset_index(inplace=True)

    return result_df


def _get_incomplete_period_mask(filtered_single_mev_df: pd.DataFrame) -> bool:
    """" Get incomplete periods

    Creates a mask for the periods which have some missing countries

    :param filtered_single_mev_df: pd.DataFrame containing a single MEV in raw
    scenario data format
    :return: nan_mask: pd.Series
    """
    incomplete_periods = pd.DataFrame(
        filtered_single_mev_df.groupby(["period"])["nigem_country_code"].count()
    )
    total_countries = incomplete_periods["nigem_country_code"].max()
    nan_mask = incomplete_periods["nigem_country_code"] < total_countries
    return nan_mask


@pass_if_first_arg_is_none_or_empty
def create_other_country_df(
    converted_dynamic_df: pd.DataFrame,
    other_country_weights_df: pd.DataFrame,
    minimum_data_freq: int,
) -> pd.DataFrame:
    """ Calculate Other Country MEVs

    Using the MEV list in the converted dynamic data, filter the data from the invalid
    countries then apply the weights for that specific MEV.

    :param other_country_weights_df: pd.DataFrame
    :param converted_dynamic_df: pd.DataFrame
    :param minimum_data_freq: int
    :return: other_country_df: pd.DataFrame
    """

    other_country_df = pd.DataFrame()
    base_columns = converted_dynamic_df.columns
    converted_dynamic_df = extend_dynamic_df_columns(converted_dynamic_df)
    unique_mev_list = _get_unique_oc_mev_list(converted_dynamic_df)

    for mev in unique_mev_list:
        filtered_single_mev_df = _filter_invalid_countries(
            converted_dynamic_df[converted_dynamic_df["variable_code"] == mev],
            other_country_weights_df,
            minimum_data_freq,
        )
        weights_applied_df = _apply_weights(
            filtered_single_mev_df, other_country_weights_df
        )

        other_country_df = _append_and_arrange_columns(
            base_columns, other_country_df, weights_applied_df
        )

    return other_country_df


def _get_unique_oc_mev_list(converted_dynamic_df: pd.DataFrame) -> list:
    """ Get unique MEV list to be included for OC calculation

    :param converted_dynamic_df: pd.DataFrame
    :return: unique_mev_list: list(str)
    """
    unique_mev_set = converted_dynamic_df.variable_code.unique()
    unique_mev_list = list(set(unique_mev_set))
    return unique_mev_list


def _append_and_arrange_columns(
    base_columns: List[str],
    other_country_df: pd.DataFrame,
    weights_applied_df: pd.DataFrame,
) -> pd.DataFrame:
    """ Append weights applied DataFrame to Other Country DataFrame

    Appends the calculated result DataFrame for corresponding MEV to Other Country
    DataFrame and arranges the restructures columns based on base_columns

    @:param base_columns: Column list to be used as base
    @:param other_country_df: Other Country DataFrame
    @:param weights_applied_df: Unique MEVs in converted_dynamic_df
    @:return: Other country dataframe
    """
    other_country_df = (
        remove_columns(other_country_df.append(weights_applied_df), ["id"])
        .reset_index(drop=True)
        .reindex(base_columns, axis=1)
    )
    other_country_df["id"] = other_country_df.index
    return other_country_df
