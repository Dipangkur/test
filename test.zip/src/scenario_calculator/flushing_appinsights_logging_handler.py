from logging import LogRecord

import applicationinsights


class FlushingAppinsightsLoggingHandler(applicationinsights.logging.LoggingHandler):
    """Fixes the standard AppInsights LoggingHandler, making it flush often.

    This class ensures that each log is flushed quickly enough to the
    AppInsights server.  The most simple solution is to issue a flush()
    after each log.
    """

    def emit(self, record: LogRecord) -> None:
        """Emit a log record.

        Refer to the superclass docstring for more info.

        One side-note however: apparently the AppInsights LogginHandler
        decides to *not* log a log-record carrying non-empty exception
        information, but to send it to the AppInsights exception facility
        instead.

        :param record: The log record to send to the logging backend.
        """
        super().emit(record)
        self.flush()
