# type: ignore[attr-defined]
"""SqlAlchemy helper functions.

TODO [JHB]: Cloned and adapted from the MSR.ScenarioCreator.Py project.
 PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
"""
from typing import Any, Optional, Tuple

from sqlalchemy.engine import Engine
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.ext.declarative import DeclarativeMeta, declarative_base
from sqlalchemy.orm import Session, sessionmaker

from scenario_calculator.db_connect_utils import (
    fill_sql_alchemy_url_template,
    get_msi_authentication_access_token,
)
from scenario_calculator.sql_alch_create_engine_args import SqlAlchCreateEngineArgs

Base = declarative_base()


def create_engine_from_connection_string(
    sql_alchemy_conn_template: str, **kwargs: Any
) -> Engine:
    """Create the SqlAlchemy engine from the connection string template.

    The first parameter (template) is first processed as per
      `fill_sql_alchemy_url_template` (qv.)
    Subsequently the resulting connection string and the provided `kwargs`
      are used to initialize the `SqlAlchCreateEngineArgs` instance (qv.).
    Subsequently the instance's `create_engine` method (qv.) is being
      invoked to supply the actual SqlAlchemy `Engine` instance.

    :param sql_alchemy_conn_template: The SqlAlchemy connection string template
      in which possible {token} or {database_token} variables are interpolated
    :param kwargs: additional keyword arguments to eventually pass to
       `create_engine`
    :return: The created Engine instance
    """
    # Process the connection string for access token placeholders
    conn_str = fill_sql_alchemy_url_template(
        sql_alchemy_conn_template, get_msi_authentication_access_token
    )
    return SqlAlchCreateEngineArgs(conn_str, **kwargs).create_engine()


def create_mapped_base(engine: Engine) -> DeclarativeMeta:
    base = automap_base()
    base.prepare(engine, reflect=True)
    return base


def create_session(engine: Engine) -> Session:
    session_factory = sessionmaker(bind=engine)
    # Alternative for automatic sessions per thread:
    # scoped_session_factory = scoped_session(session_factory)
    # session = scoped_session_factory()
    session: Session = session_factory()
    return session


def define_base(
    engine: Engine, base: Optional[DeclarativeMeta] = None
) -> DeclarativeMeta:
    if base is None:
        base = create_mapped_base(engine)
    else:
        base.metadata.create_all(engine)
    return base


def new_session_base_tuple(
    engine: Engine, base: Optional[DeclarativeMeta] = None
) -> Tuple[Session, DeclarativeMeta]:
    base = define_base(engine, base)
    session = create_session(engine)
    return session, base
