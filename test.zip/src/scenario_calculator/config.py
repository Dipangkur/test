# type: ignore[attr-defined]
"""This module defines relevant configuration parameters."""
from datetime import datetime
from typing import Optional

import attr

from scenario_calculator.thread_teeing_logging_handler import ThreadTeeingLoggingHandler


@attr.s(auto_attribs=True, repr=False)
class GeneralConfig:
    """Holds the general configuration attributes for this very application.

    Please note that this class can't act as a quasi-immutable, since
    it is used in combination with the ``click.Context`` and that requires
    that the object is instantiated first and modified subsequently.

    The following attribute instance variables are defined:
    """

    input_batch_size: Optional[int] = None
    __doc__ += """
    :ivar input_batch_size: the number of records to read in one batch"""

    output_batch_size: Optional[int] = None
    __doc__ += """
    :ivar output_batch_size: the number of records to write in one batch"""

    appinsights_instrumentation_key: Optional[str] = None
    __doc__ += """
    :ivar appinsights_instrumentation_key: the AppInsights instrumentation key
      (not shown in `__repr__` since it carries a secret key)"""

    thread_teeing_logging_handler: Optional[ThreadTeeingLoggingHandler] = None
    __doc__ += """
    :ivar thread_teeing_logging_handler: the special logging handler that
      enables the possibility to capture a copy of the logs per thread."""

    # Sentinel
    __doc__ += """
    """

    def __repr__(self) -> str:
        """Show a representation of the object instance - hiding appinsights secret key

        :return: the representation of the GeneralConfig instance
        """
        arg_reprs = (
            f"{attr_name}=***"
            if attr_name == "appinsights_instrumentation_key"
            else f"{attr_name}={val!r}"
            for attr_name, val in vars(self).items()
        )
        return f"{self.__class__.__qualname__}({', '.join(arg_reprs)})"


@attr.s(auto_attribs=True, frozen=True)
class RunParams:
    """Holds extra configuration parameters for a run of the job.

    .. note:: This is deliberately separated from the swagger-generated
        JobParams model to avoid undesired dependencies.

    The following attribute instance variables are defined:"""

    raw_scenario_input_url_str: str
    __doc__ += """
    :ivar raw_scenario_input_url_str: Points to the dynamic input data.
      The scheme-part of the url can either be 'file' (pointing to a
      csv file), or the url is an SqlAlchemy-compliant database url."""

    scenario_output_url_str: str
    __doc__ += """
    :ivar scenario_output_url_str: Points to the output data.
      The scheme-part of the url can either be 'file' (pointing to a
      csv file), or the url is an SqlAlchemy-compliant database url."""

    blob_storage_account_key: str
    __doc__ += """
   :ivar blob_storage_account_key: The BlobStorage account key.
     Used for the reader via BlockBlobService https-URLs."""

    event_logger_url_str: Optional[str] = None
    __doc__ += """
    :ivar event_logger_url_str: The db connection url for event logging
      either None - in that case a in-memory sink database is created - or
      an SqlAlchemy-compliant database url."""

    # Sentinel
    __doc__ += """

    For a definition of an SqlAlchemy-compliant database url, pls. refer to
    `https://docs.sqlalchemy.org/en/latest/core/engines.html#database-urls`_.
    """


@attr.s(auto_attribs=True, frozen=True)
class RunDefinition:
    """Holds parameters that defines this particular job.

    .. note:: This is deliberately separated from the swagger-generated
        JobDefinition model to avoid undesired dependencies.

    The following attribute instance variables are defined:"""

    raw_scenario_id: int
    __doc__ += """
    :ivar raw_scenario_id: the id of the originating raw scenario"""

    event_id: int
    __doc__ += """
    :ivar event_id: the event_id for the EventLogger"""

    scenario_name: str
    __doc__ += """
    :ivar scenario_name: the name of the scenario"""

    scenario_creator: str
    __doc__ += """
    :ivar scenario_creator: the user who created the scenario"""

    meister_version: str
    __doc__ += """
    :ivar meister_version: the meister_version is a tag Azure creates in the CD pipeline
    and with it, we can track the branch that was used to create the raw scenario"""

    calculation_date: datetime
    __doc__ += """
    :ivar calculation_date: the date when the user has activated the calculation in the
    GUI part"""

    scenario_description: str
    __doc__ += """
    :ivar scenario_description: the description the user has entered before the
    calculation fired up in the GUI part"""

    current_datetime: datetime
    __doc__ += """
    :ivar current_datetime: the date and time this calculation starts"""

    is_lab: bool
    __doc__ += """
    :ivar is_lab: The Lab flag.
      Used for defining the run as a Lab run."""

    static_file_urls: Optional[str] = None
    __doc__ += """
     :ivar static_file_urls: Static file list.
      Used for the static data files kept in blob storage to be used for the lab."""

    # Sentinel
    __doc__ += """
    """
