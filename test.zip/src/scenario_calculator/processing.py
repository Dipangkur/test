# type: ignore[attr-defined]
# -*- coding: utf-8 -*-
"""

Processes data and constructs (extended) Timeseries objects. These objects are
stored in dicts that are used throughout the code (e.g. by the enrichment
module).

In addition, this module contains the new version of extend function and other helper
functions in order to keep TimeSeries data in DataFrame instead of a custom class

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""

import logging
from typing import Any, Dict, Optional, Sequence

import numpy as np
import pandas as pd

from scenario_calculator.modelling.adjustment import (
    clean_series,
    correct_series,
    inverse_transform,
    sample_to_quarterly,
    sample_to_yearly,
    transform,
)
from scenario_calculator.timeseries import _extend_series
from scenario_calculator.utility import (
    generate_dates,
    get_uniques_from_frame,
    overwrite_number,
    overwrite_text,
)

# Globals:
logger = logging.getLogger(__name__)

UNIT_DEFAULT = "ABS_ACT"
# TODO [AB]: Fixes after SingleScenario Removal - consider getting from a config/setting
# file
_ATTRIBUTE_NAMES = (
    "id",
    "date",
    "source",
    "scenario",
    "time_series_code",
    "period",
    "corep_country_code",
    "unit",
    "conversion_factor",
    "model_param_beta_0",
    "model_param_beta_1",
    "model_param_d",
    "extension_transformation_type",
    "aggregation_transformation_type",
)


# TODO [AB]: Fixes after SingleScenario Removal - Consider removing Attributes class
# TODO [JHB]: Make the name more specific.
# TODO [JHB]: Consider solving this in another way. Perhaps this class is not needed
#   at all, it is quite of a non-value-adding class between the dataframe and
#   the TimeSeries object.
class Attributes:
    """Helper Class that will be used to retrieve relevant (time series)
    attributes from data frame. Attributes are stored in a dict."""

    def __init__(
        self, df: pd.DataFrame, unit: str = "", names: Sequence[str] = _ATTRIBUTE_NAMES
    ) -> None:
        """
        Set attributes
        :param df: dataframe
        :param unit: unit
        :param names: column names
        """
        self._attrs: Dict[str, Any] = {}
        for name in names:
            self[name] = get_uniques_from_frame(df, name)

    def __getitem__(self, key: str) -> Any:
        return self._attrs[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._attrs[key] = value


def extend_time_series(
    time_series_df: pd.DataFrame, end_year_extension: int, freq: str,
) -> pd.DataFrame:
    """
    The input value data is a data frame containing all time series data
    retrieved from the database. First, we determine all unique scenario's.
    Next, for each unique time series code a subset of data is made.
    This subset is passed to _construct_extended_tseries. The return value
    (i.e. a TimeSeries object) of this function is added to a result
    dictionary.

    :param time_series_df: data frame containing all relevant time series data
    :param end_year_extension: end year of extension
    :param freq: frequency
    :param unit: unit (currently set to ABS_ACT)
    :return: dictionary containing extended time series
    :rtype: Scenarios
    """
    extended_df = pd.DataFrame()
    series_codes = time_series_df["time_series_code"].unique()
    for code in series_codes:
        # Take subset of the df
        code_df = time_series_df[time_series_df["time_series_code"] == code]
        # Get attributes of the dataframe
        attrs = get_attribute(code_df)

        # Construct series, perform extension and re-construct dataframe:
        series = construct_series(code_df, attrs)
        series = correct_series(series, code)
        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            series, attrs, end_year_extension, freq
        )
        code_df = re_construct_code_df(
            series, attrs, last_obs_date, start_year_extension, aggr_type
        )

        # Construct dataframe:
        extended_df = pd.concat([extended_df, code_df])

    return extended_df


def get_attribute(df):
    # Get TimeSeries attributes and, if needed, overwrite attributes with
    # standard values:
    attrs = Attributes(df)
    attrs = _overwrite_attributes(attrs, attrs["time_series_code"])
    return attrs


def get_output_date(date):
    """Generates sbv-compliant date."""
    dd = str(date)[6:8]
    mm = str(date)[4:6]
    yyyy = str(date)[0:4]
    return yyyy + "-" + mm + "-" + dd  # sbv compliant date


def extend_series(
    series: pd.Series, attrs: Attributes, end_year_extension: int, freq: str = "A-DEC",
) -> pd.DataFrame:  # noqa: C901
    """Extends a macro-economic scenario.

    Background:
    Both the IFRS9 calculations and the Stress Test calculations are on a
    yearly basis. The quarterly input is converted to yearly
    data in a process called aggregation. The extension model is based on
    yearly data. There should be one unique extension per
    calculation date that is consistent for IFRS9 and Stress Testing.
    This is accomplished by performing the extension based on (transformed)
    aggregated values per calendar year. For the extension period,
    the yearly projections are then ‘disaggregated’ to a projection on
    quarterly basis by reversion of the aggregation procedure.

    The process ends by determining the date of the last observations and
    overwriting all the extended data with the original data up to the date of the
    last observations.

    :param series:
    :param attrs:
    :param end_year_extension: end year of extension
    :type end_year_extension: int
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :type freq: str
    :returns: pd.DataFrame
    """

    # Generate dates for extension step:
    start_year_extension = series.index[-1].year + 1
    start = start_year_extension
    end = end_year_extension + 1
    dates = generate_dates(start, end, freq)

    # Set default values
    aggr_type = attrs["aggregation_transformation_type"]
    trans_type = attrs["extension_transformation_type"]
    param_beta0 = attrs["model_param_beta_0"]
    param_beta1 = attrs["model_param_beta_1"]
    param_d = attrs["model_param_d"]

    aggr_type = _get_aggr_type(aggr_type, attrs["aggregation_transformation_type"])

    new_series = sample_to_yearly(series, aggr_type, freq)
    start_val = new_series.iloc[0]  # The first value of a series is needed

    # Transform to correct unit for extension step:
    trans_type = _get_trans_type(attrs["extension_transformation_type"], trans_type)
    new_series = transform(new_series, trans_type)

    # Extend series:
    prev_val = new_series[len(new_series) - 1]  # start value
    param_beta0 = _get_param_beta0(param_beta0, attrs["model_param_beta_0"])

    param_beta1 = _get_param_beta1(param_beta1, attrs["model_param_beta_1"])

    param_d = _get_param_d(param_d, attrs["model_param_d"])

    new_series = _extend_series(
        new_series, dates, prev_val, param_beta0, param_beta1, param_d
    )

    # Inverse transform series:
    new_series = inverse_transform(new_series, trans_type, start_val)
    last_date_extension = new_series.index[-1]

    # Sample back to quarterly date
    new_series = sample_to_quarterly(new_series, aggr_type)

    # Determine last date of observations, trim the series and reconstruct the
    # time series dataframe:
    last_obs_date = generate_dates(start - 1, start, freq)[0]

    # Get only the extended series values
    new_series = new_series[new_series.index > last_obs_date]
    # Get the final series by adding old and the new series
    series = series[series.index <= last_obs_date].append(new_series)

    series = series[series.index <= last_date_extension]

    return series, last_obs_date, start_year_extension, aggr_type


# TODO [AB]: Fixes after SingleScenario Removal - Consider a generic solution for the
# extensive assignments (more examples among the code base)
def re_construct_code_df(series, attrs, last_obs_date, start_year_extension, aggr_type):
    # Construct the dataframe
    ts_df = pd.DataFrame()
    ts_df["series"] = series
    ts_df["last_obs_date"] = last_obs_date
    ts_df["time_series_code"] = attrs["time_series_code"]
    ts_df["series_code"] = attrs["time_series_code"]
    ts_df["unit"] = attrs["unit"]
    ts_df["scenario"] = attrs["scenario"]
    ts_df["corep_code"] = attrs["corep_country_code"]
    ts_df["start_year_extension"] = start_year_extension
    ts_df["conversion_factor"] = attrs["conversion_factor"]
    ts_df["aggregation_type"] = aggr_type
    ts_df["originating_raw_scenario_time_series_id"] = attrs["id"]
    ts_df["adjustment"] = "regular process"
    ts_df["mapped_to_corep_code"] = ""
    ts_df["mapped_to_variable_code"] = ""
    ts_df["nigem_code"] = attrs["time_series_code"][0:2]
    ts_df["variable_code"] = attrs["time_series_code"][2:]
    ts_df["param_mu"] = np.math.nan
    ts_df["param_sigma"] = np.math.nan
    ts_df["period"] = attrs["period"]

    return ts_df


def _get_param_d(param_d, model_param_d):
    if model_param_d:
        param_d = model_param_d
    return param_d


def _get_param_beta1(param_beta1, model_param_beta_1):
    if model_param_beta_1:
        param_beta1 = model_param_beta_1
    return param_beta1


def _get_param_beta0(param_beta0, model_param_beta_0):
    if model_param_beta_0:
        param_beta0 = model_param_beta_0
    return param_beta0


def _get_trans_type(extn_trans_type, trans_type):
    if extn_trans_type:
        trans_type = extn_trans_type
    return trans_type


def _get_aggr_type(aggr_type, aggr_trans_type):
    if aggr_trans_type:
        aggr_type = aggr_trans_type
    return aggr_type


def construct_series(df: pd.DataFrame, attrs) -> pd.Series:
    """
    Constructs pandas Series object from from the given pandas dataframe.

    :param df: data frame containing all relevant data to construct a \
               pandas series object.
    :return: constructed pandas series and attributes of the dataframe.
    """

    # =========================================================================
    # Create ordered time series & drop non-numerical fields:
    series = _create_series_from_frame(df[["value", "date_index"]])

    return series


# =============================================================================
# Private helper functions:
# =============================================================================
def _overwrite_attributes(attrs: Attributes, series_code: str) -> Attributes:
    """
    Overwrite attribute with a standard value if attribute is equal
    to None or NaN, use list of messages (global):

    :param attrs: dict
    :param series_code: series code
    :return: updated dict
    """
    attrs["conversion_factor"] = overwrite_number(
        attrs["conversion_factor"],
        1.0,
        "Default value used conversion_factor: %s" % series_code,
    )
    attrs["model_param_beta_0"] = overwrite_number(
        attrs["model_param_beta_0"],
        0.0,
        "Standard value used model_param_beta_0: %s" % series_code,
    )
    attrs["model_param_beta_1"] = overwrite_number(
        attrs["model_param_beta_1"],
        0.0,
        "Standard value used model_param_beta_1: %s" % series_code,
    )
    attrs["model_param_d"] = overwrite_number(
        attrs["model_param_d"],
        0.0,
        "Standard value used model_param_d: %s" % series_code,
    )
    attrs["extension_transformation_type"] = overwrite_text(
        attrs["extension_transformation_type"],
        "YOY",
        "Standard value used extension_transformation_type: %s" % series_code,
    )
    attrs["aggregation_transformation_type"] = overwrite_text(
        attrs["aggregation_transformation_type"],
        "AVG",
        "Standard value used aggregation_transformation_type: %s" % series_code,
    )
    return attrs


def _create_series_from_frame(df: pd.DataFrame) -> Optional[pd.Series]:
    """Create ordered time series & drop non-numerical fields.
    Return None if either one of the "date_index", or "value" columns is missing.

    :param df: data frame containing all relevant data to construct
      a time series object.
    :return: time series
    """
    # Create ordered time series & drop non-numerical fields:
    series = df["value"].groupby(df["date_index"]).unique().apply(pd.Series)[0]
    series = clean_series(series)
    series.sort_index(inplace=True)
    return series
