"""Utility functions used throughout the code."""

import csv
import datetime as dt
import logging
import math
import os
import re
import time
from contextlib import contextmanager
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    Generator,
    List,
    Mapping,
    NamedTuple,
    Optional,
    Sequence,
    TextIO,
    Tuple,
    Type,
    TypeVar,
    Union,
)
from urllib.request import Request, url2pathname

import numpy as np
import pandas as pd
from sqlalchemy.util import lightweight_named_tuple

from scenario_calculator.constants import DATE_FMT, ObservationType
from scenario_calculator.settings import Settings
from swagger_server.models.base_model_ import Model

# Globals:
# TODO [JHB]: why this particular format (".8f")?
#  -> because then the self-set eps values are converted back to 0.0 :-(


# Type aliases and type vars:
NamedTupleLike = Union[NamedTuple, lightweight_named_tuple]
# noinspection PyShadowingBuiltins
_T = TypeVar("_T")
_M = TypeVar("_M", bound=Mapping[Any, Any])

# Constants:
_CSV_OUT_FLOAT_FMT = ".8f"
_CSV_OUT_DATE_FMT = "%Y-%m-%d"
_DATETIME_FMTS = (
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M",
    "%Y-%m-%d",
    "%Y%m%dT%H%M",
    "%Y%m%dT%H%M%S",
    "%Y%m%d",
)
FREQ_TO_QUARTER = {"A-MAR": 1, "A-JUN": 2, "A-SEP": 3, "A-DEC": 4}

# Globals:
_log = logging.getLogger(__name__)


@contextmanager
def time_context(name: str) -> Generator:
    """Context manager function to time the context.

    :param name: context description.
    :return: None.
    """
    # TODO [JHB]: Improved from MSR.ScenarioCreator.Py project.
    #  Make it an multi-usable module.
    #  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
    start_wall = time.time()
    start_times = os.times()
    yield
    end_times = os.times()
    elapsed_wall = time.time() - start_wall
    # noinspection PyUnresolvedReferences
    elapsed_user = end_times.user - start_times.user
    # noinspection PyUnresolvedReferences
    elapsed_sys = end_times.system - start_times.system
    _log.info(
        "[%s] finished in real %d / user %d / system %d (ms)",
        name,
        round(elapsed_wall * 1000),
        round(elapsed_user * 1000),
        round(elapsed_sys * 1000),
    )


# =============================================================================
# Decorator(s):
# =============================================================================
def common_dataframe_error_handler(func: Any) -> Any:
    """ Raises an error if one of the common DataFrame exceptions is caught

    Decorator for the handling the KeyErrors and ValueErrors

    @:param func: function itself to be decorated
    @:return:
    """

    def inner_function(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (KeyError, ValueError) as err:
            _log.error("%s", err, exc_info=True)
            raise

    return inner_function


# =============================================================================
# Arithmetic function(s):
# =============================================================================
def standardize(tseries: pd.DataFrame):
    """Calculates the standardized value based on mu and sigma.

    If the value happens to be an infinite number or sigma equals zero,
    then math.nan is returned.

    :param tseries: Data Frame
    """
    tseries["StandardizedValue"] = math.nan
    standart_filter = tseries["Sigma"] == 0 | tseries["Value"].isin([np.inf, -np.inf])
    tseries["StandardizedValue"] = tseries["StandardizedValue"].where(
        standart_filter, (tseries["Value"] - tseries["Mu"]) / tseries["Sigma"]
    )
    if tseries["Value"].isin([np.inf, -np.inf]).any():
        _log.warning("Inf Value exist")

    return tseries


# =============================================================================
# Dict & list functions:
# =============================================================================


def clean_list(lst: Sequence[_T]) -> List[_T]:
    """
    Remove NaN's from a list of heterogeneous items (not necessarily floats).

    :param lst: python list
    :return: cleaned list
    """
    return [ele for ele in lst if pd.notna(ele)]


# =============================================================================
# Functions to work with dates:
# =============================================================================
def count_quarters(date1, date2):
    """
    Count number of quarters between two dates.

    :param date1: date 1
    :type date1: pd.tslib.Timestamp
    :param date2: date 2
    :type date2: pd.tslib.Timestamp
    :return: number of quarters between dates
    :rtype: int
    """
    delta1 = _get_quarter_delta(date1, date2)
    delta2 = _get_year_delta(date1, date2)
    return delta1 + 4 * delta2 + 1


def _get_quarter_delta(date1, date2):
    """
    Get quarter q1 from date1, quarter q2 from date2 and return (q2 - q1).

    :rtype: object
    :param date1: date 1
    :type date1: pd.tslib.Timestamp
    :param date2: date 2
    :type date2: pd.tslib.Timestamp
    :return: quarter2 minus quarter1
    :rtype: int
    """
    q1 = int(math.ceil(date1.month / 3.0))
    q2 = int(math.ceil(date2.month / 3.0))
    return q2 - q1


def _get_year_delta(date1, date2):
    """
    Get year y1 from date1, year y2 from date2 and return (y2 - y1).

    :param date1: date 1
    :type date1: pd.tslib.Timestamp
    :param date2: date 2
    :type date2: pd.tslib.Timestamp
    :return: year2 minus year1
    :rtype: int
    """
    y1 = int(date1.year)
    y2 = int(date2.year)
    return y2 - y1


@common_dataframe_error_handler
def generate_date(year: int, freq: str) -> Optional[pd.Timestamp]:
    """
    Generates a date given a certain frequency and a year.

    :param year: year (as int)
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :raises KeyError:
    :return: generated date
    """
    quarter = FREQ_TO_QUARTER[freq]
    date_string = f"{year}Q{quarter}"
    pd_datetime = pd.to_datetime(date_string)
    return pd_datetime + pd.offsets.MonthEnd(3)


def generate_dates(start_year: int, end_year: int, freq: str) -> pd.DatetimeIndex:
    """
    Generates an array of annual time indices starting from end of
    month of [freq], [start_year] to the end of month of [freq], [end_year]

    :param start_year: start year
    :param end_year: end year
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :return: list of generated dates
    """
    start = str(start_year)
    end = str(end_year)
    return pd.date_range(start, end, freq=freq)


def get_observation_type(tseries: pd.DataFrame, start_scenario: int):
    """
    Helper function needed to find the "type" of an observation; i.e.
    is this a historical / scenario / extension point?

    :param tseries: Data Frame
    :param start_scenario: start date (YYYYMMDD format) scenario
    """
    tseries["Type"] = ObservationType.Scenario.name

    tseries.loc[
        pd.to_datetime(tseries["ValueDate"])
        < pd.to_datetime(str(start_scenario), format="%Y%m%d"),
        "Type",
    ] = ObservationType.Historical.name

    tseries.loc[
        pd.to_datetime(tseries["ValueDate"]).values
        > pd.to_datetime(tseries["last_obs_date"]).values,
        "Type",
    ] = ObservationType.Extension.name

    return tseries


def generate_quarter_format(year_month_day: int) -> str:
    """Convert a YYYYMMDD coded integer into a YYYYQn coded string.

    This function is used to change the scenario_start_date to the
    start_date_of_shock_period to use in the get_original_agriland_frame.

    :param year_month_day: scenario_start_date str e.g 20190331
    :return: a str in quarter format e.g "2019Q1"
    """
    ts = pd.Timestamp(pd.to_datetime(year_month_day, format="%Y%m%d"))
    return f"{ts.year}Q{ts.quarter}"


# =============================================================================
# Formatting functions:
# =============================================================================


def format_float_for_csv_out(value: float) -> str:
    """Formats a floating point value to an 8 digits accurate format.
    Infinite values (positive or negative) are converted to an empty string.

    :param value: value to be formatted
    :return: formatted value
    """
    if not math.isinf(value):
        return format(value, _CSV_OUT_FLOAT_FMT)
    return ""


def format_date_for_csv_out(date: dt.datetime) -> str:
    """Formats a date given a format type.

    :param date: datetime object
    :return: datetime formatted as string
    """
    return date.strftime(_CSV_OUT_DATE_FMT)


# =============================================================================
# Pandas Dataframe functions:
# =============================================================================
def convert_to_datetime(col):
    """Convert Pandas Column to DateTime (quarter end) column.

    :param col: column containing dates (format: YYYYQx)
    :type col: pandas.core.DataFrame
    :return: List of DateTimes (DatetimeIndex object) where all dates are \
             converted to quarter end DateTime dates.
    :rtype: pandas.DatetimeIndex
    """
    tmp1 = pd.to_datetime(col)  # Date when quarter starts
    tmp2 = pd.offsets.MonthEnd(3)
    return tmp1 + tmp2  # Date when quarter ends


def join_frames(
    df_left: pd.DataFrame,
    df_right: pd.DataFrame,
    cols: Sequence[str],
    how: str = "left",
) -> Optional[pd.DataFrame]:
    """Join df1 on df2 on cols given.

    :param df_left: left dataframe
    :param df_right: right dataframe
    :param cols: columns (names) to join on
    :param how: one of 'left', 'right', 'outer', 'inner'
    :raises ValueError:
    :return: dataframe result of join
    """
    for col in cols:
        if col not in df_left.columns or col not in df_right.columns:
            raise ValueError("Invalid column name: %s" % (col,))
    return pd.merge(df_left, df_right, how, on=cols)


def add_columns_to_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Introduce new date columns to df, derived from period column.

    :param df: original dataframe
    :return: updated dataframe
    """
    if "period" in df.columns:
        df["date_index"] = convert_to_datetime(df.period)
        df["year"] = df["date_index"].dt.year
        df["quarter"] = df["date_index"].dt.quarter
    else:
        # TODO [JHB]: Should raise exception?
        _log.warning("Period column does not exist")
    return df


def get_uniques_from_frame(df: pd.DataFrame, col_name: str) -> Any:
    """Get uniques and return the first entry of the list. Write a warning
    message to the logger is the length of the list >= 1.

    :param df: dataframe
    :param col_name: column name
    :return: first entry of uniques list.
    """
    uniques = df[col_name].unique()
    if len(uniques) > 1:
        _log.warning("Not a unique entry: %s", col_name)
    return uniques[0]


def extend_dynamic_df_columns(dynamic_df: pd.DataFrame) -> pd.DataFrame:
    """Extend columns using existing columns

    Adds country code, year and variable code to the given DataFrame

    :param dynamic_df: The input DataFrame in Raw Scenario Time Series structure
    :return: truncated_extension_df: Output Dataframe with new columns

    :raise KeyError: time_series_code, period
    """
    if not set(["time_series_code", "period"]).issubset(set(dynamic_df.columns)):
        error_message = "time_series_code or period column does not exist"
        _log.error(error_message)
        raise KeyError(error_message)

    dynamic_df = dynamic_df.assign(
        nigem_country_code=dynamic_df["time_series_code"].astype(str).str[:2]
    )
    dynamic_df = dynamic_df.assign(
        year=dynamic_df["period"].astype(str).str[:4].astype("int64")
    )
    dynamic_df = dynamic_df.assign(
        variable_code=dynamic_df["time_series_code"].astype(str).str[2:]
    )

    return dynamic_df


def remove_columns(dynamic_df: pd.DataFrame, column_list: List[str]) -> pd.DataFrame:
    """
    Drop extra columns

    Deletes the given columns from the dataframe

    :param dynamic_df: The input DataFrame in Raw Scenario Time Series structure
    :param column_list: String list of the column names to be removed
    :return: dynamic_df: returns the DataFrame with the remaining columns

    :raises KeyError: [column_list]
    """
    if not set(column_list).issubset(set(dynamic_df.columns)):
        error_message = f"One or more of the columns don't exist: {column_list}"
        _log.error(error_message)
        raise KeyError(error_message)

    return dynamic_df.drop(column_list, axis=1)


# =============================================================================
# CSV writers:
# =============================================================================


def csv_writer(
    file: TextIO, delimiter: str = "|", quoting: Any = csv.QUOTE_NONE
) -> Any:
    """
    Returns csv writer object.

    :param file: filename + path
    :param delimiter: delimiter
    :param quoting: quoting indicator
    :return: csv writer object
    """
    return csv.writer(file, delimiter=delimiter, quoting=quoting)


def mes_csv_writer(
    basename: str,
    out_dir: Path,
    hdr: Sequence[str],
    newline: Optional[str] = "",
    delimiter: str = ";",
    quoting_header: Any = csv.QUOTE_NONE,
    quoting_rows: Any = csv.QUOTE_ALL,
) -> Any:
    """Returns gbs/sbv compliant csv writer object. Writes header row.

    :param basename: basename of the file to create
    :param out_dir: dirname part of the file to create
    :param hdr: the list of header names
    :param newline: newline parameter
    :param delimiter: delimiter
    :param quoting_header: header quoting indicator
    :param quoting_rows: rows quoting indicator
    :return: csv writer object
    """
    fullpath = out_dir / basename
    _log.debug("Opening %s for writing", fullpath)
    file = fullpath.open("w", newline=newline)
    out = csv_writer(file, delimiter=delimiter, quoting=quoting_header)
    out.writerow(hdr)
    out = csv_writer(file, delimiter=delimiter, quoting=quoting_rows)
    return out


# =============================================================================
# String manipulations:
# =============================================================================


def get_unique_scenario_type(
    scenario_name: str, types: Optional[Sequence[str]] = None
) -> str:
    """Get (unique) scenario type based on scenario name.

    :param scenario_name: a name of a scenario
    :param types: possible scenario types
    :raises ValueError: Unknown scenario type
    :return: scenario type
    """
    # Check with default scenario types:
    scenario_types: Sequence[str] = Settings.SCENARIO_TYPES if types is None else types
    scenario_type = re.sub(r"^\d* ", "", scenario_name)
    if scenario_type not in scenario_types:
        _fmt = "Unknown scenario type %r"
        _log.error(_fmt, scenario_type)
        raise ValueError(_fmt % (scenario_type,))
    return scenario_type


# =============================================================================
# Various:
# =============================================================================


def overwrite_number(
    orig_value: Optional[float], overwrite_value: float, msg: str
) -> Optional[float]:
    """
    Helper function to overwrite attribute, or not (numerical version).

    :param orig_value: original value
    :param overwrite_value: overwrite value
    :param msg: LOGGER message
    :return: original or overwrite value
    """
    if pd.isna(orig_value):
        _log.warning("%s", msg)
        return overwrite_value
    return orig_value


def overwrite_text(
    orig_text: Optional[str], default_text: str, msg: str
) -> Optional[str]:
    """
    Helper function to overwrite attribute, or not (str version).

    :param orig_text: original text value
    :param default_text: overwrite text value
    :param msg: LOGGER message
    :return: original or overwrite value
    """
    if pd.isna(orig_text):
        _log.warning("%s", msg)
        return default_text
    return orig_text


def datetime2yyyymmdd_int(datetime_val: dt.datetime) -> int:
    """Convert a datatime value into a YYYYMMDD formatted integer value.

    :param datetime_val: the datetime value to convert
    :return: the date part, formatted as YYYYMMDD, converted to an int
    """
    return int(datetime_val.strftime(DATE_FMT))


def yyyymmdd_int2datetime(yyyymmdd_int: int) -> dt.datetime:
    """Convert a YYYYMMDD formatted integer value into a datatime value.

    :param yyyymmdd_int: the date, coded as YYYYMMDD
    :return: the corresponding datetime, with the time set to midnight
    """
    return dt.datetime.strptime(str(yyyymmdd_int), DATE_FMT)


def unnone(value: Any, default_if_none: Any) -> Any:
    """Return a default value in case the first parameter is None.

    :param value: The value to return, unless it is None
    :param default_if_none: The value to return in case `value` is None
    :return: one of the two passed values
    """
    return default_if_none if value is None else value


def identity(obj: _T) -> _T:
    """Return the given argument unchanged.

    :param obj: the object to return
    :return: the object passed as an argument
    """
    return obj


def make_datetime_filestamp(current_datetime: dt.datetime) -> str:
    """Make up a string representing a datetime stamp suitable for a file name.

    :param current_datetime: Used as the source datetime to derive the stamp from
    :return: the passed datetime formatted according to '%Y%m%d%H%M' format
    """
    return current_datetime.strftime("%Y%m%d%H%M")


def parse_iso_ish_date(date_val_str: str) -> dt.date:
    """Create a Python date instance from a str formatted as an iso'ish date.

    The function tries to parse the datetime string according to the entries
    defined in the `_DATETIME_FMTS` list.  It subsequently checks if the time-part
    is zero.

    :param date_val_str: the date as an iso'ish formatted string.
    :raises ValueError: The provided argument has a non-zero time element in it.
    :return: the date instance
    """
    dt_val = parse_iso_ish_datetime(date_val_str)
    if dt_val.hour or dt_val.minute or dt_val.second or dt_val.microsecond:
        raise ValueError(f"date string {date_val_str!r} has a non-zero time part in it")
    return dt_val.date()


def parse_iso_ish_datetime(datetime_val_str: str) -> dt.datetime:
    """Create a Python datetime instance from a str formatted as an iso'ish date(time).

    The function tries to parse the datetime string according to the entries
    defined in the `_DATETIME_FMTS` list.

    :param datetime_val_str: the date (+ time) as an iso'ish formatted string.
    :raises ValueError: the provided parameter does not match any of the supported
      datetime formats
    :return: the datetime instance
    """
    for fmt in _DATETIME_FMTS:
        try:
            return dt.datetime.strptime(datetime_val_str, fmt)
        except ValueError:
            pass
    # Loop exhausted. hence none of the datetime formats matched
    raise ValueError(
        f"time data {datetime_val_str!r} does not match"
        f" any of the formats {_DATETIME_FMTS!r}"
    )


def get_named_tuple_fields(
    named_tuple_or_inst: Union[NamedTupleLike, Type[NamedTupleLike]]
) -> Tuple[str, ...]:
    """Return the field names of the named tuple type or instance thereof.

    Concentrated in one single function so we only have to disable this
    warning of accessing this "semi-public" data member only once.

    :param named_tuple_or_inst: a named tuple (type or its instance)
    :return: a tuple containing the field names
    """
    # noinspection PyProtectedMember
    return named_tuple_or_inst._fields


def named_tuple_asdict(named_tuple: NamedTupleLike) -> Dict[str, Any]:
    """Return an OrderedDict which maps field names to their corresponding values.

    This function simply calls the ``... ._asdict()`` method on the parameter.
    Concentrated in one single function so we only have to disable this
    warning of accessing this "semi-public" method only once.

    :param named_tuple: a named tuple instance
    :return: an OrderedDict with field names and their corresponding values
    """
    # noinspection PyProtectedMember
    return named_tuple._asdict()


def snake_to_upper_camel(word: str) -> str:
    """Convert snake_case to UpperCamelCase.

    :param word: word in snake_case
    :return: word in UpperCamelCase
    """
    return "".join(part.capitalize() or "_" for part in re.split("_", word))


class TicksCounter:
    """Simple class to count how many times it is called."""

    def __init__(self):
        """Create a new enumerator instance."""
        self._count = 0

    def __call__(self, *args: Any, **kwargs: Any) -> None:
        """Increment count; can be called with arbitrary arguments."""
        del args, kwargs
        self._count += 1

    def tick_1_arg(self, _: Any) -> None:
        """Increment count; can be called with exactly one argument."""
        self._count += 1

    @property
    def count(self) -> int:
        """Return the count."""
        return self._count


def nan2none(value: float) -> Optional[float]:
    """Convert a NaN value to None (in preparation for nullable db-output).

    :param value: the value that might need conversion
    :return: the original value or None if it was math.nan
    """
    return None if math.isnan(value) else value


def compose2(g_func: Callable, f_func: Callable) -> Any:
    """Return the composition of two functions.

    When this function is called, function `g_func` will be called with
    the argument being the returned value of the function call
    of `f_func` with the (keyword) args provided.

    More info: https://stackoverflow.com/a/24047214/9395968,
    and https://en.wikipedia.org/wiki/Function_composition

    :param g_func: the function to call on the result of `f_func`
    :param f_func: the first function to call on the (keyword) args
      provided
    :return: a new callable, being the composition of the two
      functions (callables) provided
    """
    return lambda *args, **kwargs: g_func(f_func(*args, **kwargs))


def swagger_model_to_repr(model_inst: Model) -> str:
    """Make a one-line string representation of a Swagger Model instance object.

    :param model_inst: the Swagger Model instance object
    :return: the string representation
    """
    return (
        f"{model_inst.__class__.__qualname__}"
        f"({', '.join(f'{key}={val!r}' for key, val in model_inst.to_dict().items())})"
    )


# TODO [AB]: Improved from MSR.ScenarioCreator.Py project.
#  Make it an multi-usable module.
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
def basename_part(url_str: str) -> str:
    """Return the last path component from a URL string.

    This also works for a non-file type URL (e.g. 'https:...').

    :param url_str: the URL string to get the basename part of it
    :return: the basename part
    """
    return _get_path_part_from_url(Request(url_str)).name


# TODO [AB]: Improved from MSR.ScenarioCreator.Py project.
#  Make it an multi-usable module.
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
def _get_path_part_from_url(request: Request) -> Path:
    """Return the path (AKA selector) part of a URL Request, as Path instance.

    For more information on a properly formatted URL, especially on Windows,
    refer to:
    * https://blogs.msdn.microsoft.com/ie/2006/12/06/file-uris-in-windows/
    * https://bugs.python.org/issue5609

    :param request: the URL (as Request instance) to get the path part from
    :raises ValueError: the URL string is not properly formatted
      (probably missing a third slash ('/') after 'file:')
    :return: the path (AKA selector) part
    """
    selector = request.selector
    if not selector:
        raise ValueError(
            f"url string {request.full_url!r} does not contain path (or is malformed)"
        )
    # File URLs from NT UNC paths contain a host part
    if request.host:  # pragma: no cover
        selector = "////" + request.host + selector
    return Path(url2pathname(selector))


# TODO [AB]: Improved from MSR.ScenarioCreator.Py project.
#  Make it an multi-usable module.
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
def url_str2path(url_str: str) -> Path:
    """Convert a URL string (URI) to a Path object.

    This function implements the exact inverse operation of `Path.as_uri()`.

    :param url_str: the URL string to convert
    :raises ValueError: the URL string is not a file type URL
      (i.e. it should start with 'file://')
    :return: the converted URL to a regular Path object
    """
    request = Request(url_str)
    if request.type != "file":
        raise ValueError(f"url string {url_str!r} is not a file-type url")
    return _get_path_part_from_url(request)
