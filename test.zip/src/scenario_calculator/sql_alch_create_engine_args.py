# type: ignore[attr-defined]
"""Converting an SqlAlchemy connection string into odbc driver connect args"""

import typing
from functools import partial
from importlib import import_module

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.engine.url import make_url
from sqlalchemy.exc import NoSuchModuleError

from scenario_calculator.db_connect_utils import odbc_attr_val_quote, str2mswin_bstr

# Silencing the following false positive (bandit):
# https://bandit.readthedocs.io/en/latest/plugins/b105_hardcoded_password_string.html
_COPT_SS_ACCESS_TOKEN_KEY = "SQL_COPT_SS_ACCESS_TOKEN"  # nosec
_CONNECT_ATTRS_BEFORE_KW = "attrs_before"
_CREATE_CONNECT_ARGS_KW = "connect_args"

# See https://github.com/mkleehammer/pyodbc/issues/228#issuecomment-319190980 :
# """SQL_COPT_SS_ACCESS_TOKEN is 1256; it's specific to msodbcsql driver
#    so pyodbc does not have it defined, and likely will not."""
_SQL_COPT_SS_ACCESS_TOKEN = 1256
_SQL_ALCH_URL_ATTRS = (
    "drivername",
    "username",
    "password",
    "host",
    "port",
    "database",
    "query",
)


class SqlAlchCreateEngineArgs:
    def __init__(self, sql_alch_conn: str, **kwargs: typing.Any) -> None:
        """Initialize this structure with a validated URL and keyword args.

        The passed connection string is converted into an SqlAlchemy URL
        and this URL is subsequently checked whether it contains a valid
        drivername-part, ready to be processed further.

        :param sql_alch_conn: The SqlAlchemy connection string
        :param kwargs: The initial set of keyword arguments (if any)
          to eventually call `create_engine` with
        """
        self.url = make_url(sql_alch_conn)
        self.kwargs = kwargs
        self._check_valid_url_scheme()

    def _check_valid_url_scheme(self) -> None:
        """Check whether the URL attr contains a valid drivername-part.

        :raise: UnsupportedUrlSchemeError when invalid
        """
        try:
            self.url.get_dialect()
        except NoSuchModuleError as exc:
            raise UnsupportedUrlSchemeError(
                f"Unsupported URL Scheme: {self.url.drivername!r}"
            ) from exc

    def create_engine(self) -> Engine:
        """Calls SqlAlchemy `create_engine` after preparing the URL and kwargs.

        First, all necessary conversions are being applied to make a suitable
        URL and kwargs. This is done in a few subsequent steps:
        1 Any non-standard query parameters are converted, resulting into a
          tuple consisting of:
          * an SqlAlchemy URL, and
          * additional_arguments for the connect_args keyword parameter.
        2 All applicable URL query attributes are converted into associated
          odbc connect attributes, coded into a string and subsequently
          assigned to the odbc_connect URL query parameter.
        3 This result set is even further processed, resulting in a barebone
          SqlAlchemy connection URL, and keyword arguments providing for
          a callable that establishes the lower level SQL Driver connection
          to be used for the higher level SqlAlchemy ORM.

        Step 3) has only effect when the driver_name part of the
        connection string template equals "pyodbc".

        Finally, the resulting URL and keyword arguments are passed to the
        SqlAlchemy `create_engine` function and the resulting `Engine`
        instance is being returned.

        :return: The created Engine instance.
        """
        # Apply step 1 from above description
        self.extract_and_convert_url_pseudo_params()
        # Apply step 2 from above description
        self.convert_url_attrs_into_odbc_attrs()
        # Apply step 3 from above description
        self.maybe_convert_to_creator_arg()
        return create_engine(self.url, **self.kwargs)

    def extract_and_convert_url_pseudo_params(self) -> None:
        """Extract and convert a query attribute that should be binary encoded.

        The sort-of fake "SQL_COPT_SS_ACCESS_TOKEN" query-part, if present,
        will be extracted from the query parameters.  The corresponding
        attribute value is converted into a value suitable for passing into
        the DbApi `connect` function.

        The actual conversion is explained in the following url:
        https://github.com/mkleehammer/pyodbc/issues/228#issuecomment-319190980

        The converted value can be passed as a `connect_args` named parameter
        to SqlAlchemy's `create_engine()` function.

        The resulting SqlAlchemy attributes will subsequently be passed to
        `convert_url_attrs_into_odbc_attrs()` for further processing, after
        which the modified SqlAlchemy connection URL can be reconstructed.

        Please note that the newly constructed and returned URL cannot be
        converted back to a connection string suitable for passing to
        `create_engine`; you will have to use this returned `URL` object.

        :raises TypeError: key "SQL_COPT_SS_ACCESS_TOKEN" occurred multiple times
          in the URL query parameters
        :raises ValueError: the _SQL_COPT_SS_ACCESS_TOKEN (1256) was already present
          in the "attrs_before" parameter
        """
        copt_ss_token_val = self.url.query.pop(_COPT_SS_ACCESS_TOKEN_KEY, None)
        if copt_ss_token_val is None:
            return
        if isinstance(copt_ss_token_val, list):
            raise TypeError(
                f"Unexpected multiple values for key{_COPT_SS_ACCESS_TOKEN_KEY!r}"
            )
        # Fetch the connect_args dict from the create kwargs, if present
        connect_args = self.kwargs.get(_CREATE_CONNECT_ARGS_KW, {})
        attrs_before_val = connect_args.setdefault(_CONNECT_ATTRS_BEFORE_KW, {})
        if _SQL_COPT_SS_ACCESS_TOKEN in attrs_before_val:
            raise ValueError(
                f"Value for {_COPT_SS_ACCESS_TOKEN_KEY!r}"
                f" ({_SQL_COPT_SS_ACCESS_TOKEN}) is already present"
                f" within {_CONNECT_ATTRS_BEFORE_KW!r}-entry"
                f" within {_CREATE_CONNECT_ARGS_KW!r} keyword parameter"
                f" for `create_engine` call"
            )
        # From here onwards, we know for sure we'll be needing a `connect_args`
        # keyword argument; connect it to kwargs
        self.kwargs[_CREATE_CONNECT_ARGS_KW] = connect_args
        # Apply the conversion, new key and new value
        attrs_before_val[_SQL_COPT_SS_ACCESS_TOKEN] = str2mswin_bstr(copt_ss_token_val)

    def convert_url_attrs_into_odbc_attrs(self) -> None:
        """Change SqlAlchemy URL attribs generating pyodbc connection string.

        The pyodbc connection string is on its turn encoded in a query
        parameter named "odbc_connect".

        This function is needed in order to bypass the (sometimes wrong)
        automatic translation from an SqlAlchemy compatible connection URL to
        the lower level sql driver URL. More in particular, the following
        conversions are IMHO wrong:
        * generating an empty password in case a username is given, or
        * requesting a "trusted connection" in case no username is provided.

        This function returns the dictionary unchanged when a driver (dialect)
        other than `pyodbc` is passed.

        An example: pyodbc://usr:pass@srvr:1234/dbase?driver=some-text&p2=foo"
          will be converted into an URL looking sort of like:
        "pyodbc://?odbc_connect=encoded-odbc-connect&p2=foo", where
          encoded-odbc-connect is the quote_plus-encoded form of:
          "UID=q-usr;PWD=****;SERVER=q-srvr;PORT=1234
           ;DATABASE=q-dbase;DRIVER=q-some-text",
          and the q- variants are `the odbc_attr_val_quote`-d (qv.) form
          of the original attribute value.
        """
        if self.url.get_driver_name() != "pyodbc":
            return
        if "odbc_connect" in self.url.query:
            raise ValueError(
                f'{"odbc_connect!r"} already present'
                f" in SqlAlchemy URL query parameters"
            )
        odbc_connection_attrs: typing.Dict[str, typing.Any] = {}

        for attr_name in _SQL_ALCH_URL_ATTRS:
            attr_val = getattr(self.url, attr_name)
            setattr(
                self.url,
                attr_name,
                _process_url_attr_for_odbc(odbc_connection_attrs, attr_name, attr_val),
            )
        pyodbc_conn_str = ";".join(
            f"{odbc_attr_name}={odbc_attr_val_quote(str(odbc_attr_val))}"
            for odbc_attr_name, odbc_attr_val in odbc_connection_attrs.items()
        )

        self.url.query["odbc_connect"] = pyodbc_conn_str

    def maybe_convert_to_creator_arg(self) -> None:
        """Modify parameters so that dbapi connection will be created directly.

        This is implemented only when pyodbc is mentioned as driver.

        And if that is the case, the query parameters (dict) from the
        SqlAlchemy URL are expected to contain:
        * the `odbc_connect` parameter that will be passed as the first
          argument to the driver `connect` routine.
        And the `self.kwargs` dict to optionally contain:
        * the `connect_args` parameter that contains a dict of additional
          keyword arguments to pass to the driver `connect` routine.

        For more info, see 3rd variant of
        https://docs.sqlalchemy.org/en/13/core/engines.html#custom-dbapi-connect-arguments
        """
        driver_name = self.url.get_driver_name()
        if driver_name != "pyodbc":
            return
        driver = import_module(driver_name)
        # remove that part from the drivername
        self.url.drivername = self.url.get_backend_name()
        driver_args = (self.url.query.pop("odbc_connect"),)
        driver_kwargs = self.kwargs.pop("connect_args", {})
        connect_callable = partial(driver.connect, *driver_args, **driver_kwargs)
        self.kwargs["creator"] = connect_callable


URL_ATTR_VAL_TYPE = typing.Union[None, str, int, typing.Mapping[str, str]]


def _process_url_attr_for_odbc(
    odbc_connection_attrs: typing.Dict[str, typing.Any],
    attr_name: str,
    attr_val: URL_ATTR_VAL_TYPE,
) -> URL_ATTR_VAL_TYPE:
    """Perhaps convert Sql Alchemy URL attribute to ODBC connection attribute.

    :param odbc_connection_attrs: the odbc connection attributes in the making
    :param attr_name: the name of the SqlAlchemy attribute
    :param attr_val: the value of the SqlAlchemy attribute
    :raise AssertionError: internal inconsistency: the mapped attribute is not a string
      and is not callable
    :return: the possible modified new value of the attribute, possibly None
    """
    # Check whether this attribute has an equivalent in odbc
    attr_keyword = _SQL_ALCH_URL_ATTR_2_ODBC_ATTR.get(attr_name, None)
    if attr_keyword is None:
        # Nope, no equivalent - just leave it like it was
        return attr_val
    if isinstance(attr_keyword, str):
        # Apparently yes, it has
        if attr_val is not None:
            # convert is to the odbc connection attribute
            odbc_connection_attrs[attr_keyword] = attr_val
        # and nullify the original
        return None
    if callable(attr_keyword):
        # This is a special one, let the function will do the work.
        # Currently, this is only the case for the "query" attribute
        # and we know that the value is a dict.
        return attr_keyword(
            odbc_connection_attrs, typing.cast(typing.Dict[str, str], attr_val)  # type: ignore # noqa
        )
    raise AssertionError(
        f"attr_keyword {attr_keyword!r} is not a string and is not callable"
    )  # pragma: no cover


def _process_query_params_for_odbc(
    odbc_connection_attrs: typing.Dict[str, typing.Any],
    query_params: typing.Dict[str, str],
) -> typing.Dict[str, str]:
    """Convert query parameters from SqlAlchemy URL into ODBC suitable params.

    For example: "drv://.../?driver=some-text&other=..." : the driver-part
    is removed from the query dict and coded into "DRIVER={some-text}" fragment
    that can be used in an odbc connection string.

    :param query_params: The query parameters from an SqlAlchemy URL
    :param odbc_connection_attrs: A list of ODBC attributes (in/out)
    :return: modified query_params
    """
    result_query_params: typing.Dict[str, str] = {}
    for key, val in query_params.items():
        attribute_keyword = _SQL_ALCH_QUERY_2_ODBC_KEY.get(key, None)
        if attribute_keyword is None:
            result_query_params[key] = val
        else:
            # Convert it to the odbc connection attributes
            odbc_connection_attrs[attribute_keyword] = val
    return result_query_params


class UnsupportedUrlSchemeError(Exception):
    pass


_SQL_ALCH_QUERY_2_ODBC_KEY = {"driver": "DRIVER", "authentication": "Authentication"}
_SQL_ALCH_URL_ATTR_2_ODBC_ATTR: typing.Dict[
    str,
    typing.Union[
        str,
        typing.Callable[
            [typing.Dict[str, str], typing.List[str]], typing.Dict[str, str]
        ],
    ],
] = {
    "username": "UID",
    "password": "PWD",
    "host": "SERVER",
    "port": "PORT",
    "database": "DATABASE",
    "query": _process_query_params_for_odbc,  # type: ignore # noqa
}
