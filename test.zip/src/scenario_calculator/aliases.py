# -*- coding: utf-8 -*-
"""
Contains aliases for use throughout the code.
"""

from typing import Union

# What a main routine can return.
MainReturnType = Union[None, int, str]

# What to pass as a logging level
LoggingLevelType = Union[int, str]
