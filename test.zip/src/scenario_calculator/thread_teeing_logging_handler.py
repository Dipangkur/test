"""Create additional logging output streams, within a specific thread.

TODO: Please note that this actual implementation of logging between technical
  level and application level is still under architectural discussion, see
  https://raboweb.visualstudio.com/CAS/_workitems/edit/648719.
"""

import threading
from contextlib import contextmanager
from logging import NOTSET, Handler, LogRecord
from typing import Callable, Dict, Generator, Optional, Union

import attr


@attr.attrs(eq=False, frozen=True, auto_attribs=True)
class _TeeLoggingSetting:
    """Data class holding logging settings (per thread)."""

    log_line_cb: Callable[[str], None]
    log_level: int


class ThreadTeeingLoggingHandler(Handler):
    """Logging Handler capable of providing formatted log lines per thread.

    Within the `capture_log_lines_for_current_thread`-context, a provided
    callback function is being called with a to a string formatted log entry,
    if the log entry passes the provided (log-level) filter criteria.

    Normally, only one instance of this type of log handler needs to be installed
    in the logging system.  It only becomes active when one or more of the
    `capture_log_lines_for_current_thread()` contexts are active.

    So one instance manages multiple threads.
    """

    def __init__(
        self, need_io_thread_lock: bool = False, level: Union[int, str] = NOTSET
    ) -> None:
        """Initialize an instance, possibly specifying a filter log level and locking.

        If the caller collects output from different threads to the same output
        structure or stream, then the caller should set `need_io_thread_lock` to a
        trueish value.

        A `level` parameter can be provided. Logs with a lower level are never
        considered for the output stream(s) within this handler.

        :param need_io_thread_lock: specifies wheter the caller wants a I/O output
          thread-lock.
        :param level: the overall level to filter the logs for this handler.
        """
        self._need_io_thread_lock = need_io_thread_lock
        super().__init__(level)
        self._settings_lock = threading.RLock()
        self._thread_tee_logging_settings: Dict[Optional[int], _TeeLoggingSetting] = {}
        self.addFilter(self._per_thread_filter)

    @contextmanager
    def capture_log_lines_for_current_thread(
        self, log_line_cb: Callable[[str], None], level: int = NOTSET
    ) -> Generator:
        """Create a context in which additional logs might be emitted.

        Within this context, any logs routed to this handler being of high enough
        logging level are emitted by calling a callback function.

        :param log_line_cb: a callback function that actually will handle the
          further processing of this rendered log line, which is (already)
          terminated by a newline.
        :param level: the level to filter for this specific thread
          (should be an int instance, providing a symbolic string is not possible).
        :return: None
        """
        self._atomic_modify_thread_tee_logging_settings(
            _TeeLoggingSetting(log_line_cb, level)
        )
        try:
            yield
        finally:
            self.flush()  # FWIW
            self._atomic_modify_thread_tee_logging_settings(None)

    def _atomic_modify_thread_tee_logging_settings(
        self, logging_setting: Optional[_TeeLoggingSetting]
    ) -> None:
        """Change the thread_tee_settings atomically for the current thread.

        The operation depends on the passed value:
        * When an `_TeeLoggingSetting` instance is passed, this info is added
          for the current thread.
        * When `None` is passed, the entry is removed for the current thread.

        :param logging_setting: the setting to register for this thread, or removed.
        """
        thread_id = threading.current_thread().ident
        self._settings_lock.acquire()
        try:
            if logging_setting is None:
                del self._thread_tee_logging_settings[thread_id]
            else:
                self._thread_tee_logging_settings[thread_id] = logging_setting
        finally:
            self._settings_lock.release()

    def createLock(self) -> None:
        """Create a lock when explicitly requested so during `__init__()`.

        In general is is not needed to create an I/O thread lock for this output,
        assuming each thread's output goes to a separate "thing" (that's what this
        functionality is created for in the first place).

        We *do* need a lock though for manipulating the `_per_thread_log_setttings`
        attribute. It is called `_settings_lock`, but - again - for `emit()`
        purposes it is probably not needed.

        (This method is called by the super() __init__ routine)
        """
        if self._need_io_thread_lock:  # NOSONAR -- review [TODO] test case.
            super().createLock()
        else:
            # noinspection PyAttributeOutsideInit
            self.lock: Optional[threading.Lock] = None

    def _per_thread_filter(self, record: LogRecord) -> bool:
        """Special filtering, depending on this handler settings for the current thread.

        :return: Whether this log should be included, purely from this handler's
          setting for the applicable thread.
        """
        this_logging_setting = self._thread_tee_logging_settings.get(
            record.thread, None
        )
        return (
            this_logging_setting is not None
            and record.levelno >= this_logging_setting.log_level
        )

    def emit(self, record: LogRecord) -> None:
        """Handle the actual output of this handler (i.e. call the callback function).

        The log record is converted into a string, and in accordance with the
        general Python convention, a newline is added to it. It is subsequently
        passed as an argument to the callback function provided for the applicable
        thread.

        :param record: The record to output.
        """
        this_logging_setting = self._thread_tee_logging_settings.get(
            record.thread, None
        )
        if this_logging_setting is None:
            # This can only happen when `emit()` is called directly, and not through
            #  `handle()`. Otherwise this record would already been filtered out.
            return
        this_logging_setting.log_line_cb(self.format(record) + "\n")
