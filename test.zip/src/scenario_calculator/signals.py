import logging
import signal
from types import FrameType

_SIGNALS_TO_HANDLE = (signal.SIGTERM,)
_log = logging.getLogger(__name__)


def install_signal_handlers() -> None:
    """Install for some signals a signal handler that terminates the program.

    Currently, the set of signals is limited to ``signal.SIGTERM``, as
    as configured in this module ``_SIGNALS_TO_HANDLE`` list.
    """

    class ProgramTerminationException(Exception):
        pass

    def signal_handler(signum: int, frame: FrameType) -> None:
        del frame
        _log.info("Caught signal %d; raising ApiTermination", signum)
        raise ProgramTerminationException(f"termination requested by signal {signum}")

    _log.debug("Installing signal handlers for signals %r", _SIGNALS_TO_HANDLE)
    for signo in _SIGNALS_TO_HANDLE:
        signal.signal(signo, signal_handler)
