# type: ignore[attr-defined]
"""Converting an SqlAlchemy connection string into odbc driver connect args"""

import functools
import logging
import re
import struct
import typing
from itertools import chain, repeat
from urllib.parse import quote_plus

from msrestazure.azure_active_directory import MSIAuthentication

from scenario_calculator.utility import compose2

_DATABASE_AUTHENTICATION_RESOURCE = "https://database.windows.net/"


_log = logging.getLogger(__name__)


class ExecutedWhenStringified(functools.partial):
    """Same as `functools.partial`, called when `str()` is applied to it.

    This provides a small addition to its parent class. When an instance
    is converted to a string, it calls itself without any additional
    arguments, converts the returned value to str and returns it.
    """

    def __str__(self):
        return str(self())


def fill_sql_alchemy_url_template(
    sql_alchemy_conn_template: str,
    msi_auth_func: typing.Callable[[typing.Optional[str]], str],
) -> str:
    """Fill (iff needed) an SqlAlchemy connection string template with values.

    The template is parsed as a new style format string with keyword
    replacements.
    See https://docs.python.org/3/library/string.html#formatstrings for
    the formal specification.

    The following field names are supported:
    * token: will be replaced by the return value of `msi_auth_func`,
      subsequently quoted by `urllib.parse.quote_plus`.
    * database_token: will be replaced by the return value of `msi_auth_func`
      called with `_DATABASE_AUTHENTICATION_RESOURCE` as parameter,
      subsequently quoted by `urllib.parse.quote_plus`.

    :param sql_alchemy_conn_template: the SqlAlchemy connection string
    :param msi_auth_func: the authentication function to call for
      the access token
    :return: a properly filled SqlAlchemy connection string
    """
    return sql_alchemy_conn_template.format_map(
        {
            "token": ExecutedWhenStringified(compose2(quote_plus, msi_auth_func)),
            "database_token": ExecutedWhenStringified(
                compose2(quote_plus, msi_auth_func), _DATABASE_AUTHENTICATION_RESOURCE
            ),
        }
    )


def get_msi_authentication_access_token(
    resource: typing.Optional[str] = None,
) -> str:  # pragma: no cover
    """Get AAD access token for a resource.

    :param resource: The optional resource to call `MSIAuthentication` with
    :return: the "access_token" member of the credentials obtained by
      calling `MSIAuthentication` optionally with the provided `resource`
      argument.
    """
    msi_auth_kwargs: typing.Dict[str, str] = (
        {} if resource is None else {"resource": resource}
    )
    credentials = MSIAuthentication(**msi_auth_kwargs)
    access_token: str = credentials.token["access_token"]
    _log.debug(
        "access_token(%s): len %s, token: %s",
        _as_keywords_repr_lazy(msi_auth_kwargs),
        len(access_token),
        repr(access_token[:7]) + "..." + repr(access_token[-3:]),
    )
    return access_token


def _as_keywords_repr_lazy(
    kwargs: typing.Mapping[str, typing.Any]
) -> ExecutedWhenStringified:  # pragma: no cover
    """Same as _as_keywords_repr, but only evaluated when stringified."""
    return ExecutedWhenStringified(_as_keywords_repr, kwargs)


def _as_keywords_repr(
    kwargs: typing.Mapping[str, typing.Any]
) -> str:  # pragma: no cover
    """Return representation of kwargs in 'key=value' syntax."""
    return ", ".join(f"{key!s}={val!r}" for key, val in kwargs.items())


def odbc_attr_val_quote(value: str) -> str:
    """Quote the attribute-value of an ODBC driver connection string.

    See
    https://docs.microsoft.com/en-us/sql/relational-databases/native-client/applications/using-connection-string-keywords-with-sql-server-native-client?view=sql-server-2017#odbc-driver-connection-string-keywords
    for more information.

    Example:
        >>> odbc_attr_val_quote("some.domain.name")
        'some.domain.name'
        >>> odbc_attr_val_quote("ODBC Driver 17 for SQL Server")
        '{ODBC Driver 17 for SQL Server}'

    :param value: the value to quote
    :raises ValueError: the provided value cannot be odbc_attr_val_quote'd
    :return: the quoted value, suitable for a connection string
    """
    if re.search(r"[^-/\w.,}]", value):
        if "}" in value:
            raise ValueError(
                "Cannot odbc_attr_val_quote value needing quoting and containing '}'"
            )
        return f"{{{value}}}"
    return value


def str2mswin_bstr(value: str) -> bytes:
    """Convert a str-typed token into a (MS-Windows) BSTR (as bytes).

    This happens in two steps:
    * The string is converted into bytes, assuming the string contains
      only ASCII characters.
    * The resulting 'binary' token is converted into the BSTR. See
      `bytes2mswin_bstr` for more info.

    :param value: the text-based token (fitting the ASCII coding)
    :return: the converted value (as a sequence of bytes)
    """
    return bytes2mswin_bstr(value.encode("ascii"))


def bytes2mswin_bstr(value: bytes) -> bytes:
    """Convert a sequence of bytes into a (MS-Windows) BSTR (as bytes).

    See https://github.com/mkleehammer/pyodbc/issues/228#issuecomment-319190980
    for the original code.  It appears the input is converted to an
    MS-Windows BSTR (in 'Little-endian' format).

    See https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-dtyp\
       /692a42a9-06ce-4394-b9bc-5d2a50440168
    for more info on BSTR.

    :param value: the sequence of bytes to convert
    :return: the converted value (as a sequence of bytes)
    """
    # The original code from the provided github URL applies 'Little-endian'
    # to the byte conversion in a python for-loop.
    # The following is code is assumed to be faster.
    encoded_bytes = bytes(chain.from_iterable(zip(value, repeat(0))))
    # The original code applies native endianness for encoding the length
    # prefix. My working assumption that also the length should be encoded
    # 'Little-endian', regardless of the CPU (and OS) this code is running on.
    return struct.pack("<i", len(encoded_bytes)) + encoded_bytes
