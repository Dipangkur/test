"""Definitions of the ScenarioCalculator Events for the EventLogger."""

CALCULATE_SCENARIO_EVENT = {
    "EventType": "CalculateScenario",
    "NumberOfSteps": 13,
    "Name": "Calculate scenario",
    "Description": "Scenario Calculated",
    "ViewableBy": "Maintainer, Process Controller",
    "IsMajorEvent": True,
    "IsLast": False,
}

CALCULATE_LAB_SCENARIO_EVENT = {
    "EventType": "CalculateLabScenario",
    "NumberOfSteps": 13,
    "Name": "Calculate lab scenario",
    "Description": "Lab Scenario Calculated",
    "ViewableBy": "Maintainer, Process Controller",
    "IsMajorEvent": True,
    "IsLast": False,
}

# [1] Reading data from database
RETRIEVE_INPUT_DATA_EVENT = {
    "EventType": "RetrieveInputData",
    "NumberOfSteps": 1,
    "Name": "Retrieve Input Data",
    "Description": "Retrieving Input Data",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# TODO: CHANGE THE EVENTS NUMBERING
APPLY_AGRILAND_MODEL_EVENT = {
    "EventType": "ApplyAgrilandModel",
    "NumberOfSteps": 1,
    "Name": "Apply Agriland Model",
    "Description": "Applies Agriland Model",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [1.1] Adding missing rxeu values
ADD_MISSING_RXEU_VALUES_EVENT = {
    "EventType": "AddMissingRxeuValues",
    "NumberOfSteps": 1,
    "Name": "Add Missing RXEU Values",
    "Description": "Adding Missing RXEU Values",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}


# [1.2] Calculating Other Country
CALCULATE_AND_APPEND_OTHER_COUNTRY_EVENT = {
    "EventType": "CreateOtherCountryData",
    "NumberOfSteps": 1,
    "Name": "Create Other Country",
    "Description": "Creating Other Country",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [1.3] Extending Dynamic Data
MAKE_THE_FIRST_EXTENSION_EVENT = {
    "EventType": "ExtendDynamicDataColumns",
    "NumberOfSteps": 1,
    "Name": "Extend Dynamic Data Columns",
    "Description": "Extending Dynamic Data Columns",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [2] Extending TimeSeries
EXTEND_TIME_SERIES_EVENT = {
    "EventType": "ExtendTimeSeries",
    "NumberOfSteps": 1,
    "Name": "Extend Time Series",
    "Description": "Extending Time Series",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [3] Converting unit of series
CONVERT_UNIT_OF_SERIES_EVENT = {
    "EventType": "ConvertUnitOfSeries",
    "NumberOfSteps": 1,
    "Name": "Convert Unit Of Series",
    "Description": "Converting Unit Of Series",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [4] Deriving new series
DERIVE_NEW_SERIES_EVENT = {
    "EventType": "DeriveNewSeries",
    "NumberOfSteps": 1,
    "Name": "Derive New Series",
    "Description": "Deriving New Series",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [5] Applying regression modelling
APPLY_REGRESSION_MODELLING_EVENT = {
    "EventType": "ApplyRegressionModelling",
    "NumberOfSteps": 1,
    "Name": "Apply Regression Modelling",
    "Description": "Applying Regression Modelling",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [6] Aggregation to yearly ABS data
AGGREGATION_TO_YEARLY_ABS_DATA_EVENT = {
    "EventType": "AggregateToYearlyAbsData",
    "NumberOfSteps": 1,
    "Name": "Aggregation To Yearly ABS Data",
    "Description": "Aggregating to yearly ABS data",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [7] Transforming from ABS to YOY and Y-Y
TRANSFORM_FROM_ABS_TO_YOY_DELTA_Y_EVENT = {
    "EventType": "XformFromAbsToYoyAndYtY",
    "NumberOfSteps": 1,
    "Name": "Transform from ABS to YOY and Y-Y",
    "Description": "Transforming from ABS to YOY and Y-Y",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [8] Combining transformed-aggregated data
COMBINE_TRANSFORMED_AGGREGATED_DATA_EVENT = {
    "EventType": "CombineXformedAggregated",
    "NumberOfSteps": 1,
    "Name": "Combine transformed-aggregated data",
    "Description": "Combining transformed-aggregated data",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [9] Setting standardization parameter
SET_STANDARDIZATION_PARAMETER_EVENT = {
    "EventType": "SetStandardizationParam",
    "NumberOfSteps": 1,
    "Name": "Set standardization parameter",
    "Description": "Setting standardization parameter",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [10] Mapping missing series
MAP_MISSING_SERIES_EVENT = {
    "EventType": "MapMissingSeries",
    "NumberOfSteps": 1,
    "Name": "Map missing series",
    "Description": "Mapping missing series",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [11] Mapping missing countries
MAP_MISSING_COUNTRIES_EVENT = {
    "EventType": "MapMissingCountries",
    "NumberOfSteps": 1,
    "Name": "Map missing countries",
    "Description": "Mapping missing countries",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [12] Make Ready to Write
MAKE_READY_TO_WRITE_EVENT = {
    "EventType": "MakeReadyToWrite",
    "NumberOfSteps": 1,
    "Name": "Make Ready to Write",
    "Description": "Preparing writing to db",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

# [13] Writing output
WRITE_OUTPUT_EVENT = {
    "EventType": "WriteOutput",
    "NumberOfSteps": 1,
    "Name": "Write output",
    "Description": "Writing output",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": False,
}

LAST_EVENT = {
    "EventType": "LastEvent",
    "NumberOfSteps": 1,
    "Name": "Last event",
    "Description": "The last event is processed",
    "ViewableBy": "Maintainer",
    "IsMajorEvent": False,
    "IsLast": True,
}
