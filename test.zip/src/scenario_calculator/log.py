# type: ignore[attr-defined]
import copy
import logging
import os
from logging.config import dictConfig
from pathlib import Path
from typing import Any, Dict, List, Optional

from applicationinsights.exceptions import enable
from more_itertools import one

from scenario_calculator.aliases import LoggingLevelType
from scenario_calculator.flushing_appinsights_logging_handler import (
    FlushingAppinsightsLoggingHandler,
)
from scenario_calculator.settings import TEMP_DIR
from scenario_calculator.thread_teeing_logging_handler import ThreadTeeingLoggingHandler

# TODO [JHB]: This is to a very large extent a clone of MSR.ScenarioCreator.Py
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217

_LOG_DIR = Path(
    os.environ.get("PYTHON_LOG_PATH", TEMP_DIR / "meister_calc_logs")
).resolve()

_log = logging.getLogger(__name__)

LogConfig = Dict[str, Any]

_log_formatter = "logging.Formatter"

DEFAULT = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "classical": {
            "class": _log_formatter,
            "format": (
                "%(asctime)s %(name)-12s %(levelname)-8s %(threadName)s %(message)s"
            ),
        },
        "classical_no_ts": {
            "class": _log_formatter,
            "format": "%(name)-12s %(levelname)-8s %(threadName)s %(message)s",
        },
        "classical_no_threadname": {
            "class": _log_formatter,
            "format": "%(asctime)s %(name)-12s %(levelname)-8s %(message)s",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "classical_no_ts",
            "level": "DEBUG",
        }
    },
    "root": {"handlers": ["console"], "level": "DEBUG"},
    "loggers": {"meister": {"handlers": ["console"], "level": "DEBUG"}},
}


def _use_filelog(
    log_config: LogConfig, log_file_path: Optional[Path] = None
) -> LogConfig:  # pragma: no cover
    """Enable file logging and modify log_config to enable this.

    :param log_config: config suitable for logging.config.dictConfig.
    :param log_file_path: the file path to log to
        or None if not file logging should not be enabled/used
    :return: either the original log_config or a modified deepcopy of it
    """
    if log_file_path is not None:
        # Enables file logging
        log_config_copy = copy.deepcopy(log_config)
        log_config_copy["handlers"]["file"] = {
            "class": "logging.handlers.RotatingFileHandler",
            "formatter": "classical",
            "filename": str(log_file_path),
            "maxBytes": 24 * 1024 * 1024,
            "backupCount": 10,
        }
        root_handlers_list: List[str] = log_config_copy["root"]["handlers"]
        if "file" not in root_handlers_list:
            root_handlers_list.append("file")
        log_file_path.parent.mkdir(exist_ok=True)
        return log_config_copy
    return log_config


def _use_appinsights(
    log_config: LogConfig, appinsights_instrumentation_key: Optional[str] = None
) -> LogConfig:  # pragma: no cover
    """Enable appinsights and modify log_config to enable exception-logging.

    :param log_config: config suitable for logging.config.dictConfig.
    :param appinsights_instrumentation_key: the key for appinsights
        or None if not appinsights should not be enabled/used
    :return: either the original log_config or a modified deepcopy of it
    """
    if appinsights_instrumentation_key is not None:
        # Enables logging of exceptions
        enable(appinsights_instrumentation_key)
        # Enables logging of traces
        log_config_copy = copy.deepcopy(log_config)
        log_config_copy["handlers"]["insights"] = {
            "class": ".".join(
                (
                    FlushingAppinsightsLoggingHandler.__module__,
                    FlushingAppinsightsLoggingHandler.__qualname__,
                )
            ),
            "formatter": "classical_no_ts",
            "level": "DEBUG",
            "instrumentation_key": appinsights_instrumentation_key,
        }
        root_handlers_list: List[str] = log_config_copy["root"]["handlers"]
        if "insights" not in root_handlers_list:
            root_handlers_list.append("insights")
        return log_config_copy
    return log_config


def _use_thread_teeing_logging(
    log_config: LogConfig, tee_logs_to_major_event_and_level: Optional[LoggingLevelType]
) -> LogConfig:  # pragma: no cover
    """Install ThreadTeeingLoggingHandler and modify log_config to enable it.

    :param log_config: config suitable for logging.config.dictConfig.
    :param tee_logs_to_major_event_and_level: if not None, install the
      ThreadTeeingLoggingHandler on the indicated level.
    :return: either the original log_config or a modified deepcopy of it
    """
    if tee_logs_to_major_event_and_level is not None:
        # Enables teeing logging to an additional collector
        log_config_copy = copy.deepcopy(log_config)
        log_config_copy["handlers"]["thread_teeing"] = {
            "class": ".".join(
                (
                    ThreadTeeingLoggingHandler.__module__,
                    ThreadTeeingLoggingHandler.__qualname__,
                )
            ),
            "formatter": "classical_no_threadname",
            "level": tee_logs_to_major_event_and_level,
        }
        root_handlers_list: List[str] = log_config_copy["root"]["handlers"]
        if "thread_teeing" not in root_handlers_list:
            root_handlers_list.append("thread_teeing")
        return log_config_copy
    return log_config


# No coverage because we don't need to test logging.basicConfig
def config_logger(
    log_config: Optional[LogConfig] = None,
    log_file_path: Optional[Path] = None,
    appinsights_instrumentation_key: Optional[str] = None,
    tee_logs_to_major_event_and_level: Optional[LoggingLevelType] = None,
) -> Optional[ThreadTeeingLoggingHandler]:  # pragma: no cover
    """Configure the logging system, optionally enriched w/ additional output "streams".

    :param log_config: config suitable for logging.config.dictConfig.
        If None, this module's `DEFAULT` configuration is being used.
    :param log_file_path: the file path to log to
        or None if not file logging should not be enabled/used
    :param appinsights_instrumentation_key: the key for appinsights
        or None if not appinsights should not be enabled/used
    :param tee_logs_to_major_event_and_level: whether a ThreadTeeingLoggingHandler
      instance should be installed (including on what level), *and returned*
    :return: The installed ThreadTeeingLoggingHandler, when requested to do so.
    """
    if log_config is None:
        log_config = DEFAULT
    log_config = _use_filelog(log_config, log_file_path)
    log_config = _use_appinsights(log_config, appinsights_instrumentation_key)
    log_config = _use_thread_teeing_logging(
        log_config, tee_logs_to_major_event_and_level
    )
    dictConfig(log_config)
    if log_file_path is not None:
        _log.warning("Also logging to file %s", log_file_path)
    if appinsights_instrumentation_key is None:
        _log.warning("AppInsights not used/configured")
    if tee_logs_to_major_event_and_level is not None:
        _log.warning(
            "Also capturing logs at level %s and higher to Major Logging Event",
            logging.getLevelName(tee_logs_to_major_event_and_level)
            if isinstance(tee_logs_to_major_event_and_level, int)
            else tee_logs_to_major_event_and_level,
        )
        root_logger = logging.getLogger()
        return one(
            (
                handler
                for handler in root_logger.handlers
                if isinstance(handler, ThreadTeeingLoggingHandler)
            )
        )
    return None
