"""Manifest constants not expected to change ever."""
from enum import Enum

# The name of the envvar containing the AppInsights instrumentation key
APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME = "APPINSIGHTS_INSTRUMENTATIONKEY"

# The default for the input batch size (reading the database)
DEFAULT_INPUT_BATCH_SIZE = 1000

# The default for the output batch size (writing the database)
DEFAULT_OUTPUT_BATCH_SIZE = 1000

# The default rest api port to service
DEFAULT_PORT = 80

# The basename of the dynamic (raw_scenario) input file
INPUT_DYNAMIC_DF = "input_dynamic_df.csv"
# The basename of the dynamic (raw_scenario) input file (minimum data)
INPUT_TEMPLATE_DYNAMIC_DF = "input_template_dynamic_df.csv"
# The basename of the dynamic (raw_scenario) input file for other country
INPUT_DYNAMIC_DF_WITH_OC = "input_dynamic_df_for_other_country.csv"
# The basename of the dynamic expected output file after other country calculation
EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC = "expected_dynamic_df_with_other_country.csv"

# The basename of the dynamic (raw_scenario) input file for other country
INPUT_DYNAMIC_DF_WITH_OC_AGR_BASELINE = (
    "input_dynamic_df_for_other_country_and_agriland_baseln.csv"
)
# The basename of the dynamic expected output file after other country calculation
EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC_AGR_BASELINE = (
    "expected_dynamic_df_with_other_country_baseln.csv"
)


# The basename of the dynamic (raw_scenario) input file for other country
INPUT_DYNAMIC_DF_WITH_OC_AGR_PLUS = (
    "input_dynamic_df_for_other_country_and_agriland_plus.csv"
)
# The basename of the dynamic expected output file after other country calculation
EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC_AGR_PLUS = (
    "expected_dynamic_df_with_other_country_plus.csv"
)


# The string-part needed (by adding it) to construct the GBV output file
# (when left out, we have the SBV output file)
GBV_PART = "_GBV"

# The template (suitable for str.format() to construct the GBV output file
OUTPUT_DATA_CSV_BASENAME_FMT = "".join(("Mes_STIB", GBV_PART, "_{datetime_str}.csv"))

# The way dates are coded (YYYYMMDD), before converting it to int
DATE_FMT = "%Y%m%d"

# Indicating a normal (successful) exit status code
EXIT_OK = 0

ObservationType = Enum("Type", "Scenario Historical Extension")

# Should be aligned with the Other Country test input
OC_CONSTANT_YEAR = 2020
# Default Data frequency to filter consequent data in Other Country
DEFAULT_DATA_FREQ = 10
# Test frequency to trigger Other Country calculation with fixed year (OC_CONSTANT_YEAR)
TEST_FREQ = -1

# Mock dynamic data input name for agriland
INPUT_DYNAMIC_DF_WITH_MOCK_AGRILAND = "input_dynamic_df_with_mock_agriland.csv"
EXPECTED_EXTENDED_DYNAMIC_DF_WITH_MOCK_AGRILAND = (
    "expected_extended_dynamic_df_with_mock_agriland.csv"
)

# To define "complete dynamic_df" quarters to have before and after the reporting_date
QUARTERS_TO_HAVE_AFTER = 4
QUARTERS_TO_HAVE_BEFORE = -7
