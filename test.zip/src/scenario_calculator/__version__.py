# -*- coding: utf-8 -*-
"""Package metadata."""

# Variable injected by token-replace step in a build so it is available during runtime.
_VERSION = "{{GITVERSION_SEMVER}}"

if "GITVERSION_SEMVER" in _VERSION:
    _VERSION = "0.0.1"

__title__ = "scenario_calculator"
__version__ = _VERSION
__build__ = "{{BUILD_BUILDID}}"
__author__ = "Rabobank - CAS"
__description__ = "Meister Scenario Calculator"
__author_email__ = "fm.nl.utrecht.SYSRFCAS@rabobank.com"
