# -*- coding: utf-8 -*-

# type: ignore
# TODO [AB]: Fix mypy errors after TimeSeries & OutputRow removal PBIs
"""
Time series container class. This class can be used to perform the time series
extension step.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
"""

# =============================================================================
# Private helper functions (ARIMA process):
# =============================================================================


def _extend_series(series, dates, prev_val, param0, param1, param_d):
    """
    Extends time series using a forecast from the fitted ARIMA model
    given by param0, param1, param_d

    :param series: original series
    :type series: pandas.core.series.Series
    :param dates: range of dates to which the series is extended by forecast
    :type dates: DatetimeIndex
    :param prev_val: start value for extension
    :type prev_val: float
    :param param0: the constant parameter of ARIMA model
    :type param0: float
    :param param1: parameter of ARIMA model (coefficient of autoregressive \
                   term)
    :type param1: float
    :param param_d: parameter of ARIMA model
    :type param_d: float
    :return: extended series
    :rtype: pandas.core.series.Series
    """
    for date in dates:
        new_val = _calculate_arima_step(prev_val, param0, param1, param_d)
        series[date] = new_val
        prev_val = new_val
    return series


def _calculate_arima_step(prev_value, param1, param2, param_d):
    """
    The ARIMA model is a class of statistical models for analysing and
    forecasting time series data. Commonly, a standard notation is used to
    specify the model under consideration, i.e. ARIMA(p, d, q).
    In this particular notation p, d and q are positive integer values
    (including zero) where

        1) p is the number of number of autoregressive terms;
        2) d the number of non-seasonal differences needed for stationarity;
        3) q is the number of lagged forecast errors in the prediction
           equation.

    For more detailed information on ARIMA models we
    refer to: https://people.duke.edu/~rnau/411arim.htm

    Currently, three models are implemented in this function; i.e.

        1) ARIMA(0, 0, 0): white noise;
        2) ARIMA(1, 0, 0): first-order autoregressive model;
        3) ARIMA(0, 1, 0): random walk.

    However, in practice, we presently only use the white-noise and
    first-order autoregressive model. The following parameterizations,
    defined by coefficients β0, β1, are used per model:

        1) ARIMA(0, 0, 0): Y[t] = β0,
        2) ARIMA(1, 0, 0): Y[t] = β0 + β1 ∙ (Y[t-1] - β0 )
        3) ARIMA(0, 1, 0): Y[t] = β0 + Y[t-1],

    with = Y[t] the value of the dependent variable at time t and Y[t-1]
    the value at the time t – 1.

    :param prev_value: previous value
    :type prev_value: float
    :param param1: parameter of ARIMA model
    :type param1: float
    :param param2: parameter of ARIMA model
    :type param2: float
    :param param_d: parameter of ARIMA model (order of differencing)
    :type param_d: float
    :type param_d: float
    :return: update value based on previous value
    :rtype: float
    """
    if param_d == 0:
        return param1 + param2 * (prev_value - param1)
    else:
        return param1 + prev_value
