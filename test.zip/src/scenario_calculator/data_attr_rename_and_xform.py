# type: ignore[attr-defined]
from collections import namedtuple
from typing import (
    Any,
    Callable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Type,
    TypeVar,
    Union,
)

import pandas as pd

from scenario_calculator.utility import NamedTupleLike, identity

# Type definitions and type vars:

# This typedef describes a single target column/attribute/field:
# It (may) contain(s):
# - the target column/attribute name (a string), or
# - a tuple of
#   - the target column/attribute name (as above), and
#   - the target column/attribute type
#   - with an optional third field specifying a translation function
#     that converts the input value to an output value for that column/attribute
TARGET_ATTR_DESC = Union[
    str, Tuple[str, Type], Tuple[str, Optional[Type], Callable[[Any], Any]]
]

# This typedef describes the mapping from a series of input column/attribute/field
# names to the corresponding target columns/attributes/fields.
ATTR_MAPPING_DESC = Mapping[str, Optional[TARGET_ATTR_DESC]]

_NTL = TypeVar("_NTL", bound=NamedTupleLike)


_AttrConversion = namedtuple(
    "_AttrConversion", ("source_attr_name", "target_attr_name", "typ", "xform_func")
)


class DataFrameTransformer:
    """Functionality to rename, and transform DataFrames.

    In instance of this class is able to process dataframe and perform:
    * Rename the field
    * Coerce the type to another type
    * Apply a value transformation function

    This all is specified by the `attr_mapping_desc` argument of `__init__`.
    Refer to the comments near the `ATTR_MAPPING_DESC` typedef for more information.

    """

    def __init__(self, source_cls_name: str, attr_mapping_desc: ATTR_MAPPING_DESC):
        """Initialise the DataFrameTransformer instance.

        :param source_cls_name: the name of the input NamedTupleLike class
        :param attr_mapping_desc: a dictionary describing
          * the concerning input fields
          * the name of the corresponding target output field
          * possibly what type they should be converted to
          * and possibly what data transformation is needed
          (refer to the description of `ATTR_MAPPING_DESC`)
          Note: all the attributes must be described in the order they
            are defined in the source class.
        """
        self._source_cls_name = source_cls_name
        self._attr_conv_spec = _make_full_conversion_spec(attr_mapping_desc)

    def rename_columns_heading(self, df: pd.DataFrame) -> pd.DataFrame:
        """ Change the column headings as per target fields.

        :param df: Dynamic input dataframe for which column names to be changed.
        :return: Dataframe with changed column names as per the _attr_conv_spec mapping.
        """
        # Get the source and target names from _attr_conv_spec
        column_source_names = [
            self._attr_conv_spec[i].source_attr_name
            for i in range(len(self._attr_conv_spec))
        ]
        column_target_names = [
            self._attr_conv_spec[i].target_attr_name
            for i in range(len(self._attr_conv_spec))
        ]
        # Rename the columns and return the dataframe with new column headings
        return df.rename(columns=dict(zip(column_source_names, column_target_names)))

    def xform_data_and_change_data_type(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform the data of dataframe and change the data type.

        :param df: Dynamic input dataframe for which column values to be changed.
        :return: Dataframe with changed column values as per the _attr_conv_spec
        mapping.
        """
        # Get the function to be called for data transformation and
        # Data type from _attr_conv_spec.
        column_target_types = [
            self._attr_conv_spec[i].typ for i in range(len(self._attr_conv_spec))
        ]
        column_apply_functions = [
            self._attr_conv_spec[i].xform_func for i in range(len(self._attr_conv_spec))
        ]
        # Create a dictionary with column names and corresponding transform functions.
        column_name_apply_functions_dict = dict(
            zip(list(df.columns), column_apply_functions)
        )
        # Apply the functions in corresponding columns
        for k in column_name_apply_functions_dict:
            df[k] = df[k].apply(column_name_apply_functions_dict[k])
        # Create a dictionary with column names and target data types.
        column_name_target_type_dict = dict(zip(list(df.columns), column_target_types))
        # Remove column with None target type to avoid failure.
        column_name_target_type_dict = {
            k: v for k, v in column_name_target_type_dict.items() if v is not None
        }
        # Change the data type and return the transformed dataframe.
        return df.astype(column_name_target_type_dict)


def _make_full_conversion_spec(
    attr_mapping_desc: ATTR_MAPPING_DESC,
) -> List[_AttrConversion]:
    """Make a fully specified attribute conversion specification for all attrs.

    :param attr_mapping_desc: the mapping describing the conversion, see
      the comment near `ATTR_MAPPING_DESC`.
    :return: None
    """
    # Create a fully specified list of (named) tuples of 4 containing the
    # sql and df column names, df columnn typ and conversion function
    # but only for those sql columns for which something has been defined
    # (i.e. not None)
    return [
        _make_attr_conversion_spec(source_attr_name, target_attr_desc)
        for source_attr_name, target_attr_desc in attr_mapping_desc.items()
        if target_attr_desc is not None
    ]


def _make_attr_conversion_spec(
    source_attr_name: str, target_attr_desc: TARGET_ATTR_DESC
) -> _AttrConversion:
    """"Convert one attribute TARGET_ATTR_DESC info into fully defined conv-spec.

    :param source_attr_name: the attribute name of the input (source)
    :param target_attr_desc: the associated conversion specification
      as defined by the TARGET_ATTR_DESC typedef
    :raises TypeError: param `target_attr_desc` is not Sequence
    :raises ValueError: param `target_attr_desc` has a length different from what is
      specified in the `TARGET_ATTR_DESC` typedef
    :return: a fully specified conversion in _AttrConversion
    """
    if isinstance(target_attr_desc, str):
        # just a plain column name
        return _AttrConversion(source_attr_name, target_attr_desc, None, identity)
    if not isinstance(target_attr_desc, Sequence):
        raise TypeError(f"target_attr_desc ({target_attr_desc!r}) is not a Sequence")
    if len(target_attr_desc) == 2:
        # target attribute name and type
        return _AttrConversion(source_attr_name, *target_attr_desc[:2], identity)  # type: ignore # noqa
    if len(target_attr_desc) == 3:
        # target attribute name, type, and transformation function
        return _AttrConversion(source_attr_name, *target_attr_desc[:3])
    raise ValueError(f"Strange target_attr_desc: {target_attr_desc!r}")
