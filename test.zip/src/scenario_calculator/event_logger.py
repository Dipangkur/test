# type: ignore[attr-defined]
"""The EventLogger functionality.

TODO [JHB]: Cloned and improved from MSR.ScenarioCreator.Py project.
  Backport it, or - even better - make it an multi-usable module.
  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
"""

import json
import logging
import sys
import traceback
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import Boolean, CheckConstraint, Column, DateTime, Integer, String
from sqlalchemy.exc import SQLAlchemyError

from scenario_calculator.db import (
    Base,
    create_engine_from_connection_string,
    new_session_base_tuple,
)

SQL_CONNECTION_MEMORY = "sqlite:///:memory:"
# This prevents a connection timeout for the event logger, see
#  docs.sqlalchemy.org/en/latest/core/pooling.html#disconnect-handling-pessimistic
_EXTRA_CREATE_ENGINE_KWARGS = {"pool_pre_ping": True, "pool_recycle": 3600}

_log = logging.getLogger(__name__)


class IncompleteRawScenarioError(Exception):
    pass


def _make_exception_stack_trace() -> Dict[str, Any]:
    """Return a dict providing exception and stack trace info.

    The function returns a dict (mapping) with two fields:
    - formatted_exception_only: a list of strings each ending with a newline
        containing info about only the exception that was raised most recently.
    - formatted_exception_info: a list of strings each ending with a newline
        containing both the complete (chained) stack backtrace as well as all
        the triggering exceptions that occurred.

    Both fields are provided so that the caller can choose what to show.

    :return: a dict with the two fields described above.
    """
    etype, value, tb = sys.exc_info()
    return dict(
        formatted_exception_only=traceback.format_exception_only(etype, value),
        formatted_exception_info=traceback.format_exception(etype, value, tb),
    )


class InMemoryMeisterEvent(Base):
    """The MeisterEvent used when stored in an own-created memory database.

    It contains the fields that are normally inferred from the already
    existing MeisterEvents table.
    """

    __tablename__ = "MeisterEvents"

    Id = Column(Integer, primary_key=True)
    ParentEventId = Column(Integer, nullable=True, default=None)
    EventType = Column(String(25), nullable=True, default=None)
    NumberOfSteps = Column(Integer, nullable=False, default=0)
    Name = Column(String(50), nullable=False)
    Description = Column(String, nullable=True)
    Start = Column(DateTime, nullable=True)
    End = Column(DateTime, nullable=True)
    ViewableBy = Column(String(100), nullable=True)
    Status = Column(
        String(20),
        CheckConstraint("Status IN('Pending', 'Success', 'Failure')"),
        nullable=False,
    )
    EventData = Column(String, nullable=True, default=None)
    IsMajorEvent = Column(Boolean, nullable=False, default=False)
    IsLast = Column(Boolean, nullable=False, default=False)

    def __str__(self):
        return (
            f"<{self.__class__.__qualname__}"
            f" Start={self.Start},"
            f" ParentEventId={self.ParentEventId},"
            f" Status={self.Status},"
            f" EventType={self.EventType},"
            f" NumberOfSteps={self.NumberOfSteps},"
            f" IsMajorEvent={self.IsMajorEvent},"
            f" IsLast={self.IsLast},"
            f" EventData={self.EventData}>"
        )


class EventLogger:
    def __init__(
        self,
        conn_str: Optional[str] = None,
        event_id: int = 0,
        event_data_dict: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize the event logger.

        :param conn_str: Points to a database holding the MeisterEvents table.
          If `None`, then a temporary in-memory database is created where the events
          are stored and available during the lifetime of this object.
        :param event_id: The (parent) event id to refere to in the logs
        :param event_data_dict: additional info to be stored in the EventData
          field, coded as a human-readable JSON string, if a so-called "Major Event"
          is being logged.
        """
        self.parent_id = event_id
        self._event_data_dict = event_data_dict
        if conn_str is None:
            meister_event_cls = InMemoryMeisterEvent

            engine = create_engine_from_connection_string(
                SQL_CONNECTION_MEMORY, **_EXTRA_CREATE_ENGINE_KWARGS
            )
            self.db_session, meister_event_cls = new_session_base_tuple(
                engine, meister_event_cls
            )
            self.event_model = meister_event_cls
        else:
            engine = create_engine_from_connection_string(
                conn_str, **_EXTRA_CREATE_ENGINE_KWARGS
            )
            self.db_session, base = new_session_base_tuple(engine, None)
            # noinspection PyUnresolvedReferences
            self.event_model = base.classes.MeisterEvents

    @property
    def event_data_dict(self) -> Optional[Dict[str, Any]]:
        """Provide a reference to the event data dictionary
        :return: a reference to the event data dictionary
        """
        return self._event_data_dict

    def close(self) -> None:
        """Close any resources held by the event logger object.

        More specifically, the database session will be closed.

        """
        self.db_session.close()

    @contextmanager
    def log_event(self, event_as_dict: Dict[str, Any]) -> Any:
        """Execute the with-clause, yield MeisterEvent depending on exception.

        * An MeisterEvent is added to the corresponding table. Initially the
          status will be set to 'Pending' and the with-clause is executed.
        * If no exception occurs during the execution, the Status of the
          Event is updated to 'Success'.
        * If an exception did occur during the execution however, the Status
          of the Event is updated 'Failure' and the EventData of the Event is filled
          with a JSON encoded structure providing event and stack backtrace
          info.
          See ``_make_exception_stack_trace()`` for more details on this
          structure.

        :param event_as_dict: the actual event parameters, passed as a dict.
        :raises KeyboardInterrupt: interrupted by someone hitting Ctrl-C
        :raises Exception: either the commit to the database didn't succeed, or
          the code within the context raised an exception
        :return: the resulting Event that has been written to the MeisterEvents
          table as well.
        """

        # TODO [JHB]: validate correctness (length) of attributes
        #  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/534094
        meister_event = self.event_model(
            **event_as_dict,
            Start=datetime.utcnow(),
            ParentEventId=self.parent_id,
            Status="Pending",
        )
        self._maybe_update_event_data(meister_event)
        self.db_session.add(meister_event)
        try:
            self.db_session.commit()
        except (TypeError, SQLAlchemyError, OSError) as exc:
            _log.error(
                "Troubles inserting a new log event with parameters %r; reason: %s",
                event_as_dict,
                exc,
            )
            _log.info("Rolling back this event and re-raising exception")
            self.db_session.rollback()
            raise
        try:
            yield meister_event
        except (
            KeyboardInterrupt,
            TypeError,
            KeyError,
            SQLAlchemyError,
            OSError,
            IncompleteRawScenarioError,
        ):
            meister_event.End = datetime.utcnow()
            meister_event.Status = "Failure"
            event_data = self._make_exception_json(meister_event)
            meister_event.EventData = event_data
            self.db_session.commit()
            raise

        meister_event.End = datetime.utcnow()
        self._maybe_update_event_data(meister_event)
        meister_event.Status = "Success"
        self.db_session.commit()

    def _maybe_update_event_data(self, meister_event: Any) -> None:
        """Update the `EventData` attribute when applicable.

        :param meister_event: the concerning event entry
        """
        if self._should_include_data_dict(meister_event):
            meister_event.EventData = _make_readable_json(self._event_data_dict)

    def _make_exception_json(self, meister_event: Any) -> str:
        """Make a string consisting of exception info and perhaps extra event data.

        A JSON (string) is returned consisting of exception information.


        :param meister_event: the concerning event entry
        :return: a formatted json string containing exception info, possibly
          augmented with extra event data in case this should be included
        """
        exception_stack_trace_info_dict = _make_exception_stack_trace()
        if self._should_include_data_dict(meister_event):
            event_data = _make_readable_json(
                {**exception_stack_trace_info_dict, **self._event_data_dict}  # type: ignore # noqa
            )
        else:
            event_data = _make_readable_json(exception_stack_trace_info_dict)
        return event_data

    def _should_include_data_dict(self, meister_event: Any) -> bool:
        """Return whether we should include the event data dictionary in the log.

        Extra event data is inserted only for so called "Major Events", and only
        if there is extra event data present.

        :param meister_event: the concerning event entry
        :return: whether we should include the event data dictionary in the log
        """
        return meister_event.IsMajorEvent and self._event_data_dict is not None

    def dump_to_log(self, log_level: int) -> None:
        """Dump the event log for this instance to the logger.

        :param log_level: the level to use for logging
        """
        _log.log(log_level, "A dump of the event log follows:")
        for item in (
            self.db_session.query(self.event_model)
            .filter(self.event_model.ParentEventId == self.parent_id)
            .order_by(self.event_model.Id)
        ):
            _log.log(log_level, "--%s", item)


def _make_readable_json(some_obj: object) -> str:
    """Convert some object to a bit of human-readable string object.

    :param some_obj: the object to convert
    :return: the converted object
    """
    return json.dumps(some_obj, indent=2, default=_fix_datetime_for_json)


def _fix_datetime_for_json(some_obj: object) -> object:
    """Convert the passed object to a json serializable object if it is a datetime.

    :param some_obj: an object that might need to be converted
    :return: the passed object or converted to a string
    """
    if isinstance(some_obj, datetime):
        return str(some_obj)
    return None
