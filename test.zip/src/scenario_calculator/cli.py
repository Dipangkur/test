""" CLI for application entry """

import logging
import os
import sys
from datetime import datetime
from logging import Logger
from pathlib import Path
from typing import Optional

import click
from sqlalchemy.engine.url import make_url

from scenario_calculator.aliases import MainReturnType
from scenario_calculator.calculator import calculate
from scenario_calculator.config import GeneralConfig, RunDefinition, RunParams
from scenario_calculator.constants import (
    APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME,
    DEFAULT_INPUT_BATCH_SIZE,
    DEFAULT_OUTPUT_BATCH_SIZE,
    DEFAULT_PORT,
    INPUT_DYNAMIC_DF,
    OUTPUT_DATA_CSV_BASENAME_FMT,
)
from scenario_calculator.io.base_reader import URL_SCHEME_FILE
from scenario_calculator.log import config_logger
from scenario_calculator.main_rest_api_mode import start_api
from scenario_calculator.settings import Settings
from scenario_calculator.signals import install_signal_handlers
from scenario_calculator.utility import make_datetime_filestamp, parse_iso_ish_datetime

_THIS_MODULE_NAME = __name__


def _validate_logging_level_cb(
    ctx: click.Context, param: click.Option, log_level: str
) -> int:
    """Check the provided logging level and return the numeric equivalent.

    This implementation supports the notion of additional symbolic levelnames,
    as provided by `logging.addLevelName`.

    :param ctx: the click Context (ignored)
    :param param: the parameter name (ignored)
    :param log_level: either a symbolic log level name, or the string representation
      of a number
    :raises click.BadParameter: Wrong parameter for (symbolic) log level
    :return: the logging level
    """
    del ctx, param
    try:
        return int(log_level)
    except ValueError:
        pass
    # It is not numeric; it is symbolic instead.
    try:
        # Create a temporary logger object just to check and convert the symbolic level
        return Logger(
            ".".join((_THIS_MODULE_NAME, "__non_existent__")), level=log_level
        ).level
    except ValueError as value_error:
        raise click.BadParameter(str(value_error))


# noinspection PyTypeChecker
@click.group()
@click.option(
    "--input-batch-size",
    "-i",
    type=int,
    default=DEFAULT_INPUT_BATCH_SIZE,
    help="the number of records to read in one batch",
)
@click.option(
    "--output-batch-size",
    "-o",
    type=int,
    default=DEFAULT_OUTPUT_BATCH_SIZE * 100,
    help="the number of records to write in one batch",
)
@click.option(
    "--event-log-logging-level",
    "-e",
    callback=_validate_logging_level_cb,
    default=str(logging.INFO),
    help="the lowest (symbolic) level for the logs that should be duplicated"
    " in the major event log",
)
@click.pass_context
def cli(
    ctx: click.Context,
    input_batch_size: int,
    output_batch_size: int,
    event_log_logging_level: int,
) -> MainReturnType:
    """Calculate scenario command line handler."""
    # Ensure that ctx.obj exists and is a GeneralConfig instance (in case `cli()`
    # is called by means other than the `if __name__ == "__main__":` block below)
    general_config: GeneralConfig = ctx.ensure_object(GeneralConfig)
    general_config.input_batch_size = input_batch_size
    general_config.output_batch_size = output_batch_size
    general_config.appinsights_instrumentation_key = os.environ.get(
        APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME, None
    )
    general_config.thread_teeing_logging_handler = config_logger(
        None,
        None,
        general_config.appinsights_instrumentation_key,
        event_log_logging_level,
    )
    install_signal_handlers()


def _validate_iso_ish_datetime(
    ctx: click.Context, param: click.Option, datetime_str: Optional[str]
) -> Optional[datetime]:
    """Check the provided datetime-string and return the datetime instance equivalent.

    If `None` is passed, `None` is returned.

    :param ctx: the click Context (ignored)
    :param param: the parameter name (ignored)
    :param datetime_str: a date/time string
    :raises click.BadParameter: Wrong parameter for ISO'ish datetime
    :return: a datetime instance, or None in case None was passed
    """
    del ctx, param
    try:
        return None if datetime_str is None else parse_iso_ish_datetime(datetime_str)
    except ValueError as value_error:
        raise click.BadParameter(str(value_error))


@cli.command("console-mode")
@click.option(
    "--raw-scenario-input-url-str",
    "-i",
    type=str,
    default=(Settings.MOCK_CLOUD_DIR / INPUT_DYNAMIC_DF).as_uri(),
    help="the url to the raw scenario input data ('file' or SqlAlchemy compatible).",
)
@click.option(
    "--scenario-output-url-str",
    "-o",
    type=str,
    help="the url to the scenario output data ('file' or SqlAlchemy compatible).",
)
@click.option(
    "--event-logger-url-str",
    "-l",
    type=str,
    help="the url to the event database, or None in which case it depends on the value"
    " of the RAW-SCENARIO-INPUT-URL-STR option; if that one is SqlAlchemy"
    " compatible, it will be equal to that very option; if has a 'file'-scheme, it"
    " will result in an in-memory event log that will be dumped to the logger"
    " afterwards.",
)
@click.option(
    "--raw-scenario-id",
    "-r",
    type=int,
    default=-1,
    help="the id to use the select the raw scenario from the database tables; unused"
    " when the RAW-SCENARIO-INPUT-URL-STR option is not SqlAlchemy compatible.",
)
@click.option(
    "--event-id",
    "-e",
    type=int,
    default=0,
    help="the (parent) event id to use for logging the events; better have a unique"
    " value when the events are stored in a non-memory database.",
)
@click.option(
    "--scenario-name",
    "-n",
    type=str,
    default="",
    help="the name of the scenario, is used to select which Scenario Type to choose"
    " from the Agriland static data.",
)
@click.option(
    "--scenario-creator",
    "-c",
    type=str,
    default="",
    help="the user who created the scenario.",
)
@click.option(
    "--meister-version",
    "-v",
    type=str,
    default="",
    help="A tag that tracks the Meister Version",
)
# create a Python datatime instance from a str formatted as YYYYYMMDD and handles None
@click.option(
    "--calculation-date",
    "-t",
    callback=_validate_iso_ish_datetime,
    help="The timestamp, in date-time format, when the user has requested the"
    " calculation in the GUI part (in UTC).",
)
@click.option(
    "--scenario-description",
    "-d",
    type=str,
    default="",
    help="the description the user has entered before the calculation fired up in the"
    " GUI part",
)
@click.pass_context
def console_mode(
    ctx: click.Context,
    raw_scenario_input_url_str: str,
    scenario_output_url_str: Optional[str],
    event_logger_url_str: Optional[str],
    raw_scenario_id: int,
    event_id: int,
    scenario_name: str,
    scenario_creator: str,
    meister_version: str,
    calculation_date: Optional[datetime],
    scenario_description: str,
) -> MainReturnType:
    """Calculate the scenario given all the input from the command line."""
    general_config: GeneralConfig = ctx.ensure_object(GeneralConfig)
    if calculation_date is None:
        calculation_date = datetime.utcnow()
    event_logger_url_str = complete_input_urls(
        ctx, raw_scenario_input_url_str, event_logger_url_str, raw_scenario_id
    )
    current_datetime = datetime.utcnow()
    if scenario_output_url_str is None:
        scenario_output_url_str = Path(
            Settings.DATA_OUT_DIR
            / OUTPUT_DATA_CSV_BASENAME_FMT.format(
                datetime_str=make_datetime_filestamp(current_datetime)
            )
        ).as_uri()
    run_params = RunParams(
        raw_scenario_input_url_str, scenario_output_url_str, event_logger_url_str
    )
    run_definition = RunDefinition(
        raw_scenario_id,
        event_id,
        scenario_name,
        scenario_creator,
        meister_version,
        calculation_date,
        scenario_description,
        current_datetime,
    )
    return calculate(general_config, run_params, run_definition)


def complete_input_urls(
    ctx: click.Context,
    raw_scenario_input_url_str: str,
    event_logger_url_str: Optional[str],
    raw_scenario_id: int,
) -> str:
    """Complete the input url in case it is not the expected one.

    :param ctx: context of cli command handler
    :param raw_scenario_input_url_str: the Raw Scenario input url str
    :param event_logger_url_str: event logger url
    :param raw_scenario_id: the id of the originating Raw Scenario
    :raises click.BadParameter: Wrong parameter for the input URL
    :return: the default input url in case we did not get the expected one
    """
    raw_scenario_input_url = make_url(raw_scenario_input_url_str)
    if raw_scenario_input_url.drivername != URL_SCHEME_FILE:
        if event_logger_url_str is None:
            event_logger_url_str = raw_scenario_input_url
        if raw_scenario_id == -1:
            raise click.BadParameter(
                "Missing RAW-SCENARIO-ID while RAW-SCENARIO-INPUT-URL-STR is SqlAlchemy"
                " compatible",
                ctx=ctx,
            )
    return event_logger_url_str


@cli.command("rest-api-mode")
@click.option(
    "--port",
    "-p",
    type=int,
    default=DEFAULT_PORT,
    help="the port servicing the rest-api",
)
@click.pass_context
def rest_api_mode(ctx: click.Context, port: int) -> MainReturnType:
    """Enter REST API mode."""
    general_config: GeneralConfig = ctx.ensure_object(GeneralConfig)
    return start_api(general_config, port)


if __name__ == "__main__":
    # See http://click.palletsprojects.com/en/7.x/commands\
    #    /#nested-handling-and-contexts
    # fmt: off
    sys.exit(cli(obj=GeneralConfig()))
    # fmt: on
