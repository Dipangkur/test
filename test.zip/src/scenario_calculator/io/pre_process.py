# type: ignore[attr-defined]
# -*- coding: utf-8 -*-
"""
A pre process file that provides global variables that are fetched or
calculated from values in the cloud sql data base and then later used in the
transformation of static data to dynamic or even in the extension and
enrichment.
"""
from typing import cast

import pandas as pd

from scenario_calculator.constants import DATE_FMT
from scenario_calculator.utility import get_uniques_from_frame

# =============================================================================
# Functions to create dates and other globals that will be used in calculation
# =============================================================================


def get_scenario_name(scenario_df: pd.DataFrame) -> str:
    """
    The dynamic dataframe contains the scenario name in the column named
    "scenario". This column is of content of one unique value, e.g.
    "201809 Baseline".

    :param scenario_df: the scenario (input AKA dynamic AKA cloud) dataframe
    :return: the presumedly single value from the column "scenario".
    """
    return cast(str, get_uniques_from_frame(scenario_df, "scenario"))


def get_reporting_date(input_df: pd.DataFrame) -> int:
    """Return the one and only value of the "date" column of the DataFrame.

    The value returned is an integer where the date is coded as YYYYMMDD.

    The input dataframe contains the reporting date in the column named
    "date". This column has content of one unique value, e.g. 20180930.

    :param input_df: the input dataframe that should contain a "date" column
    :return: the reporting date
    """
    return cast(int, get_uniques_from_frame(input_df, "date"))


def calc_scenario_start_date(reporting_date: int) -> int:
    """Return the scenario_start_date which is 3 months after the reportingdate.

    From the reporting date, e.g. 20180930 the function calculates the
    start_data_scenario with the equation reporting_date+Q, e.g. 20181231.

    The parameter and return value are ints coded as YYYYMMDD.

    :param reporting_date: date coded as YYYYMMDD
    :return: scenario_start_date coded as YYYYMMDD
    """
    # Retrieve the reporting date and calculate the start_data_scenario
    start_date = pd.to_datetime(reporting_date, format=DATE_FMT) + pd.offsets.MonthEnd(
        3
    )

    # Get the right format of the start_data_scenario
    return int(start_date.strftime(DATE_FMT))


def get_end_year_extension(scenario_end_date: int) -> int:
    """
    From the scenario_end_date, e.g. 20480930 we need to extract the year,
    e.g 2048. For testing purposes we created a db_flag. If the flag is true we
    can get to debug mode and get a small amount of years to extend, that way,
    extended and enrich scenario we get back is much smaller and we can test it
    locally.

    :param scenario_end_date: date coded as YYYYMMDD, retrieved by calculation
    :return: the year that the extension will end
    """
    return pd.to_datetime(scenario_end_date, format=DATE_FMT).year


def get_nbrof_years_to_extend(nbrof_years_extension_df: pd.DataFrame) -> int:
    """Retrieve the number of years to extend from the input data frame.

    :param nbrof_years_extension_df: dataframe holding nbrof years to extend
    :return: the number of years to extend
    """
    return nbrof_years_extension_df.iloc[0][0]


def calc_scenario_end_date(reporting_date: int, number_of_years_to_extend: int) -> int:
    """Calculate the end date of the extended scenario.

    In order to get the scenario_end_date we need to add the number of year to
    extend e.g get end_year_extension=30, and return that date, e.g 20480930.

    :param reporting_date: date coded as YYYYMMDD
    :param number_of_years_to_extend: number of years to extend the date with
    :return: the date that the extension will end, coded as YYYYMMDD
    """
    scenario_end_date = pd.to_datetime(reporting_date, format=DATE_FMT) + pd.DateOffset(
        years=number_of_years_to_extend
    )
    # Get the right format of the end_date_extension
    end_date_as_int = int(scenario_end_date.strftime("%Y%m%d"))
    return end_date_as_int


def get_scenario_end_date(
    reporting_date: int, nbrof_years_extension_df: pd.DataFrame
) -> int:
    """Return the end date of the to be calculated scenario.

    In order to get the scenario_end_date, we need to include the year
    e.g get end_year_extension=30, and return that date, e.g 20480930.

    :param reporting_date: date coded as YYYYMMDD
    :param nbrof_years_extension_df: dataframe holding nbrof years to extend
    :return: the date that the extension_df will end
    """
    number_of_years_to_extend = get_nbrof_years_to_extend(nbrof_years_extension_df)
    end_date_as_int = calc_scenario_end_date(reporting_date, number_of_years_to_extend)
    return end_date_as_int


def get_frequency(reporting_date):
    """
    From the reporting_date, e.g. 20180930 the function gives the
    frequency, meaning the month of the reporting_date, e.g. "A-SEP".

    :param reporting_date: date in format='%Y%m%d', retrieved from the cloud
    :type reporting_date: int
    :return: the name of the month of the reporting date
    :rtype: str
    """
    # Retrieve the reporting_date in the right format
    rd = pd.to_datetime(reporting_date, format=DATE_FMT)

    # Get the month part of the reporting_date
    return "A-{}".format(rd.strftime("%b").upper())


# =============================================================================
# Global dates etc. used throughout the tool:
# =============================================================================

# This was the parameter that contained valid_from of different sd
RUN_PARAM_KEY = ""

# This was the parameter that contained valid_from of ARIMA sd, not needed
TIMESERIES_PARAMS_KEY = ""

# This was the parameter that contained valid_from of standardization sd
STANDARDIZATION_PARAMS_KEY = ""
