# type: ignore[attr-defined]
import logging
import os
import re
from abc import ABC, abstractmethod
from functools import partial
from operator import concat
from typing import Any, Dict, List, Tuple

import pandas as pd

from scenario_calculator.io.blobstorage import (
    BLOB_READER_URL_PATTERN,
    BlobReaderBackend,
    FileReaderBackend,
)
from scenario_calculator.utility import basename_part

logger = logging.getLogger(__name__)

# TODO [AB]: Improved from MSR.ScenarioCreator.Py project.
#  Make it an multi-usable module.
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217


class FileReader(ABC):
    """Generic FileReader ABC, able to handle file and https URLs.

    Derived classes should implement the read method.

    When a derived class is instantiated with a url matching
    ``BLOB_READER_URL_PATTERN``, then the set_account_key() class method
    should be called beforehand.
    """

    def __init__(self, url, period_type=""):
        self._url = url
        self._source = basename_part(url)
        self._period_type = period_type
        if url.startswith("file://"):
            self._backend = FileReaderBackend
        elif re.match(BLOB_READER_URL_PATTERN, url):
            account_key = self.test_and_get_account_key()
            self._backend = partial(BlobReaderBackend, account_key)
        else:
            err_msg_fmt = "Don't know how to get data from url: %(url)r"
            err_msg_args = dict(url=url)
            logger.error(err_msg_fmt, err_msg_args)
            raise NotImplementedError(err_msg_fmt % err_msg_args)

    @classmethod
    def test_and_get_account_key(cls):
        try:
            account_key = cls._account_key
        except AttributeError as attr_err:
            raise ValueError(
                (
                    "{clsname}.set_account_key() should be called before"
                    " {clsname} instance(s) can be created with an url"
                    " matching {blob_patt!r}"
                ).format(clsname=cls.__qualname__, blob_patt=BLOB_READER_URL_PATTERN)
            ) from attr_err
        return account_key

    @classmethod
    def set_account_key(cls, account_key: Any) -> None:
        """Set (once) the storage account key for the BlockReaderBackend.

        Unfortunately the account key can not be passed in the constructor
        call, since the signature of the constructor is shared between
        multiple FileReader-derived classes.

        Make sure this class method is called before an instance is created
        with an URL matching ``BLOB_READER_URL_PATTERN``.

        :param account_key: the storage account key to use
        """
        cls._account_key = account_key

    def read_blob(self, keep_default_na):
        return self._read(keep_default_na)

    def _read(self, keep_default_na):
        with self._backend(self._url) as buf:
            return self.read(buf, keep_default_na)

    @abstractmethod
    def read(self, buf, keep_default_na):
        pass  # pragma no cover


def extract_blob_file_name(url: str) -> Tuple[str, str]:
    """Extract the file name out of url given.

    Gets the file name and the extension from the url.

    Eg: https://blobstorage.net/uploads/3243_static_euro_countries_20180809142433286.csv
     would return a tuple like ("static_euro_countries",".csv")

    :param url: the url of the static file in blob storage
    :return: (str, str) name and the extension of the file
    """

    # Get filename, get rid of the timestamp and trim it
    name_with_timestamp = re.search(r"(.*)/(.*)", url.strip("/")).group(2)  # type: ignore # noqa
    name_with_underscores = re.sub("[0-9]", "", name_with_timestamp).strip()

    # Concatenate file name and the extension after cleaning them from "_"s
    return (
        (os.path.splitext(name_with_underscores)[0]).strip("_"),
        os.path.splitext(name_with_underscores)[1],
    )


def create_merged_mapping(
    static_blob_files_list: List[str], static_file_mapping: Dict[str, str]
) -> pd.DataFrame:
    """Create merged mapping DataFrame from blob file list and the static file mapping

    Merges static file mapping with blob file list as adding a new attribute which tells
    if it should be read from the blob storage or directly from the static file. On the
    file_name column of the result DataFrame, there will be direct url of the blob
    storage file.

    :param static_blob_files_list: list of static blob files
    :param static_file_mapping: mapping of static file descriptions and names
    :return: str, str
    """

    sorted_blob_files = _create_sorted_dict_from_blob_file_list(static_blob_files_list)
    df_merged_mapping = _merge_mappings(sorted_blob_files, static_file_mapping)
    df_merged_mapping = _finalize_columns(df_merged_mapping)

    return df_merged_mapping


def _finalize_columns(df_merged_mapping: pd.DataFrame) -> pd.DataFrame:
    """ Update columns
    Overwrites file_name with url if it is a blob storage file, adds is_blob column

    :param df_merged_mapping: merged mapping of static files
    :return: pd.DataFrame
    """

    df_merged_mapping.loc[
        df_merged_mapping["url"].notna(), "file_name"
    ] = df_merged_mapping["url"]
    df_merged_mapping["is_blob"] = 0
    df_merged_mapping.loc[df_merged_mapping["url"].notna(), "is_blob"] = 1
    df_merged_mapping = df_merged_mapping.drop(["url"], axis=1)
    return df_merged_mapping


def _merge_mappings(
    sorted_blob_files: Dict[str, str], static_file_mapping: Dict[str, str]
) -> pd.DataFrame:
    """ Merge Mappings

    Converts Mappings to DataFrames and merges them on the file_name column

    :param sorted_blob_files: dictionary of sorted blob files
    :param static_file_mapping: merged mapping of static files
    :return: pd.DataFrame
    """

    df_file_mapping = pd.DataFrame(
        list(sorted(static_file_mapping.items())), columns=["df_name", "file_name"]
    )
    df_blob_files = pd.DataFrame(
        list(sorted_blob_files.items()), columns=["file_name", "url"]
    )

    df_merged_mapping = df_file_mapping.merge(
        df_blob_files, how="outer", on="file_name"
    )
    return df_merged_mapping


def _create_sorted_dict_from_blob_file_list(static_blob_files_list: List[str]) -> dict:
    """ Create sorted blob file dictionary

    Converts blob file url list into Dictionary of url-filename pairs

    :param static_blob_files_list: List of file urls to be read from blob storage
    :return: Dict[str, str]: Dictionary keeping filename - url pairs of blob files
    """

    blob_file_mapping = {
        concat(*extract_blob_file_name(url)): url for url in static_blob_files_list
    }
    sorted_blob_files = dict(sorted(blob_file_mapping.items()))
    return sorted_blob_files


class BlobReader(FileReader):
    def read(self, buf: Any, keep_default_na: bool) -> pd.DataFrame:
        """ Reads given buf as pandas DataFrame

        :param buf: data to be read from
        :param keep_default_na: param to be passed for read_csv function
        :return: pd.DataFrame keeping the read data from blob
        """
        return pd.read_csv(buf, delimiter=";", keep_default_na=keep_default_na)

    def blob_exists(self) -> bool:
        """Checks if the blob exists in the url

        :return: bool defining if that blob file exists
        """

        blob_backend = self._backend.func(
            BlobReader.test_and_get_account_key(), self._url
        )
        return (
            len(
                blob_backend.service.list_blobs(
                    blob_backend.container, blob_backend.filename
                ).items
            )
            > 0
        )
