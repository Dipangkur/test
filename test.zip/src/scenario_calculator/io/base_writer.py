"""Generation of output-channel-independeny output records."""
import logging
import math
from typing import Iterator

import numpy as np
import pandas as pd

# Logging:
_log = logging.getLogger(__name__)


def output_data_frame_from_optional_scenario_items(  # noqa: C901
    output: list, output_batch_size: int,
) -> Iterator[pd.DataFrame]:
    """Return an iterator of DataFrame entries from the Scenarios items

    :param output: list of optional scenarios items
    :param output_batch_size:
    :return: a final DataFrame
    """
    for tseries in output:
        ts_list = split(tseries, output_batch_size)
        for ts_chunk in ts_list:
            yield ts_chunk


def index_marks(nrows, chunk_size):
    return range(chunk_size, math.ceil(nrows / chunk_size) * chunk_size, chunk_size)


def split(dfm, chunk_size):
    indices = index_marks(dfm.shape[0], chunk_size)
    return np.split(dfm, indices)
