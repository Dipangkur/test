# type: ignore[attr-defined]
"""
This module is used to process the agriland static data. This data contains
the parameters to be used per scenario type. Using the scenario name
(from which the scenario type can be derived) and the static data determines
a Pandas DataFrame that can be used by calculator.

>> Reference: Meister Requirements Document
"""
import logging

import pandas as pd
from pandas import DataFrame

from scenario_calculator.utility import get_unique_scenario_type

logger = logging.getLogger(__name__)


def increment_date(string_date: str, delta_in_years: int) -> str:
    """
    Increment date based on time delta (in years).

    :param string_date: YYYYQx string date
    :param delta_in_years: time delta in years
    :return: incremented date (format YYYYQx string)
    """
    year: str = str(int(string_date[0:4]) + delta_in_years)
    quarter = str(string_date[-1])
    return f"{year}Q{quarter}"


def get_original_agriland_frame(
    df: DataFrame, scenario_name: str, start_date_of_shock_period: str
) -> DataFrame:
    """
    Construct dynamic Agriland data frame to be used by calculator.

    :param df: contains relevant agriland parameters
    :param scenario_name: a name of a scenario
    :param start_date_of_shock_period: start date of shock period (YYYYQx)
    :return: dynamic Agriland data frame or empty dataframe
    """
    # If Agriland was not provided the function will return an empty dataframe
    if df.index.empty:
        return pd.DataFrame()
    shock_year_keyword = "shock_year_"
    total_shock_years = get_total_shock_years(df, shock_year_keyword)

    # subset agriland static data df based on scenario_type:
    scenario_type = get_unique_scenario_type(scenario_name)
    df_sub = df[df["scenario_type"] == scenario_type]
    df_sub["scenario_type"] = scenario_name
    df_sub.rename(inplace=True, columns={"scenario_type": "scenario"})

    # Rename the "shock_year_X" columns aligned with the reporting date
    for i in range(total_shock_years + 1):
        df_sub.rename(
            inplace=True,
            columns={
                shock_year_keyword
                + str(i): increment_date(start_date_of_shock_period, i)
            },
        )

    return df_sub.reset_index(drop=True)


def get_total_shock_years(static_agriland_df: pd.DataFrame, keyword: str) -> int:
    """
    Gets the number of total shock years in the static agriland DataFrame. Returns the
    last character of the last column in the DataFrame as integer
    :param static_agriland_df:
    :return:
    """
    shock_cols = [col for col in static_agriland_df.columns if keyword in col]
    return len(shock_cols)
