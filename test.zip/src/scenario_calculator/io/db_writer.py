# type: ignore[attr-defined]
import logging
import time
from collections import namedtuple

import pandas as pd
from sqlalchemy import event
from sqlalchemy.engine import Connection, Engine
from sqlalchemy.ext.declarative import DeclarativeMeta  # noqa F401

from scenario_calculator.db import create_engine_from_connection_string
from scenario_calculator.io.base_writer import (
    output_data_frame_from_optional_scenario_items,
)
from scenario_calculator.io.db_conv_utils import iter_db_field_attributes  # noqa F401
from scenario_calculator.io.fields import SCENARIO_ATTR_MAPPING
from scenario_calculator.io.reader import OneValuedInputData
from scenario_calculator.utility import (
    get_named_tuple_fields,
    named_tuple_asdict,
    time_context,
    yyyymmdd_int2datetime,
)

ScenarioInfo = namedtuple("ScenarioInfo", tuple(SCENARIO_ATTR_MAPPING.keys()))  # type: ignore # noqa

_log = logging.getLogger(__name__)
_WRITE_LOG_INTERVAL = 60  # Issue an INFO log every minute


def write_output_to_db(
    scenario_output_url_str: str,
    output_batch_size: int,
    all_scenarios_quarterly: list,
    scenario_info_all: OneValuedInputData,
) -> int:
    """Write the calculated scenario to the Scenario and ScenarioTimeSeries tables.

    :param scenario_output_url_str: SqlAlchemy database connection string template
    :param output_batch_size: the number of output records to collect in one chunk
    :param all_scenarios_quarterly: the quarterly (normal and mapped) scenarios
    :param scenario_info_all:  Namedtuple with the info of the quarterly scenarios
    :return: the Scenario Id of the newly inserted scenario
    """
    with time_context("[14.1] Opening Scenario database and initialing settings"):
        engine = _create_engine(scenario_output_url_str)

    with engine.begin() as connection:
        with time_context(
            "[14.2] Writing scenario info to Scenario database and initialing settings"
        ):
            scenario_id = _write_scenario_info_entry(connection, scenario_info_all)

        with time_context("[14.3] Writing scenario TimeSeries to database"):
            _write_scenario_timeseries(
                connection, output_batch_size, scenario_id, all_scenarios_quarterly,
            )

    return scenario_id


def _write_scenario_info_entry(
    connection: Connection, scenario_info_all: OneValuedInputData
) -> int:
    """Write the single entry to the `Scenario` table.

    :param connection:  DB connection
    :param scenario_info_all:  Namedtuple with the info of the quarterly scenarios
    :return: scenario_df to be written to the database
    """
    scenario_info_fields_set = set(get_named_tuple_fields(ScenarioInfo))
    scenario_info = ScenarioInfo(  # type: ignore
        **{
            key: val
            for key, val in named_tuple_asdict(scenario_info_all).items()
            if key in scenario_info_fields_set
        }
    )

    scenario_df = pd.DataFrame.from_dict([scenario_info])
    _map_df_columns_to_db_table(scenario_df)

    scenario_df.to_sql(
        name="Scenario", con=connection, if_exists="append", index=False,
    )

    # TODO [AB]: Fixes after SingleScenario Removal - Check for options without tablock
    max_id_query = "select max(ID) FROM Scenario"
    if not connection.engine.url.drivername.startswith("sqlite"):  # pragma: no cover
        max_id_query += " with (tablock, holdlock)"
    scenario_id = int(pd.read_sql_query(max_id_query, connection).values)

    _log.info("Written scenario info with id %d", scenario_id)

    return scenario_id


def _map_df_columns_to_db_table(scenario_df: pd.DataFrame) -> None:
    """ Maps the columns of scenario DataFrame with Database table

    :param scenario_df: DataFrame to be mapped
    """
    columns_dict = dict(pd.DataFrame(SCENARIO_ATTR_MAPPING).iloc[0])
    scenario_df.rename(columns=columns_dict, inplace=True)
    scenario_df["ReportingDate"] = scenario_df["ReportingDate"].map(
        yyyymmdd_int2datetime
    )
    scenario_df["ScenarioStartDate"] = scenario_df["ScenarioStartDate"].map(
        yyyymmdd_int2datetime
    )
    scenario_df["ScenarioEndDate"] = scenario_df["ScenarioEndDate"].map(
        yyyymmdd_int2datetime
    )
    scenario_df["Status"] = "New"


def _write_scenario_timeseries(
    connection: str,
    output_batch_size: int,
    scenario_id: int,
    all_scenarios_quarterly: list,
):
    """Write all the provided timeseries data to the database.

    :param connection: db engine connection
    :param output_batch_size: the number of output records to collect in one chunk
    :param scenario_id: the scenario id (foreign key) to refer to
    :param all_scenarios_quarterly: the list of all the scenarios to write
    :raises MemoryError:
    """

    output_df_iter = output_data_frame_from_optional_scenario_items(
        all_scenarios_quarterly, output_batch_size
    )

    number_of_chunks = 0
    starting_time = time.time()
    chunk_starting_time = starting_time

    for chunk_df in output_df_iter:
        number_of_chunks += 1
        chunk_df["ScenarioId"] = scenario_id

        try:
            memory_usage = chunk_df.memory_usage()
            chunk_df.to_sql(
                name="ScenarioTimeSeries",
                con=connection,
                if_exists="append",
                index=False,
            )
        except MemoryError:
            _log.error(str(memory_usage))
            raise

        chunk_starting_time = _log_writing_speed(
            len(chunk_df), chunk_starting_time, starting_time
        )
        _log.info("Chunk %r is Written", number_of_chunks)


def _create_engine(scenario_output_url_str: str) -> Engine:
    """ Creates an engine with or without fast_executemany option depending on the
    output type

    :param scenario_output_url_str: DB output string
    """
    if not scenario_output_url_str.startswith("sqlite"):  # pragma: no cover
        engine = create_engine_from_connection_string(
            scenario_output_url_str, fast_executemany=True
        )

        @event.listens_for(engine, "before_cursor_execute")
        def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
        ):  # pylint: disable=unused-variable
            # pylint: disable=unused-argument
            if executemany:  # pragma: no cover
                cursor.fast_executemany = True
                conn.execution_options(autocommit=False)

    else:
        engine = create_engine_from_connection_string(scenario_output_url_str)

    return engine


def _log_writing_speed(
    chunk_size: int, chunk_starting_time: float, starting_time: float
) -> float:
    """ Logs the speed of the db writing

    :param chunk_size: Size of the current chunk
    :param chunk_starting_time: Starting time of the current chunk
    :param starting_time: Starting time of the DB writing process
    :return: New starting_time
    """
    record_count = 0
    record_count += chunk_size
    now = time.time()
    if now >= (chunk_starting_time + _WRITE_LOG_INTERVAL):  # pragma: no cover
        write_speed_str = (
            str(round(record_count / (now - starting_time)))
            if (now - chunk_starting_time) != 0
            else "<many>"
        )
        _log.info("Written %7d records at %s records/s", record_count, write_speed_str)
        return time.time()
    return chunk_starting_time
