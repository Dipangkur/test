# type: ignore[attr-defined]
# -*- coding: utf-8 -*-
"""
The purpose of the base_reader.py file is to retrieve the dynamic data and the
static data, so other processes can use it. For instance, to get scenario start date,
get scenario end date, build the extension dataframe and so on.
"""
import logging
import os
import urllib.parse
from contextlib import closing
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from sqlalchemy.engine.url import URL, make_url
from sqlalchemy.ext.declarative import DeclarativeMeta

from scenario_calculator.db import (
    create_engine_from_connection_string,
    create_session,
    define_base,
)
from scenario_calculator.io.db_conv_utils import DbInputTransformer
from scenario_calculator.io.fields import (
    DYNAMIC_DF_COL_NAMES,
    RAW_SCENARIO_COLMAPPING,
    RAW_SCENARIO_TIMESERIES_COLMAPPING,
)
from scenario_calculator.io.file_reader import BlobReader, create_merged_mapping
from scenario_calculator.utility import time_context

URL_SCHEME_FILE = "file"

_log = logging.getLogger(__name__)


def sqlalch_url2path(raw_scen_db_conn_templ: str) -> Path:
    """Extract the local Path from the URL with 'file'-scheme.

    :param raw_scen_db_conn_templ: Points to the dynamic input data.
      The scheme-part of the url can either be 'file' (pointing to a
      csv file), or the url is an SqlAlchemy-compliant database url.
      For a definition of an SqlAlchemy-compliant database url, pls. refer to
      https://docs.sqlalchemy.org/en/latest/core/engines.html#database-urls`_.
    :raises TypeError: parameter is not a string, nor an SqlAlchemy URL
    :raises ValueError: parameter should be a 'file'-scheme URL
    :return: the Path that was coded in the file URL.
    """
    # The URL 'scheme'-part is called 'drivername' in SqlAlchemy-lingo
    url = make_url(raw_scen_db_conn_templ)
    if url.drivername != URL_SCHEME_FILE:
        if not isinstance(url, URL):
            raise TypeError(
                f"url is not instance of {URL!s}, but has type {type(url)!s} instead"
            )
        # Rest assured: ``__to_string__()`` hides the password, provided
        # it is an SqlAlchemy URL
        raise ValueError(f"Not a 'file'-scheme URL: {url.__to_string__()}")
    # Based on the os path needs to be modified with or without a '/'.
    fixpath = "/" if os.name == "posix" else ""
    return Path(urllib.parse.unquote(fixpath + url.database))


def read_dynamic_data(
    raw_scen_db_conn_templ: str,
    raw_scenario_id: Optional[int] = None,
    batch_size: Optional[int] = None,
) -> pd.DataFrame:
    """Reads dynamic data and returns a dataframe.

    :param raw_scen_db_conn_templ: Points to the dynamic input data.
      The scheme-part of the url can either be 'file' (pointing to a
      csv file), or the url is an SqlAlchemy-compliant template string.
      For a definition of an SqlAlchemy-compliant database url, pls. refer to
      https://docs.sqlalchemy.org/en/latest/core/engines.html#database-urls`_.
    :param raw_scenario_id: the id to use to select the proper raw scenario
      in case a raw_scenario database table is being used.
    :param batch_size: the amount of records to read in one go
      in case a raw_scenario database table is being used.
    :raises TypeError: raw_scenario_id or batch_size is not an int
    :return: Pandas DataFrame
    """
    # Please note that the URL follows the SqlAlchemy convention, which
    # assumes already an URL suitable for a database, but is workable for
    # other schemes as well.
    # The more generic URI package doesn't support SqlAlchemy URLs.

    if raw_scen_db_conn_templ.startswith(URL_SCHEME_FILE + ":"):
        path = sqlalch_url2path(raw_scen_db_conn_templ)
        del raw_scenario_id, batch_size  # they're not used in this case
        df = pd.read_csv(path, delimiter=";", encoding="utf-8")
        return df
    # Okay, no file, then it must be a SqlAlchemy (database) url
    if isinstance(raw_scenario_id, int) and isinstance(batch_size, int):
        return read_raw_scenario_from_db(
            raw_scen_db_conn_templ, raw_scenario_id, batch_size
        )
    else:
        raise TypeError("raw_scenario_id and batch_size should be given integer values")


def read_raw_scenario_from_db(
    raw_scen_db_conn_templ: str, raw_scenario_id: int, batch_size: int
) -> pd.DataFrame:
    """Reads the raw_scenario from the raw_scenario database table(s).

    The tables being read are RawScenario and RawScenarioTimeSeries.
    The fields/columns they contain are defined in the constants named
    `RAW_SCENARIO_COLMAPPING` and `RAW_SCENARIO_TIMESERIES_COLMAPPING`, resp.,
    in the `io.fields` module.

    The DataFrame returned have the columns with their respective names
    in the order as defined DYNAMIC_DF_COL_NAMES.
    The respective column types are defined in the RAW_SCENARIO*_COLMAPPING
    dictionaries.

    :param raw_scen_db_conn_templ: An SqlAlchemy connection template string.
      For a definition of an SqlAlchemy-compliant database url, pls. refer to
      `https://docs.sqlalchemy.org/en/latest/core/engines.html#database-urls`_.
    :param raw_scenario_id: the id to use to select the proper raw scenario.
    :param batch_size: the amount of records to read in one go.
    :return: Pandas DataFrame
    """
    # batch_size is not being used (yet)
    del batch_size
    with time_context("[1.1.1] Opening RawScenario database and initializing settings"):
        engine = create_engine_from_connection_string(raw_scen_db_conn_templ)

        base_cls: DeclarativeMeta = define_base(engine)
        # noinspection PyUnresolvedReferences
        raw_scenario_cls: DeclarativeMeta = base_cls.classes.RawScenario
        raw_scenario_input_conv = DbInputTransformer(
            raw_scenario_cls, RAW_SCENARIO_COLMAPPING
        )
        # noinspection PyUnresolvedReferences
        raw_scenario_tsrs_cls: DeclarativeMeta = base_cls.classes.RawScenarioTimeSeries
        raw_scenario_tsrs_input_conv = DbInputTransformer(
            raw_scenario_tsrs_cls, RAW_SCENARIO_TIMESERIES_COLMAPPING
        )

    session = create_session(engine)
    with closing(session):
        _log.info("Reading RawScenario & Timeseries with id %d", raw_scenario_id)
        # get the specific row from RawScenario table - fail if not exactly one is found
        with time_context("[1.1.2] Reading 1 row from RawScenario table"):
            # Read raw scenario table
            raw_scen_row = (
                session.query(*raw_scenario_input_conv.make_orm_query_fields())
                .filter_by(Id=raw_scenario_id)
                .one()
            )
            # Get the transpose of the result and assign into a pandas dataframe
            raw_scen_row_df = pd.DataFrame(raw_scen_row).T
            # Add the column headings
            raw_scen_row_df.columns = raw_scen_row.keys()
            # Rename the column heading
            raw_scen_row_df = raw_scenario_input_conv.rename_columns_heading(
                raw_scen_row_df
            )
            # Transform the data and change the data type
            raw_scen_row_df = raw_scenario_input_conv.xform_data_and_change_data_type(
                raw_scen_row_df
            )

        with time_context("[1.1.3] Reading rows from RawScenarioTimeSeries table"):
            # Now fetch all the RawScenarioTimeSeries rows and put them in a data frame
            rs_tsrs_rows = session.query(
                *raw_scenario_tsrs_input_conv.make_orm_query_fields()
            ).filter_by(RawScenarioId=raw_scenario_id)
            # Put data into pandas dataframe
            df = pd.read_sql(rs_tsrs_rows.statement, rs_tsrs_rows.session.bind)
            # rename the column heading
            df = raw_scenario_tsrs_input_conv.rename_columns_heading(df)
            # Transform the data and change the data type
            df = raw_scenario_tsrs_input_conv.xform_data_and_change_data_type(df)

    nr_rows = df.shape[0]
    _log.info("Fetched %d entries from RawScenarioTimeSeries table", nr_rows)
    # Now create additional columns in the data frame, where each row contains the same
    # value. The actual value is taken from the translated raw scenario row.

    # Replicate the rows of the raw_scen_row_df to the number times of the rows fetched
    # from RawScenarioTimeSeries table.
    raw_scen_row_df = pd.concat([raw_scen_row_df] * df.shape[0])
    # Combine both dataframes
    for col in list(raw_scen_row_df):
        df[col] = raw_scen_row_df[col].values
    df = df.reindex(columns=DYNAMIC_DF_COL_NAMES, copy=False)

    return df


def read_static_data(
    static_data_dir: Path,
    file_mapping: Dict[str, str],
    is_lab: bool = False,
    blob_file_list: List[str] = None,
) -> Dict[str, pd.DataFrame]:
    """Reads all the static data from csv files or from blob storage depending on is_lab

    This is needed to extend the time series.

    Returns a dictionary containing various data frames which the keys are
    given by the file_mapping.

    A mapping is used to switch the name of the files that CAS gets from MES.
    the mapping is needed to know the origin of the file i.e. ARIMA etc.
    Yet, in the code it is transferred to the designated use.

    :param static_data_dir: a path to the static data directory
    :param file_mapping: a dict. that gives the right name for each static data
    :param is_lab: bool value for deciding if the run is a lab run
    :param blob_file_list: list of static files to be read from blob storage
    :raises FileNotFoundError: If the given blob file doesn't exist
    :return: dictionary containing various static Pandas data frames
    """

    # Retrieve data from the data directory as a dictionary of data frames
    # For the missing_countries_mapping frame, don't keep default na because of the
    # country code of Namibia (NA)

    static_dict = {
        descr: pd.read_csv(
            static_data_dir / fname,
            delimiter=";",
            encoding="utf-8",
            keep_default_na=descr != "missing_countries_mapping",
        )
        for descr, fname in file_mapping.items()
    }

    # Get Merged Mapping if it is a lab run and overwrite static_dict
    if is_lab and blob_file_list:
        merged_mapping = create_merged_mapping(blob_file_list, file_mapping)
        _log.info(
            "Static File Mapping Merged with Blob Storage: \n %s",
            merged_mapping.to_string(),
        )
        for _, row in merged_mapping.loc[merged_mapping["is_blob"] == 1].iterrows():
            blob_reader = BlobReader(row["file_name"])

            if not blob_reader.blob_exists():
                error_message = (
                    "File couldn't be found in the BlobStorage: " + row["file_name"]
                )
                _log.info(error_message)
                raise FileNotFoundError(error_message)

            static_dict[row["df_name"]] = blob_reader.read_blob(
                (row["df_name"] != "missing_countries_mapping")
            )

    return static_dict
