# type: ignore
# TODO [AB]: Fix mypy errors after TimeSeries & OutputRow removal PBIs
"""SBV (GBV) compliant output  is written to csv flat file(s). Output
specifications are written down in a System Interface Specifications
(SIS) document.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
Reference: "SIS MES to STIB v0.3"
"""

import logging
from pathlib import Path
from typing import Sequence

import pandas as pd

from scenario_calculator.io.base_writer import (
    output_data_frame_from_optional_scenario_items,
)
from scenario_calculator.io.reader import OneValuedInputData
from scenario_calculator.settings import Settings
from scenario_calculator.utility import mes_csv_writer

_ASSUMED_SBV_NBROF_COLS = 13

logger = logging.getLogger(__name__)


# =============================================================================
# Write output to csv files:
# =============================================================================


def write_output_to_csv(
    basename_gbv: str,
    basename_si: str,
    output: list,
    scenario_info: OneValuedInputData,
    out_dir: Path = Settings.DATA_OUT_DIR,
) -> None:
    """
    This function writes SBV and GBV compliant output to a csv files.

    :param basename_gbv: the basename of the GBV file
    :param basename_si: the basename of the SCENARIO INFO file
    :param output: list of optional scenarios items
    :param scenario_info: namedtuple with the info of the quarterly scenarios
    :param scenario_start_date: scenario start date, retrieved from dynamic df,
      coded as YYYYMMDD
    :param out_dir: the location of the output directory
    """
    # create output directory if it doesn't exist yet
    out_dir.mkdir(exist_ok=True)
    hdr_ovid = OneValuedInputData.csv_field_titles()
    writer_si = mes_csv_writer(basename_si, out_dir, hdr_ovid, delimiter=";")
    writer_si.writerow(scenario_info)

    output_df_list = []
    for output_df in output_data_frame_from_optional_scenario_items(output, 1000):
        output_df_list.append(output_df)

    final_df = pd.concat(output_df_list)
    final_df = final_df.loc[:, ~final_df.columns.str.contains("^Unnamed")]
    final_df["ValueDate"] = final_df["ValueDate"].dt.strftime("%d-%m-%Y")

    final_df.to_csv(path_or_buf=str(out_dir) + "/" + basename_gbv, sep=";", index=False)


# =============================================================================
# Private helper functions:
# =============================================================================


def _check_sbv_settings_assumptions(
    hdr_sbv: Sequence[str], hdr_gbv: Sequence[str]
) -> None:  # pragma: no cover
    """Check whether some assumptions on SBV and GBV headers still hold.

    :param hdr_sbv: The SBV column names heading
    :param hdr_gbv: The GBV column names heading
    :raises AssertionError: one or more of the mentioned assumptions don't hold
    """
    if len(hdr_sbv) != _ASSUMED_SBV_NBROF_COLS:
        raise AssertionError(
            f"The number of SBV columns ({len(hdr_sbv)})"
            f" differs from what is assumed ({_ASSUMED_SBV_NBROF_COLS})"
        )
    if hdr_gbv[:_ASSUMED_SBV_NBROF_COLS] != hdr_sbv:
        raise AssertionError(
            f"The SBV header ({hdr_sbv}) is not an initial subset"
            f" (of {_ASSUMED_SBV_NBROF_COLS}) of GBV header ({hdr_gbv})"
        )
