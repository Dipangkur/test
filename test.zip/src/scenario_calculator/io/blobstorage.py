# type: ignore[attr-defined]
# TODO [AB]: Improved from MSR.ScenarioCreator.Py project.
#  Make it an multi-usable module.
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
import re
from io import BytesIO, TextIOWrapper

from azure.storage.blob import BlockBlobService

from scenario_calculator.utility import url_str2path

BLOB_READER_URL_PATTERN = (
    r"^https://(?P<account_name>.+?)\.blob\.core\.windows\.net/"
    r"(?P<container>.+?)/(?P<filename>.+?)$"
)


class BlobReaderBackend:
    def __init__(self, account_key, uri):
        match = re.match(BLOB_READER_URL_PATTERN, uri)
        if not match:
            raise ValueError(f"Invalid url: {uri}")

        match_group = match.groupdict()
        self.account_name = match_group["account_name"]
        self.container = match_group["container"]
        self.filename = match_group["filename"]
        self.service = BlockBlobService(
            account_name=self.account_name, account_key=account_key
        )

    def __enter__(self):
        self.stream = BytesIO()
        self.service.get_blob_to_stream(self.container, self.filename, self.stream)
        self.stream.seek(0)
        wrapper = TextIOWrapper(self.stream, encoding="utf-8")
        return wrapper

    def __exit__(self, *_):
        self.stream.close()


class FileReaderBackend:
    def __init__(self, uri):
        self.file_obj = url_str2path(uri).open()

    def __enter__(self):
        return self.file_obj

    def __exit__(self, *_):
        self.file_obj.close()
