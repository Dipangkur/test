# type: ignore
# -*- coding: utf-8 -*-
"""
This file contains lists and dictionaries of name of columns of the input and the output
data.

The GBV are the names of the columns of the table that contains extended and enriched
scenario data computed by the calculator. This defined as Generic Business View (GBV).

The SBV are the names of the columns of the table that contains extended and enriched
scenario data computed by the calculator and are used by DART to perform the IFRS9 ECL
and stress testing computations. This is defined as Specific Business View.

The DYNAMIC_DF_COL_NAMES are the names of the columns of the table that comes from the
dynamic file.

The EXTENSION_DF_COL_NAMES are the names of the columns of the table that comes from the
dynamic file and the static files together.

The dictionaries, on the other hand, are compatible with the SIS.
"""

# TODO: Fix the HDR_SBV, HDR_GBV and EXTENSION_DF_COL_NAMES to use only the dictionaries
from numpy import float64, int64

# # type: ignore[attr-defined]
from scenario_calculator.data_attr_rename_and_xform import ATTR_MAPPING_DESC
from scenario_calculator.utility import datetime2yyyymmdd_int, yyyymmdd_int2datetime

EXTENSION_DF_COL_NAMES = [
    "id",
    "date",
    "source",
    "scenario",
    "time_series_code",
    "period",
    "value",
    "type",
    "unit",
    "date_index",
    "year",
    "quarter",
    "nigem_country_code",
    "variable_code",
    "corep_country_code",
    "model_param_beta_0",
    "model_param_beta_1",
    "model_param_d",
    "conversion_factor",
    "variable_type",
    "extension_transformation_type",
    "aggregation_transformation_type",
]

DYNAMIC_DF_COL_NAMES = [
    "id",
    "date",
    "source",
    "scenario",
    "time_series_code",
    "period",
    "value",
    "type",
    "unit",
    "description",
]

# The following 2 RAW_SCENARIO_*COLMAPPING defs are derived from the SQL create commands
# They (also) contain the mapping from the database column names to the
# (internal) dataframe column names, possibly accompanied by a dataframe type.
# Please note that field documentation is on the line following the field name.

# Input tables
RAW_SCENARIO_COLMAPPING: ATTR_MAPPING_DESC = {
    "Id": None,  # IDENTITY(1, 1) NOT NULL,
    "CreationDateTime": None,  # DATETIME2(3) NOT NULL,
    "RawScenarioName": "scenario",  # [varchar](100) NOT NULL,
    "ReportingDate": ("date", int64, datetime2yyyymmdd_int),  # DATETIME2(3) NOT NULL,
    "Creator": None,  # [varchar](20) NOT NULL,
    "RawScenarioStatus": None,  # [varchar](20) NOT NULL,
    "ReviewedBy": None,  # [varchar](100) NULL,
    "ReviewDate": None,  # DATETIME2(3) NULL,
    "MeisterVersion": None,  # [varchar](200) NOT NULL,
    "ReviewMessage": None,  # NVARCHAR(MAX) NULL,
    "RawScenarioDescription": None,  # NVARCHAR(100) NULL,
    "ScenarioDescriptionFile": None,  # NVARCHAR(MAX) NULL,
    "IsLab": None,  # BIT NOT NULL,
    # PRIMARY KEY (Id)
}

RAW_SCENARIO_TIMESERIES_COLMAPPING: ATTR_MAPPING_DESC = {
    "Id": "id",  # [int] IDENTITY(1,1) NOT NULL
    "RawScenarioId": None,  # [int] NOT NULL
    "CreationDateTime": None,  # DATETIME2(3) NOT NULL
    "TimeSeriesCode": "time_series_code",  # [varchar](12) NOT NULL
    "RawScenarioTimeSeriesPeriod": "period",  # [varchar](6) NOT NULL
    "RawScenarioTimeSeriesValue": ("value", float64),  # Float(53) NOT NULL
    "RawScenarioTimeSeriesType": "type",  # [nvarchar](12) NOT NULL
    "RawScenarioTimeSeriesUnit": "unit",  # [nvarchar](12) NOT NULL
    "RawScenarioTimeSeriesSource": "source",  # [nvarchar](100) NOT NULL
    "RawScenarioTimeSeriesDescription": "description",  # [nvarchar](255) NULL
    # PRIMARY KEY (ID),
    # FOREIGN KEY (RawScenarioId) REFERENCES [dbo].[RawScenario](Id)
}

SCENARIO_ATTR_MAPPING: ATTR_MAPPING_DESC = {
    # *GENERATE*: None: "Id",  # INT NOT NULL PRIMARY KEY: n/a
    "scenario_name": "ScenarioName",  # varchar(100) NOT NULL: tsrs.scenario
    "scenario_creation_datetime": "ScenarioCreationDatetime",  # datetime2(3):
    #   current_datetime
    "originating_raw_scenario_id": "OriginatingRawScenarioId",  # int NOT NULL: n/a
    "reporting_date": ("ReportingDate", None, yyyymmdd_int2datetime),  # datetime2(3)
    #   NOT NULL: tsrs.date
    "scenario_start_date": ("ScenarioStartDate", None, yyyymmdd_int2datetime),
    #   datetime2(3) NOT NULL: n/a
    "scenario_end_date": ("ScenarioEndDate", None, yyyymmdd_int2datetime),
    #   datetime2(3) NOT NULL: n/a
    "scenario_creator": "ScenarioCreator",  # varchar(255) NOT NULL: n/a
    # *GENERATE*: "status": "Status",  # varchar(20) NOT NULL CHECK ([Status] IN (
    #   'New', 'Accepted', 'Declined', 'Approved', 'Declined by SSTC')): n/a
    # None: "ReviewedBy",  # varchar(100): n/a
    # None: "ReviewDate",  # datetime2(3): n/a
    # None: "ApprovedBy",  # varchar(100): n/a
    # None: "ApprovalDate",  # datetime2(3): n/a
    # None: "SSTCApprovalDate",  # datetime2(3): n/a
    "model_version": "ModelVersion",  # varchar(255) NOT NULL: n/a
    "model_description": "ModelDescription",  # nvarchar(255) NOT NULL: n/a
    "calculator_version": "CalculatorVersion",  # varchar(255) NOT NULL: n/a
    "meister_version": "MeisterVersion",  # varchar(255) NOT NULL: n/a
    "calculation_date": "CalculationDate",  # datetime2(3): n/a
    "scenario_description": "ScenarioDescription",  # nvarchar(100): n/a
    # None: "Comment",  # nvarchar(MAX): n/a
    # None: "QAFile",  # nvarchar(MAX): n/a
    # None: "RawScenarioGraph",  # nvarchar(MAX): n/a
    # None: "ApprovalReport",  # nvarchar(MAX): n/a
    "is_lab": "IsLab",  # BIT NOT NULL,
}

SCENARIO_TIMESERIES_ATTR_MAPPING: ATTR_MAPPING_DESC = {
    # *GENERATE*: None: "Id",  # INT NOT NULL PRIMARY KEY: n/a
    # *GENERATE*: None: "ScenarioId",  # int NOT NULL: (Scenario(Id))
    # *NOT PRESENT*: None: "OriginatingRawScenarioTimeSeriesId",  # int NOT NULL: n/a
    "macro_economic_variable": "MacroEconomicVariable",
    #   nvarchar(50) NOT NULL: tsrs.variable_code
    "value": "Value",  # Float(53) NOT NULL: format_float_for_csv_out(value1)
    "unit": "Unit",  # nvarchar(12) NOT NULL: tsrs.unit
    "value_date": "ValueDate",  # date: format_date_for_csv_out(index)
    "type_": "Type",  # nvarchar(50) NOT NULL: observation_type
    "standardized_value": "StandardizedValue",  # Float(53): value2
    "sigma": "Sigma",  # Float(53): sigma
    "mu": "Mu",  # Float(53): mu
    "corep_code": "CorepCode",  # varchar(2) NOT NULL: tsrs.corep_code
    "nigem_code": "NigemCode",  # varchar(2): tsrs.nigem_code
    "mapped_to_variable_code": "MappedToVariableCode",
    "mapped_to_corep_code": "MappedToCorepCode",
    "tool_data_adjustment": "ToolDataAdjustment",
}

SCENARIO_ITEM_TO_OUTPUT_DATAFRAME_MAPPING = {
    "corep_code": "CorepCode",
    "variable_code": "MacroEconomicVariable",
    "mapped_to_corep_code": "MappedToCorepCode",
    "mapped_to_variable_code": "MappedToVariableCode",
    "param_mu": "Mu",
    "nigem_code": "NigemCode",
    "originating_raw_scenario_time_series_id": "OriginatingRawScenarioTimeSeriesId",
    "param_sigma": "Sigma",
    "adjustment": "ToolDataAdjustment",
    "unit": "Unit",
    "value": "Value",
    "date_index": "ValueDate",
}

OUTPUT_DATAFRAME_COLUMS = [
    "CorepCode",
    "MacroEconomicVariable",
    "MappedToCorepCode",
    "MappedToVariableCode",
    "Mu",
    "NigemCode",
    "OriginatingRawScenarioTimeSeriesId",
    "Sigma",
    "ToolDataAdjustment",
    "Type",
    "Unit",
    "Value",
    "ValueDate",
]


COMPONENT_TEST_OUTPUT_COLUMNS = [
    "CorepCode",
    "MacroEconomicVariable",
    "MappedToCorepCode",
    "MappedToVariableCode",
    "Mu",
    "NigemCode",
    "OriginatingRawScenarioTimeSeriesId",
    "Sigma",
    "StandardizedValue",
    "ToolDataAdjustment",
    "Type",
    "Unit",
    "Value",
    "ValueDate",
]
