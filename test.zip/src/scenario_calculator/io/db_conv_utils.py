# type: ignore[attr-defined]
from typing import Iterator, List

from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm.attributes import InstrumentedAttribute

from scenario_calculator.data_attr_rename_and_xform import (
    ATTR_MAPPING_DESC,
    DataFrameTransformer,
)


class DbInputTransformer(DataFrameTransformer):
    """Provides additional functionality, targeted to transform input from database.

    This class provides the same functionality as the `DataFrameTransformer` class
    does, plus a little more...

    Compared to its base class, the first parameter of __init__ should now be
    a Database Model class instead of a class name.

    One additional method is provided: `make_orm_query_fields` (q.v.).
    """

    def __init__(
        self, model_cls: DeclarativeMeta, attr_mapping_desc: ATTR_MAPPING_DESC
    ):
        """Initialise the DbInputTransformer instance.

        :param model_cls: the class that describes the model of the input table
        :param attr_mapping_desc: a dictionary describing
          * what fields should be queried for
          * what type they should be converted to
          * and possibly what data transformation is needed
          (refer to the description of `ATTR_MAPPING_DESC`)
        """
        self._model_cls = model_cls
        super().__init__(model_cls.__name__, attr_mapping_desc)

    def make_orm_query_fields(self) -> List[InstrumentedAttribute]:
        """Construct a list of ORM query fields.

        The fields to be queried for is determined by the `attr_mapping_desc` parameter
        of this class' `__init__` method.

        The returned list of (SqlAlchemy) instrumented attributes can directly
        be used in an ORM query, using the varargs `*` operator like
        `session.query(*returned_list)`.

        :return: Those SqlAlchemy Column attribute objects that need be queried for.
        """
        return [
            getattr(self._model_cls, df_column_desc.source_attr_name)
            for df_column_desc in self._attr_conv_spec
        ]


def iter_db_field_attributes(
    model_cls: DeclarativeMeta,
) -> Iterator[InstrumentedAttribute]:
    """Return an iterator over all field attributes of a SqlAlchemy model class.

    :param model_cls: the model class of the SqlAlchemy table
    :return: An iterator of attributes
    """
    return (
        field_attr
        for field_attr in vars(model_cls).values()
        if isinstance(field_attr, InstrumentedAttribute)
    )
