# type: ignore[attr-defined]
# -*- coding: utf-8 -*-
"""
The purpose of the reader is to retrieve the input from various sources,
organize the data and return a dictionary of data frames ready to use for
calculation purposes.

The architecture of the reader is as follows:
1. Reads data from external data sources to a dictionary of data frames.
2. Reads data from internal data source to a data frames, meaning static data.
3. Build the extended dataframe without Agriland.
4. Merge Agriland dataframe, if it exists.

Reference: "MES Enrichment of Macroeconomic Scenarios Methodology".
Reference: "SIS MES to STIB v0.3"
"""
from datetime import datetime
from pathlib import Path
from typing import Dict, List, NamedTuple, Tuple

import numpy as np
import pandas as pd
from more_itertools import one

from scenario_calculator import __version__
from scenario_calculator.config import RunDefinition
from scenario_calculator.constants import DEFAULT_DATA_FREQ, TEST_FREQ
from scenario_calculator.io import fields
from scenario_calculator.io.agriland_parameters import get_original_agriland_frame
from scenario_calculator.io.base_reader import read_dynamic_data, read_static_data
from scenario_calculator.io.pre_process import (
    calc_scenario_start_date,
    get_end_year_extension,
    get_frequency,
    get_reporting_date,
    get_scenario_end_date,
    get_scenario_name,
)
from scenario_calculator.modelling.agriland import apply_agriland_model
from scenario_calculator.other_country import (
    add_missing_rxeu_values,
    apply_conversion_factor,
    apply_currency_conversion,
    create_other_country_df,
    truncate_dynamic_df,
)
from scenario_calculator.utility import (
    add_columns_to_frame,
    generate_quarter_format,
    join_frames,
    time_context,
)

# =============================================================================
# Collect and order the data frames from different sources in the required form
# =============================================================================


class OneValuedInputData(NamedTuple):
    """A named tuple holding return values from read_and_extend_input(), which are basic
    types. Those values are either fetched as is or calculated from the dynamic data, or
    fetched from the swagger.

    | The following attribute instance variables are defined:
    | scenario_name: the scenario_name
    | scenario_creation_datetime: the actual date when the ScenarioCalculator starts
    | the calculation
    | originating_raw_scenario_id: the id of the originating RawScenario
    | reporting_date: the reporting date, coded as YYYYMMDD
    | scenario_start_date: the start date, coded as YYYYMMDD
    | scenario_end_date: extension end date, coded as YYYYMMDD
    | scenario_creator: the user who created the scenario
    | model_version: the version of the model that the MES team gave CAS to produce
    | model_description: the description of the model that the MES team gave CAS to
    | produce
    | calculator_version: the version of CAS ScenarioCalculator python code
    | meister_version: the version(s) identifying the component(s) that form(s) the
    | Meister functionality
    | calculation_date: the date when the user has activated the calculation in the
    | GUI part
    | calculation_date: the date when the user has activated the calculation in the
    | GUI part
    | scenario_description: the description the user has entered before the
    | calculation fired up in the GUI part
    | end_year_extension: extension end year
    | frequency: the frequency
    | is_lab: is lab
    """

    scenario_name: str
    scenario_creation_datetime: datetime
    originating_raw_scenario_id: int
    reporting_date: int
    # TODO: fix reporting_date to be datetime type like in the SIS
    scenario_start_date: int
    scenario_end_date: int
    scenario_creator: str
    model_version: str
    model_description: str
    calculator_version: str
    meister_version: str
    calculation_date: datetime
    scenario_description: str

    # The following attributes are derived from the input...
    end_year_extension: int
    frequency: str
    is_lab: bool

    @classmethod
    def csv_field_titles(cls) -> Tuple[str, ...]:
        """Return a tuple containing all "titled"  attribute names of this object/class.

        A tuple is returned, containing the attribute names, processed to `str.title()`.
        The order of the "titled" attribute is equal to the order they are declared
        in this very class.

        :return: A tuple of this class' "titled" attribute names, in order.
        """
        return tuple(field_name.title() for field_name in cls._fields)


class ReadAndExtendedInputData(NamedTuple):
    """A named tuple holding return values from read_and_extend_input().

    | The following attribute instance variables are defined:
    | frames: a dict of input data frames (dynamic and static)
    | one_valued_input_data: a namedtuple of basic info of the scenario
    """

    frames: Dict[str, pd.DataFrame]
    one_valued_input_data: OneValuedInputData


def read_and_extend_input(
    raw_scen_db_conn_templ: str,
    local_path: Path,
    file_mapping: Dict[str, str],
    batch_size: int,
    run_definition: RunDefinition,
) -> ReadAndExtendedInputData:
    """Read/extend static/dynamic data from csv files and possibly database.

    Builds and returns(amongst others) an extension dataframe.
    The function first handles all the input excluding Agriland and after
    that Agriland is processed. The function will return a dictionary
    of dataframes, where the "scenarios" dataframe originated from the
    dynamic input and the rest is obtained from static data, and ordered
    according to the file_mapping dictionary.

    Besides the mentioned dataframes, also some other (from the input derived)
    data items are returned, as laid out in the ``ReadAndExtendedInputData``
    structure.

    :param raw_scen_db_conn_templ: Points to the dynamic input data.
      The scheme-part of the url can either be 'file' (pointing to a
      csv file), or the url is an SqlAlchemy-compliant template string.
      For a definition of an SqlAlchemy-compliant database url, pls. refer to
      https://docs.sqlalchemy.org/en/latest/core/engines.html#database-urls`_.
    :param local_path: the path were we read the static data files from
    :param file_mapping: a dict. that gives the right name for each static data
    :param batch_size: the amount of records to read in one go
      in case a raw_scenario database table is being used.
    :param run_definition: holds parameters that are collected from the swagger
    :return: a tuple with a dict containing the dataframes that need further
      processing, and a few other relevant values for further use.
    """
    dynamic_df, reporting_date, static_data_dict = read_dynamic_and_static_data(
        batch_size, file_mapping, local_path, raw_scen_db_conn_templ, run_definition
    )

    _, dynamic_df, static_data_dict = apply_agriland_model(
        dynamic_df, static_data_dict, reporting_date
    )

    dynamic_df = add_missing_rxeu_values(dynamic_df)
    dynamic_df, oc_appended_dynamic_df = calculate_and_append_other_country(
        dynamic_df, static_data_dict, TEST_FREQ
    )
    return make_the_first_extension(
        dynamic_df,
        oc_appended_dynamic_df,
        reporting_date,
        run_definition,
        static_data_dict,
    )


def read_dynamic_and_static_data(
    batch_size, file_mapping, local_path, raw_scen_db_conn_templ, run_definition,
):
    # Retrieve data from cloud and local dir, clean it and build extension df
    scheme = raw_scen_db_conn_templ.split(":", maxsplit=1)[0]
    with time_context(f"[1.1] reading dynamic data (scheme={scheme!r})"):
        dynamic_df = read_dynamic_data(
            raw_scen_db_conn_templ, run_definition.raw_scenario_id, batch_size
        )
        reporting_date = get_reporting_date(dynamic_df)
    static_data_dict = read_static_data(
        local_path, file_mapping, run_definition.is_lab, run_definition.static_file_urls
    )
    static_data_dict["agriland"] = get_original_agriland_frame(
        static_data_dict["agriland_org"],
        get_scenario_name(dynamic_df),
        generate_quarter_format(reporting_date),
    )
    return dynamic_df, reporting_date, static_data_dict


def calculate_and_append_other_country(
    dynamic_df, static_data_dict, minimum_data_freq=DEFAULT_DATA_FREQ
):
    with time_context("[1.3] Calculating the Other Country"):
        other_country_df = _prepare_other_country_data(dynamic_df, static_data_dict)
        other_country_df = _calculate_other_country(
            other_country_df, static_data_dict, minimum_data_freq
        )
        if other_country_df is not None and ~other_country_df.empty:
            dynamic_df = _append_other_country(dynamic_df, other_country_df)

        oc_appended_dynamic_df = dynamic_df.copy()
    return dynamic_df, oc_appended_dynamic_df


def make_the_first_extension(
    dynamic_df, oc_appended_dynamic_df, reporting_date, run_definition, static_data_dict
):
    with time_context("[1.4] Adding new columns to the dynamic data"):
        frames = _join_frames_without_agriland(dynamic_df, static_data_dict)
        frames["oc_appended_dynamic_df"] = oc_appended_dynamic_df
        # Creates dynamic Agriland dataframe from the static Agriland
        scenario_name = get_scenario_name(dynamic_df)
        start_date = calc_scenario_start_date(reporting_date)

        # Join the Agriland dataframe to the extension df only if it's available:
        if "agriland" in frames.keys():
            frames["extension"] = _agriland_join_frames(
                frames["extension"], frames["agriland"], fields.EXTENSION_DF_COL_NAMES
            )
        scenario_end_date = get_scenario_end_date(
            reporting_date, frames["nbrof_years_extension"]
        )
        end_year_extension = get_end_year_extension(scenario_end_date)
        frequency = get_frequency(reporting_date)
    # collecting all the one-valued input and the dataframes. The fields that will be
    # filled by the C# side are filled for now with None
    return ReadAndExtendedInputData(
        frames=frames,
        one_valued_input_data=OneValuedInputData(
            scenario_name=scenario_name,
            scenario_creation_datetime=run_definition.current_datetime,
            originating_raw_scenario_id=run_definition.raw_scenario_id,
            reporting_date=reporting_date,
            scenario_start_date=start_date,
            end_year_extension=end_year_extension,
            scenario_end_date=scenario_end_date,
            scenario_creator=run_definition.scenario_creator,
            frequency=frequency,
            model_version=one(frames["model_info"].model_version),
            model_description=one(frames["model_info"].model_name),
            calculator_version=__version__.__version__,
            meister_version=run_definition.meister_version,
            calculation_date=run_definition.calculation_date,
            scenario_description=run_definition.scenario_description,
            is_lab=run_definition.is_lab,
        ),
    )


def _join_frames_without_agriland(
    dynamic_df: pd.DataFrame, static_data: Dict[str, pd.DataFrame]
) -> Dict[str, pd.DataFrame]:
    """
    The dataframe we got from the cloud and the static data dataframes
    dictionary should be merged and cleaned up in a certain way in order to
    build the extended raw scenario.
    This part does not include handling the Agriland dataframe.

    :param dynamic_df: the datafarame we read from the cloud sql db
    :param static_data: dict. of the static data in the form of dataframes
    :return: dict. containing various dataframes that had been reorganised
    """
    frames = dict()

    # Add new df to the dictionary
    frames["scenarios"] = dynamic_df

    # Add the local sd-dictionary of df to the external cloud-dictionary of df
    frames.update(static_data)

    # Manipulate the date column to three columns in the cloud dataframe:
    frames["scenarios"] = add_columns_to_frame(frames["scenarios"])

    # Perform left join on variable_code
    frames["extension"] = join_frames(
        frames["variables"], frames["extension"], ["variable_code"]
    )

    # Perform left join on time_series_code and taking only the relevant
    # columns for extension
    frames["extension"] = join_frames(
        frames["scenarios"], frames["extension"], ["time_series_code"]
    )[fields.EXTENSION_DF_COL_NAMES]

    return frames


def _agriland_join_frames(
    left_df: pd.DataFrame, right_df: pd.DataFrame, col_names: List[str]
) -> pd.DataFrame:
    """
    Join left_df on right_df. Here right_df is a dataframe with Agriland data.
    The left_df that we will use is the extension dataframe.
    Agriland prices are an important variable for Rabobank, but are missing
    some countries in the RR delivery. Hence, we need to check if Agriland
    exists.

    :param left_df: left dataframe
    :param right_df: contains Agriland dataframe, or an empty dataframe
    :param col_names: List of columns to be kept in the returned DataFrame
    :return: Extension dataframe joined to Agriland dataframe
    """
    # If Agriland dataframe is not empty preform a join
    if not right_df.index.empty:
        cols = ["time_series_code", "scenario"]
        return join_frames(left_df, right_df, cols)
    return left_df[col_names]


def _prepare_other_country_data(
    dynamic_df: pd.DataFrame, static_data_dict: Dict[str, pd.DataFrame]
) -> pd.DataFrame:
    """Make OTHER country data ready for calculation

    Pls. refer to ``scenario_calculator.other_country``
    for a more elaborate description of the functionality.

    :param dynamic_df: Dynamic dataframe
    :param static_data_dict: str - DataFrame pairs for static data
    :return: other_country_dynamic_df: final DataFrame after truncation, conversion
    factor and currency conversion
    """

    truncated_dynamic_df = truncate_dynamic_df(
        dynamic_df, static_data_dict["other_country_start_year"]
    )

    conversion_applied_dynamic_df = apply_conversion_factor(
        truncated_dynamic_df, static_data_dict["extension"]
    )

    other_country_dynamic_df = apply_currency_conversion(
        conversion_applied_dynamic_df,
        static_data_dict["other_country_price_variables"],
        static_data_dict["other_country_euro_countries"],
    )

    return other_country_dynamic_df


def _calculate_other_country(
    dynamic_df: pd.DataFrame,
    static_data_dict: Dict[str, pd.DataFrame],
    minimum_data_freq: int,
) -> pd.DataFrame:
    """ Calcuate Other Country

    Calls create_other_country_df function after other country data preparation phase

    :param dynamic_df: input DataFrame in raw scenario format
    :param static_data_dict: str DataFrame pairs for static data
    :param minimum_data_freq: int for defining minimum range of the data
    :return: other_country_dynamic_df: final DataFrame after calculation
    """
    return create_other_country_df(
        dynamic_df, static_data_dict["other_country_weights"], minimum_data_freq
    )


def _append_other_country(
    dynamic_df: pd.DataFrame, other_country_df: pd.DataFrame
) -> pd.DataFrame:
    """" Append other_country_df to dynamic_df

    Creates new id's for other_country_df starting from the latest id of dynamic_df
    and appends the calculated other_country_df under dynamic_df

    @:param dynamic_df: pd.DataFrame, DataFrame to be extended
    @:param other_country_df: pd.DataFrame, calculated DataFrame to be appended
    @:returns: dynamic_df with calculated other_country_df
    """
    new_id_range = (
        np.arange(len(other_country_df))
        + dynamic_df.id.iloc[dynamic_df.id.last_valid_index()]
        + 1
    )
    other_country_df["id"] = new_id_range.astype(int)
    dynamic_df = pd.concat([dynamic_df, other_country_df], axis=0, ignore_index=True)

    return dynamic_df.dropna(how="any", subset=["value"])
