import re

import click
import logging
import pathlib
from typing import Tuple

import sys

_PYTHON_VERSION_SPEC_RE = r"^python-(\d+)\.(\d+)\.(\d+)$"

logging.basicConfig()


def enable_debug(ctx: click.Context, _, value: bool) -> None:
    if value and not ctx.resilient_parsing:
        logging.getLogger("").setLevel(logging.DEBUG)
        logging.debug("Debug logging enabled")


@click.command()
@click.option(
    "--debug", is_flag=True, callback=enable_debug, expose_value=False, is_eager=True
)
@click.option("--warn-only/--no-warn-only", default=False)
@click.option(
    "--runtime-file",
    "runtime_str_path",
    type=click.Path(exists=True),
    default="runtime.txt",
    help="The file specifying the Python runtime version.",
)
def verify_runtime_version(warn_only: bool, runtime_str_path: str) -> None:
    """Program that checks Python's version against the runtime version file.

    :param warn_only: only issue a warning on version mismatch, instead of error
    :param runtime_str_path: the path to the runtime specification file
    :raises SystemExit: with an error string as argument when version mismatch
    """
    line = _get_runtime_line(runtime_str_path)
    required_version_tuple = _get_required_version(line)
    actual_version_tuple = sys.version_info[:3]
    if actual_version_tuple != required_version_tuple:
        message = (
            f"actual_version {actual_version_tuple!r}"
            f" != required_version {required_version_tuple!r}"
        )
        if warn_only:
            click.echo(f"warning: {message}", err=True)
        else:
            raise SystemExit(f"error: {message}")


def _get_runtime_line(runtime_str_path: str) -> str:
    """Extract the runtime line from the file specified by the path parameter.

    :param runtime_str_path: path to the file specifying the runtime
    :raises click.ClickException: when there is not exactly one line in the file
    :return: the single line from the file
    """
    logging.debug(
        "runtime_str_path: %r, type: %s", runtime_str_path, type(runtime_str_path)
    )
    runtime_path = pathlib.Path(runtime_str_path)
    with runtime_path.open() as runtime_file:
        lines = runtime_file.readlines()
    nbrof_lines = len(lines)
    if nbrof_lines != 1:
        raise click.ClickException(
            f"exactly one single line expected,"
            f" now {runtime_path!s} contains {nbrof_lines:d}"
        )
    line = lines[0].strip()
    return line


def _get_required_version(line: str) -> Tuple[int, ...]:
    """Extract the required version from the runtime specification line.

    :param line: the line to parse
    :raises click.ClickException: the line is according to standards
      (i.e. should match the `_PYTHON_VERSION_SPEC_RE` regular expression)
    :return: the required version
    """
    match = re.match(_PYTHON_VERSION_SPEC_RE, line)
    if not match:
        raise click.ClickException(
            f"python_version_requirment_line {line!r}"
            f" does not match regular expression r'{_PYTHON_VERSION_SPEC_RE}'"
        )
    required_version_tuple = tuple(int(group) for group in match.groups())
    return required_version_tuple


if __name__ == "__main__":
    verify_runtime_version()
