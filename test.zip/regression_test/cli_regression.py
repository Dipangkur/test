""" CLI for regression testing """

import logging
import os
import sys
from datetime import datetime
from logging import Logger
from typing import Tuple

import click

from regression_test.regression_utility import (
    create_connection_string,
    extract_params_for_cli,
    get_blob_storage_token,
)
from scenario_calculator.aliases import MainReturnType
from scenario_calculator.config import GeneralConfig
from scenario_calculator.constants import (
    APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME,
    DEFAULT_INPUT_BATCH_SIZE,
    DEFAULT_OUTPUT_BATCH_SIZE,
)
from scenario_calculator.log import config_logger
from scenario_calculator.main_rest_api_mode import _calculate_scenario_task
from scenario_calculator.signals import install_signal_handlers
from swagger_server.models import JobDefinition, JobParams, JobParamsAndJobDefinition

_THIS_MODULE_NAME = __name__


def _validate_logging_level_cb(
    ctx: click.Context, param: click.Option, log_level: str
) -> int:
    """Check the provided logging level and return the numeric equivalent.

    This implementation supports the notion of additional symbolic levelnames,
    as provided by `logging.addLevelName`.

    :param ctx: the click Context (ignored)
    :param param: the parameter name (ignored)
    :param log_level: either a symbolic log level name, or the string representation
      of a number
    :raises click.BadParameter: Wrong parameter for (symbolic) log level
    :return: the logging level
    """
    del ctx, param
    try:
        return int(log_level)
    except ValueError:
        pass
    # It is not numeric; it is symbolic instead.
    try:
        # Create a temporary logger object just to check and convert the symbolic level
        return Logger(
            ".".join((_THIS_MODULE_NAME, "__non_existent__")), level=log_level
        ).level
    except ValueError as value_error:
        raise click.BadParameter(str(value_error))


# noinspection PyTypeChecker
@click.group()
@click.option(
    "--input-batch-size",
    "-i",
    type=int,
    default=DEFAULT_INPUT_BATCH_SIZE,
    help="the number of records to read in one batch",
)
@click.option(
    "--output-batch-size",
    "-o",
    type=int,
    default=DEFAULT_OUTPUT_BATCH_SIZE * 100,
    help="the number of records to write in one batch",
)
@click.option(
    "--event-log-logging-level",
    "-e",
    callback=_validate_logging_level_cb,
    default=str(logging.INFO),
    help="the lowest (symbolic) level for the logs that should be duplicated"
    " in the major event log",
)
@click.pass_context
def cli(
    ctx: click.Context,
    input_batch_size: int,
    output_batch_size: int,
    event_log_logging_level: int,
) -> MainReturnType:
    """Calculate scenario command line handler."""
    # Ensure that ctx.obj exists and is a GeneralConfig instance (in case `cli()`
    # is called by means other than the `if __name__ == "__main__":` block below)
    general_config: GeneralConfig = ctx.ensure_object(GeneralConfig)
    general_config.input_batch_size = input_batch_size
    general_config.output_batch_size = output_batch_size
    general_config.appinsights_instrumentation_key = os.environ.get(
        APPINSIGHTS_INSTRUMENTATIONKEY_ENVNAME, None
    )
    general_config.thread_teeing_logging_handler = config_logger(
        None,
        None,
        general_config.appinsights_instrumentation_key,
        event_log_logging_level,
    )
    install_signal_handlers()


@cli.command("json_mode")
@click.option(
    "--json_file", "-s", type=str, default="cli_config.json",
    help="Location of the cli_config file",
)
@click.pass_context
def json_mode(ctx: click.Context, json_file: str) -> None:
    """Enter json file mode."""
    # TODO: -AB- Assuming because of the difference in the context leads other
    # differences in the mappings which ends up as some differences between the Period
    # column among the ScenarioTimeSeries. Might be related to known "exception swept
    # under the carpet" TODOs, but needs detailed investigation.
        # Get job parameters and run parameters from the input file
    job_params_and_job_definition = JobParamsAndJobDefinition.from_dict(
        extract_params_for_cli(json_file)
    )
    job_params = job_params_and_job_definition.job_params
    job_definition = job_params_and_job_definition.job_definition
    general_config: GeneralConfig = ctx.ensure_object(GeneralConfig)

    current_datetime = datetime.utcnow()
    job_definition.calculation_date = current_datetime
    connection_url = create_connection_string()
    job_params.raw_scenario_sql_connection_url = connection_url
    job_params.scenario_sql_connection_url = connection_url

    blob_storage_token = get_blob_storage_token()

    job_params.blob_storage_account_key = blob_storage_token

    # Manage the arguments and trigger calculation
    task_args: Tuple[JobParams, JobDefinition, GeneralConfig, datetime] = (
        job_params,
        job_definition,
        general_config,
        current_datetime,
    )

    _calculate_scenario_task(*task_args)


if __name__ == "__main__":
    # See http://click.palletsprojects.com/en/7.x/commands\
    #    /#nested-handling-and-contexts
    # fmt: off
    sys.exit(cli(obj=GeneralConfig()))
    # fmt: on
