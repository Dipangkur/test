""" Helper utility for regression testing """
import time
from typing import Dict

import datacompy
import pandas as pd
import yaml
from sqlalchemy import create_engine

from regression_test.constants import (
    DEFAULT_DIFFERENCE_OUTPUT_DIR,
    database,
    driver,
    port,
    server,
)


class RegressionUtility:
    """Helper Class that will be used to keep necessary methods needed for regression
    testing."""

    def __init__(self, url):
        self.engine = create_engine(url)

    def get_difference_between_scenario_ts_on_scenario_ids(
        self,
        scenario_id1: int,
        scenario_id2: int,
        list_join_columns: str,
        report_sample_size: int,
    ) -> str:
        """Find data differences and write the output in data_difference_report.txt.
        :param scenario_id1: first scenario id
        :param scenario_id2: second scenario id
        :param list_join_columns: list of columns to be joined while finding the
        differences
        :param report_sample_size: number of output rows to be reported
        """
        # TODO: Further investigation for the OriginatingRawScenarioId differences
        sql_query = (
            "SELECT "
            "MacroEconomicVariable"
            ", Value"
            ", Unit"
            ", ValueDate"
            ", Type"
            ", StandardizedValue"
            ", Sigma"
            ", Mu"
            ", CorepCode"
            ", NigemCode"
            ", MappedToVariableCode"
            ", MappedToCorepCode"
            ", ToolDataAdjustment"
            " FROM ScenarioTimeSeries where ScenarioId = ?"
        )
        with self.engine.begin() as con:
            df1 = pd.read_sql(sql_query, con, params=[scenario_id1])
            df2 = pd.read_sql(sql_query, con, params=[scenario_id2])

        compare = datacompy.Compare(
            df1,
            df2,
            join_columns=list_join_columns,
            df1_name="ScenarioId" + str(scenario_id1),
            df2_name="ScenarioId" + str(scenario_id2),
        )

        output_file = str(
            DEFAULT_DIFFERENCE_OUTPUT_DIR
            + "_"
            + time.strftime("%Y%m%d-%H%M%S")
            + "_"
            + str(scenario_id1)
            + "_"
            + str(scenario_id2)
            + ".txt",
        )
        with open(output_file, "w",) as f:
            f.write(compare.report(sample_count=report_sample_size))
            f.close()

        return output_file

    def delete_db_records_from_scenario_ts_on_scenario_id_cliuser(
        self, scenario_id: int
    ) -> None:
        """Delete DB records created by CLIUSER for a provided scenario id from
        Scenario and ScenarioTimeSeries tables.
        :param scenario_id: scenario id
        """

        sql_query1 = (
            "DELETE ScenarioTimeSeries FROM ScenarioTimeSeries INNER JOIN "
            "Scenario ON Scenario.Id = ScenarioTimeSeries.ScenarioId "
            "WHERE Scenario.ScenarioCreator = 'CLIUSER' and "
            "ScenarioTimeSeries.ScenarioId = (?)"
        )
        sql_query2 = (
            "DELETE FROM Scenario WHERE Scenario.ScenarioCreator = 'CLIUSER' "
            "and Scenario.Id = (?)"
        )

        with self.engine.connect() as con:
            con.execute(
                sql_query1, (str(scenario_id)),
            )
            con.execute(
                sql_query2, (str(scenario_id)),
            )

    def delete_db_records_from_scenario_ts_all_cliuser(self) -> None:
        """Delete all DB records created by CLIUSER.
        """

        sql_query1 = (
            "DELETE ScenarioTimeSeries FROM ScenarioTimeSeries INNER JOIN "
            "Scenario ON Scenario.Id = ScenarioTimeSeries.ScenarioId "
            "WHERE Scenario.ScenarioCreator = 'CLIUSER' "
        )

        sql_query2 = "DELETE FROM Scenario WHERE Scenario.ScenarioCreator = 'CLIUSER' "

        with self.engine.connect() as con:
            con.execute(sql_query1)
            con.execute(sql_query2)


def extract_params_for_cli(file_path: str) -> Dict[str, str]:
    """ Extract the the yaml / json file given as a dict

    :param file_path: input file path
    :return: a dict with contents of the yaml / json file in the path given
    """
    with open(file_path, "r") as stream:
        try:
            return yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)


def create_connection_string() -> str:
    """Creates and returns the connection string.

        :return: connection string
        """
    print("Hi there! Before proceeding, please provide SQL login details")
    user_name = input("Please enter the DB User name: ")
    password = input("Please enter the password: ")

    connection_str = (
        "mssql+pyodbc://"
        + str(user_name)
        + ":"
        + str(password)
        + "@"
        + server
        + ":"
        + port
        + "/"
        + database
        + "?"
        + "driver="
        + driver
    )
    return connection_str


def get_blob_storage_token() -> str:
    """Gets the blob storage token as input.

    :return: blob storage token
    """
    print("Hi there! Before proceeding, please provide blob storage token")
    return input("Please enter the blob storage token: ")
