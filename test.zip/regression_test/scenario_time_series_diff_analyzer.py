""" Find data differences between two scenario ids """

from regression_test.constants import (
    list_join_columns,
    report_sample_size,
    tool_running,
)
from regression_test.regression_utility import (
    RegressionUtility,
    create_connection_string,
)

# Create connection
connection_url = create_connection_string()

# Initialize the regression utility
regression_utility = RegressionUtility(connection_url)

# Run the tool
while tool_running:
    scenario_id1 = int(input("Please enter First ScenarioId to compare: "))
    scenario_id2 = int(input("Please enter Second ScenarioId to compare: "))

    # fmt: off
    difference_report = \
        regression_utility.get_difference_between_scenario_ts_on_scenario_ids(
            scenario_id1, scenario_id2, list_join_columns, report_sample_size
        )
    # fmt: on

    print("Analysis completed!!! Results are written to " + difference_report)
    res = input("Want to run the anlysis again(Y/N)?:")
    if res not in ["y", "Y"]:
        tool_running = False
        print("Bye bye!!!")
