""" Store constants used for setting up the regression testing tools """

# Tool controlling constants
tool_running = True

# DB Connection details
server = "meisterdevserver.database.windows.net"
port = "1433"
database = "rawscenario"
driver = "ODBC+Driver+17+for+SQL+Server"

# Difference Report Setup
list_join_columns = ["CorepCode", "MacroEconomicVariable", "Unit", "ValueDate"]
report_sample_size = 100000

DEFAULT_DIFFERENCE_OUTPUT_DIR = "./data/output/data_difference_report"
