# -*- coding: utf-8 -*-
"""@author: Jurgen.Tas@Rabobank.com
Unit tests for enrichment.py module
"""
import collections
import unittest

import pandas as pd
import pytest
import datetime

from scenario_calculator.modelling.enrichment import (
    _drop_columns,
    _add_derived_series,
    _get_yearly_sampled_tseries,
    aggregate_series,
    convert_series,
    create_quarterly_subset,
    derive_new_series,
    map_missing_countries_values,
    map_missing_series_values,
    set_standardization_params,
    add_transformed_series,
)

# Globals:
DFLT_IDX = pd.date_range(str(1995), str(2005), freq="Q")
DFLT_VAL = tuple([1.0] * len(DFLT_IDX))


def construct_series_for_testing(
    series_code, unit, corep_code, trans_type, aggr_type, idx=DFLT_IDX, val=DFLT_VAL
):
    """Construct time_series for testing"""
    s = pd.Series(val, index=idx)

    time_series_df = pd.DataFrame()
    time_series_df["id"] = 1
    time_series_df["series"] = s
    time_series_df["originating_raw_scenario_time_series_id"] = 1
    time_series_df["date"] = 0
    time_series_df["corep_code"] = corep_code
    time_series_df["corep_country_code"] = corep_code
    time_series_df["mapped_to_corep_code"] = ""
    time_series_df["mapped_to_variable_code"] = ""
    time_series_df["time_series_code"] = series_code
    time_series_df["nigem_code"] = corep_code
    time_series_df["variable_code"] = series_code[2:]
    time_series_df["start_year_extension"] = 2017
    time_series_df["source"] = ""
    time_series_df["series_code"] = series_code
    time_series_df["period"] = "1996Q1"
    time_series_df["scenario"] = "test_scenario"
    time_series_df["unit"] = unit
    time_series_df["conversion_factor"] = 1
    time_series_df["param_beta0"] = 0
    time_series_df["param_beta1"] = 0
    time_series_df["param_d"] = 0
    time_series_df["param_mu"] = 0
    time_series_df["param_sigma"] = 0
    time_series_df["transformation_type"] = trans_type
    time_series_df["aggregation_type"] = aggr_type
    time_series_df["last_obs_date"] = s.index[-1]
    time_series_df["extension_transformation_type"] = "YOY"
    time_series_df["aggregation_transformation_type"] = "AVG"
    time_series_df["adjustment"] = "derived"

    return time_series_df


def construct_df_for_testing() -> pd.DataFrame:
    """Construct scenario_dict for testing"""
    ts1 = construct_series_for_testing("NLY", "ABS_ACT", "NL", "YOY", "AVG")
    ts2 = construct_series_for_testing("NLPOPWA", "ABS_ACT", "NL", "YOY", "AVG")
    ts3 = construct_series_for_testing("NLPOPT", "ABS_ACT", "NL", "YOY", "AVG")
    ts4 = construct_series_for_testing("NLR3M", "ABS_ACT", "NL", "YOY", "AVG")
    ts5 = construct_series_for_testing("NLCED", "ABS_ACT", "NL", "YOY", "AVG")

    return pd.concat([ts1, ts2, ts3, ts4, ts5])


class TestEnrichment(unittest.TestCase):
    _scenarios = construct_df_for_testing()
    _df_variables = pd.DataFrame.from_dict(
        {
            "variable_code": ["GDPperCAPPOPT", "GDPperCAPPOPWA", "RR3M"],
            "aggregation_transformation_type": ["SUM", "SUM", "AVG"],
        }
    )

    @pytest.fixture(autouse=True)
    def inject_fixture(self, caplog):
        self._caplog = caplog

    def test_derive_series(self):
        """Test derive_series"""
        # TODO [JHB]: this test does not verify aggregation on specific type
        #   PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/860905
        #   ALSO creation of the data should be done in a direct way
        #   instead of Creating the SingleScenario and converting to the DataFrame
        scenarios = derive_new_series(self._df_variables, ["NL"], self._scenarios)
        keys = ["NLGDPperCAPPOPT", "NLGDPperCAPPOPWA", "NLRR3M"]
        for key in keys:
            self.assertIn(key, scenarios["series_code"].unique())

    def test_derive_series_exception(self):
        """Test derive_series exception"""
        with pytest.raises(IndexError):
            derive_new_series(self._df_variables, ["BE"], self._scenarios)

    def test_convert_series(self):
        """Test convert_series"""
        scenarios = convert_series(self._scenarios)
        pd.testing.assert_frame_equal(scenarios, self._scenarios)

    def test_aggregate_series(self):
        """Test aggregate_series"""
        scenarios = aggregate_series(self._scenarios, "A-DEC")
        list_series_code = ["NLY", "NLPOPWA", "NLPOPT", "NLR3M", "NLCED"]

        assert scenarios.unit.unique() == "ABS"
        assert list_series_code.sort() == scenarios.series_code.unique().sort()

    def test_create_quarterly_subset(self):
        """Test create_quarterly_subset"""
        scenarios = create_quarterly_subset(self._scenarios, "A-DEC")
        idx = pd.date_range(str(1995), str(2005), freq="A-DEC")
        val = [1.0] * len(idx)
        s = pd.Series(val, index=idx)
        # assert that expected series is calculated
        pd.testing.assert_series_equal(
            s, scenarios[scenarios.series_code == "NLY"].series, check_names=False
        )

    def test_add_transformed_series(self):
        """Test transform series"""
        df_scenarios = aggregate_series(self._scenarios, "A-DEC")
        df_transformed_scenarios = add_transformed_series(df_scenarios)
        keys = [
            ("NLY", "YOY"),
            ("NLPOPWA", "YOY"),
            ("NLPOPT", "YOY"),
            ("NLR3M", "YOY"),
            ("NLCED", "YOY"),
            ("NLY", "Y-Y"),
            ("NLPOPWA", "Y-Y"),
            ("NLPOPT", "Y-Y"),
            ("NLR3M", "Y-Y"),
            ("NLCED", "Y-Y"),
        ]

        for key in keys:
            self.assertIn(
                key,
                list(df_transformed_scenarios.groupby(["series_code", "unit"]).groups),
            )

    def test_set_standardization_params(self):
        """Test set_standardization_params"""
        data = [["BEY", "ABS_ACT", 1.0, 2.0]]
        cols = ["time_series_code", "unit", "model_param_mu", "model_param_sigma"]
        df = pd.DataFrame(data, columns=cols)
        scenarios = set_standardization_params(self._scenarios, df)
        assert (
            scenarios.loc[
                (scenarios["series_code"] == "BEY") & (scenarios["unit"] == "ABS_ACT"),
                "param_sigma",
            ][0]
            == 2.0
        )
        assert (
            scenarios.loc[
                (scenarios["series_code"] == "BEY") & (scenarios["unit"] == "ABS_ACT"),
                "param_mu",
            ][0]
            == 1.0
        )

    def test_set_standardization_params_checks_non_nan_sigma(self) -> None:
        """Test whether set_standardization_params checks for sigma's being absent"""
        data = [["NLY", "ABS_ACT", 1.0, 2.0], ["BRY", "ABS_ACT", 1.0, None]]
        cols = ["time_series_code", "unit", "model_param_mu", "model_param_sigma"]
        df = pd.DataFrame(data, columns=cols)
        scenarios = set_standardization_params(self._scenarios, df)

        with pytest.raises(AssertionError):
            assert (
                scenarios.loc[
                    (scenarios["series_code"] == "BRY")
                    & (scenarios["unit"] == "ABS_ACT"),
                    "param_sigma",
                ].all()
                == None  # noqa: E711
            )

    def test_map_missing_series(self):
        """"Test map_missing_series"""
        ts1 = construct_series_for_testing("NLY", "ABS_ACT", "NL", "ABS", "AVG")
        ts2 = construct_series_for_testing("NLY", "ABS", "NL", "ABS", "AVG")
        ts3 = construct_series_for_testing("NLY", "Y-Y", "NL", "ABS", "AVG")
        ts4 = construct_series_for_testing("NLY", "YOY", "NL", "ABS", "AVG")

        d = pd.concat([ts1, ts2, ts3, ts4])
        mapping = collections.namedtuple(
            "mapping",
            ["time_series_code", "corep_country_code", "mapped_to_time_series_code"],
        )
        mapping = mapping("BEY", "BE", "NLY")

        scenarios = map_missing_series_values(mapping, d)
        keys = [("BEY", "ABS_ACT"), ("BEY", "ABS"), ("BEY", "YOY"), ("BEY", "Y-Y")]
        for key in keys:
            self.assertIn(
                key, list(scenarios.groupby(["series_code", "unit"]).groups),
            )

    def test_map_missing_countries(self):
        """Test map_missing_countries"""
        corep_code = "BE"
        scenarios = map_missing_countries_values(self._scenarios, corep_code)
        keys = [
            ("BEY", "ABS_ACT"),
            ("BEPOPWA", "ABS_ACT"),
            ("BEPOPT", "ABS_ACT"),
            ("BER3M", "ABS_ACT"),
            ("BECED", "ABS_ACT"),
        ]
        for key in keys:
            self.assertIn(
                key,
                list(
                    scenarios[scenarios["adjustment"] == "mapped - missing country"]
                    .groupby(["series_code", "unit"])
                    .groups
                ),
            )

    def test_get_yearly_sampled_tseries(self):
        """Test _get_yearly_sampled_tseries"""
        expected_dates = [
            datetime.date(1996, 3, 31),
            datetime.date(1997, 3, 31),
            datetime.date(1998, 3, 31),
            datetime.date(1999, 3, 31),
            datetime.date(2000, 3, 31),
            datetime.date(2001, 3, 31),
            datetime.date(2002, 3, 31),
            datetime.date(2003, 3, 31),
            datetime.date(2004, 3, 31),
        ]
        yearly_series = _get_yearly_sampled_tseries(
            self._scenarios[self._scenarios.series_code == "NLY"], "A-MAR"
        )

        assert len(yearly_series.index) == len(expected_dates)
        assert set(yearly_series.index.date) == set(expected_dates)

    def test_add_derived_series(self):
        """ Test _add_derived_series """
        scenarios = _add_derived_series(
            self._df_variables,
            "NL",
            self._scenarios["scenario"].iloc[0],
            self._scenarios,
            "ABS_ACT",
        )
        assert all(scenarios["adjustment"] == "derived")

    def test_drop_columns(self):
        """ Test _drop_columns """
        expected_colm_list = [
            "series",
            "corep_code",
            "variable_code",
            "mapped_to_corep_code",
            "mapped_to_variable_code",
            "param_mu",
            "nigem_code",
            "originating_raw_scenario_time_series_id",
            "param_sigma",
            "adjustment",
            "unit",
            "series_code",
            "scenario",
            "time_series_code",
            "last_obs_date",
        ]

        tested_df = _drop_columns(self._scenarios)

        assert set(tested_df.columns) == set(expected_colm_list)
