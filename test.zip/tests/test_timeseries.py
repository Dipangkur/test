# -*- coding: utf-8 -*-
"""@author: Jurgen.Tas@Rabobank.nl
Unit tests for adjustments.py module
"""
import unittest

import pandas as pd

from scenario_calculator.timeseries import _calculate_arima_step


class TestTimeSeries(unittest.TestCase):
    start = 1961
    end = 2017
    end_year_extension = 2023
    INDEX1 = pd.date_range(str(start), str(end), freq="Q")
    INDEX2 = pd.date_range(str(start), str(end_year_extension + 1), freq="Q")

    val1 = [1] * len(INDEX1)  # init. fixed size array
    val2 = [1] * len(INDEX2)  # init. fixed size array
    SERIES1 = pd.Series(val1, index=INDEX1)
    SERIES2 = pd.Series(val2, index=INDEX2)

    def test_calculate_arima(self):
        """Test arima method for three simple testing cases"""
        # case1:
        self.assertEqual(_calculate_arima_step(0, 0, 1, 0), 0)

        # case2:
        self.assertEqual(_calculate_arima_step(0, 1, 1, 0), 0)

        # case3:
        self.assertEqual(_calculate_arima_step(0, 1, 1, 1), 1)


if __name__ == "__main__":
    unittest.main()
