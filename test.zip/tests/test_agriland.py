# -*- coding: utf-8 -*-
"""@author: Jurgen.Tas@Rabobank.nl
Unit tests for agriland.py module
"""

import numpy as np
import pandas as pd
import pytest

from scenario_calculator.constants import (
    INPUT_DYNAMIC_DF_WITH_MOCK_AGRILAND,
    DATE_FMT,
)
from scenario_calculator.event_logger import IncompleteRawScenarioError
from scenario_calculator.io.agriland_parameters import get_original_agriland_frame
from scenario_calculator.io.base_reader import read_static_data, read_dynamic_data
from scenario_calculator.io.pre_process import get_scenario_name
from scenario_calculator.modelling.agriland import (
    apply_agriland_model,
    transform_to_cumulative_growth,
    split_and_truncate_dynamic_df,
    apply_shock,
    inverse_transform_from_cumulative_growth,
    get_abs_shocked_df,
    add_months,
    is_complete_dynamic_df,
    get_first_and_last_quarters_with_shock_value,
)
from scenario_calculator.settings import Settings
from scenario_calculator.utility import generate_quarter_format
from tests.test_settings import TestSettings


class TestAgriland:
    dynamic_data_url_str = (
        TestSettings.TEST_DYNAMIC_DATA_DIR / INPUT_DYNAMIC_DF_WITH_MOCK_AGRILAND
    ).as_uri()
    dynamic_df = read_dynamic_data(dynamic_data_url_str)
    reporting_date = "20200930"
    scenario_name = get_scenario_name(dynamic_df)
    static_data_dict = read_static_data(
        TestSettings.TEST_STATIC_DATA_DIR, Settings.STANDARD_FILE_MAPPING
    )
    static_data_dict["agriland"] = get_original_agriland_frame(
        static_data_dict["agriland_org"],
        get_scenario_name(dynamic_df),
        generate_quarter_format(reporting_date),
    )

    def test_apply_agriland_model(self, expected_agriland_model_applied_df):
        result = apply_agriland_model(
            self.dynamic_df, self.static_data_dict, self.reporting_date
        )
        pd.testing.assert_frame_equal(
            result[0][["time_series_code", "period", "value"]].reset_index(drop=True),
            expected_agriland_model_applied_df.reset_index(drop=True),
        )

    def test_apply_agriland_model_incomplete_dynamic_df(self):
        """
        Test to check if incomplete dynamic_df raises a ValueError
        """
        with pytest.raises(IncompleteRawScenarioError):
            # drop one value from the dynamic_df to make it "incomplete"
            incomplete_df = self.dynamic_df.drop(
                self.dynamic_df[self.dynamic_df["period"] == "2020Q3"].index
            )
            apply_agriland_model(
                incomplete_df, self.static_data_dict, self.reporting_date
            )

    def test_apply_agriland_model_incomplete_static_df(
        self, complete_dynamic_df: pd.DataFrame
    ):
        """
        Test to check if model does "Nothing" if there is no shock value
        """
        # Call apply agriland model with  empty static agriland DataFrame
        incomplete_static_data = self.static_data_dict
        incomplete_static_data["agriland"] = pd.DataFrame()

        # even with incomplete dynamic_df, shouldn't fail, just should skip the model
        assert apply_agriland_model(
            complete_dynamic_df, incomplete_static_data, self.reporting_date
        )

    def test_transform_to_cumulative_growth(
        self, series_yoy_df: pd.DataFrame, expected_series_yoy_df: pd.DataFrame
    ):
        """ Equality checks for the transform_to_cumulative_growth function's result
        DataFrame """
        pd.testing.assert_frame_equal(
            expected_series_yoy_df, transform_to_cumulative_growth(series_yoy_df)
        )

    def test_apply_shock(
        self,
        expected_series_yoy_df: pd.DataFrame,
        expected_shocked_df: pd.DataFrame,
        filtered_agriland_df: pd.DataFrame,
    ):
        """ Equality checks for the appyly_shock function's result DataFrame """
        pd.testing.assert_frame_equal(
            expected_shocked_df,
            apply_shock(expected_series_yoy_df, filtered_agriland_df),
        )

    def test_inverse_transform_to_cumulative_growth(
        self,
        expected_shocked_df: pd.DataFrame,
        expected_inversed_cumulative_df: pd.DataFrame,
    ):
        """ Equality checks for the inverse_transform_to_cumulative_growth function's result
         DataFrame """
        pd.testing.assert_frame_equal(
            expected_inversed_cumulative_df,
            inverse_transform_from_cumulative_growth(expected_shocked_df),
        )

    def test_get_abs_schocked_df(
        self,
        expected_inversed_cumulative_df: pd.DataFrame,
        expected_abs_shocked_df: pd.DataFrame,
        expected_series_abs: pd.Series,
    ):
        """ Equality checks for the get_abs_schocked_df function's result DataFrame """
        new_series = get_abs_shocked_df(
            expected_inversed_cumulative_df.reset_index(),
            float(expected_series_abs[0:1]["value"]),
        )
        pd.testing.assert_series_equal(
            pd.Series(
                expected_abs_shocked_df["value"].values,
                index=pd.to_datetime(expected_abs_shocked_df["period"]),
            ),
            new_series,
        )

    def test_split_dynamic_df(
        self, dynamic_with_rxeu_df: pd.DataFrame, filtered_agriland_df: pd.DataFrame
    ):
        """ Equality checks for the split DataFrames """
        dynamic_agriland_df, dynamic_df = split_and_truncate_dynamic_df(
            dynamic_with_rxeu_df, filtered_agriland_df
        )
        np.testing.assert_equal(dynamic_agriland_df.shape, (1, 9))
        np.testing.assert_equal(dynamic_df.shape, (4, 9))

    def test_add_months(self):
        """ Equality check of string values after adding months """
        np.testing.assert_equal(
            add_months("20180930", 12), pd.to_datetime("20190930", format=DATE_FMT)
        )

    def test_is_complete_dynamic_df(
        self, complete_dynamic_df: pd.DataFrame, incomplete_dynamic_df: pd.DataFrame
    ):
        """
        Test for the function which checks if dynamic_df is complete or not
        :param complete_dynamic_df: passing dataframe
        :param incomplete_dynamic_df: failing dataframe
        :return:
        """
        assert is_complete_dynamic_df(complete_dynamic_df, "2020Q3")
        assert not is_complete_dynamic_df(incomplete_dynamic_df, "2020Q3")

    def test_get_last_quarters_with_shock_value(
        self,
        missing_static_agriland_df: pd.DataFrame,
        expected_last_quarters_of_shock_df: pd.DataFrame,
    ):
        """
        Test for checking if missing static_agriland_df is mapped correctly for the last
        valid quarters
        :param missing_static_agriland_df:
        :param expected_last_quarters_of_shock_df:
        :return:
        """
        pd.testing.assert_frame_equal(
            expected_last_quarters_of_shock_df,
            get_first_and_last_quarters_with_shock_value(missing_static_agriland_df),
        )
