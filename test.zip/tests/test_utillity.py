# -*- coding: utf-8 -*-
"""@author: Jurgen.Tas@Rabobank.com
Unit tests for utility.py module
"""

import datetime
import logging
import math
import re
import unittest
from typing import Dict

import numpy as np
import pandas as pd
import pytest
from numpy import testing
from pytest import approx

from scenario_calculator.constants import ObservationType
from scenario_calculator.utility import (
    add_columns_to_frame,
    snake_to_upper_camel,
    TicksCounter,
    parse_iso_ish_date,
    parse_iso_ish_datetime,
    nan2none,
    swagger_model_to_repr,
)
from scenario_calculator.utility import clean_list
from scenario_calculator.utility import convert_to_datetime
from scenario_calculator.utility import format_date_for_csv_out
from scenario_calculator.utility import format_float_for_csv_out
from scenario_calculator.utility import generate_date
from scenario_calculator.utility import get_observation_type
from scenario_calculator.utility import generate_quarter_format
from scenario_calculator.utility import get_uniques_from_frame
from scenario_calculator.utility import join_frames
from scenario_calculator.utility import overwrite_number
from scenario_calculator.utility import overwrite_text
from scenario_calculator.utility import standardize
from scenario_calculator.utility import time_context
from swagger_server.models import JobDefinition


class TestAdjustments(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def inject_fixture(self, caplog):
        self._caplog = caplog

    def test_time_context(self):
        """
        Test time_context which is wrapped within contextmanager
        Assert logging message
        """
        # TODO [JHB]: Improved from to MSR.ScenarioCreator.Py project.
        #   Make it an multi-usable module.
        #  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
        with self._caplog.at_level(logging.INFO):
            with time_context("testing"):
                """Just to log the testing"""
                pass

            assert re.match(
                "".join(
                    (
                        r"^.*",
                        re.escape("[testing] finished in real "),
                        r"\d+",
                        re.escape(" / user "),
                        r"\d+",
                        re.escape(" / system "),
                        r"\d+",
                        re.escape(" (ms)"),
                        r"$",
                    )
                ),
                self._caplog.text,
            )

    def test_overwrite_text(self):
        """Test overwrite_text"""
        txt1 = None
        txt2 = "b"
        txt3 = "c"
        res1 = overwrite_text(txt1, txt2, "")
        res2 = overwrite_text(txt2, txt3, "")
        testing.assert_string_equal(res1, txt2)
        testing.assert_string_equal(res2, txt2)

    def test_overwrite_number(self):
        """Test overwrite_number"""
        val1 = None
        val2 = 1.0
        val3 = 2.0
        res1 = overwrite_number(val1, val2, "")
        res2 = overwrite_number(val2, val3, "")
        testing.assert_equal(res1, val2)
        testing.assert_equal(res2, val2)

    def test_standardize(self):
        """Test standardize"""

        data = [
            [1.0, 0.0, 1.0],
            [1.0, 0.0, 0.0],
            [1.0, 0.0, math.nan],
            [1.0, 0.0, None],
            [math.inf, 0.0, 1.0],
            [-math.inf, 0.0, 1.0],
        ]

        tseries = pd.DataFrame(data, columns=["Value", "Mu", "Sigma"])

        standardize(tseries)

        # case 1:
        assert tseries["StandardizedValue"][0] == approx(1.0)
        # case 2:
        assert math.isnan(tseries["StandardizedValue"][1])
        # case 3:
        assert math.isnan(tseries["StandardizedValue"][2])
        assert math.isnan(tseries["StandardizedValue"][3])
        # case 4:
        assert math.isnan(tseries["StandardizedValue"][4])
        assert math.isnan(tseries["StandardizedValue"][5])

    def test_exception(self):
        """Test exceptions"""
        with pytest.raises(KeyError):
            generate_date(2001, "")
        left = pd.DataFrame(dict(key1=["foo", "foo"], lval=[1, 2]))
        right = pd.DataFrame(dict(key2=["foo", "foo"], rval=[4, 5]))
        with pytest.raises(ValueError):
            join_frames(left, right, ["key3"])

    def test_clean_list(self):
        """"Test clean list"""
        lst = [math.nan, "a", 1.0, "b", "c"]
        cleaned_lst = clean_list(lst)
        testing.assert_array_equal(cleaned_lst, ["a", 1.0, "b", "c"])

    def test_get_observation_type(self):
        """"Test get_observation_type"""
        dates = [
            [datetime.datetime(2017, 12, 31), datetime.datetime(2020, 12, 31)],
            [datetime.datetime(2020, 3, 31), datetime.datetime(2020, 12, 31)],
            [datetime.datetime(2020, 12, 31), datetime.datetime(2020, 3, 31)],
        ]

        start_value_date = 20191231
        tseries = pd.DataFrame(dates, columns=["ValueDate", "last_obs_date"])
        get_observation_type(tseries, start_value_date)

        # case 1:
        testing.assert_string_equal(tseries["Type"][0], ObservationType.Historical.name)
        # case 2:
        testing.assert_string_equal(tseries["Type"][1], ObservationType.Scenario.name)
        # case 3:
        testing.assert_string_equal(tseries["Type"][2], ObservationType.Extension.name)

    def test_generate_quarter_format(self):
        """
        Test that generate_quarter_format() generates a string of the format
        YYYYQx from an int of the format YYYYMMDD
        """
        assert generate_quarter_format(20190331) == "2019Q1"
        assert generate_quarter_format(20190630) == "2019Q2"
        assert generate_quarter_format(20190930) == "2019Q3"
        assert generate_quarter_format(20191231) == "2019Q4"

    def test_format_float(self):
        """"Test format_float_for_csv_out"""
        # case 1:
        assert format_float_for_csv_out(1.0) == "1.00000000"
        # case 2:
        assert format_float_for_csv_out(math.inf) == ""

    def test_format_date(self):
        """"Test format_date_for_csv_out"""
        date = datetime.datetime(2017, 12, 31, 19, 53, 42)
        assert format_date_for_csv_out(date) == "2017-12-31"

    def test_convert_to_datetime(self):
        """Test convert to datetime"""
        s1 = pd.Series(["2012Q1", "2012Q2"])
        date1 = datetime.datetime(2012, 3, 31)
        date2 = datetime.datetime(2012, 6, 30)
        s2 = pd.Series([date1, date2])
        s3 = convert_to_datetime(s1)
        pd.testing.assert_series_equal(s2, s3)

    def test_add_columns_to_frame(self):
        """Test add_columns_to_frame"""
        # case 1:
        df1 = pd.DataFrame(dict(period=["2012Q1", "2012Q2"]))
        df2 = add_columns_to_frame(df1)
        date1 = datetime.datetime(2012, 3, 31)
        date2 = datetime.datetime(2012, 6, 30)
        df3 = pd.DataFrame(
            dict(
                period=["2012Q1", "2012Q2"],
                date_index=[date1, date2],
                year=[2012, 2012],
                quarter=[1, 2],
            )
        )
        pd.testing.assert_frame_equal(df2, df3)
        # case 2:
        df4 = pd.DataFrame(dict(test=["2012Q1", "2012Q2"]))
        df5 = add_columns_to_frame(df4)
        pd.testing.assert_frame_equal(df4, df5)

    def test_get_uniques_from_frame(self):
        """Test get_uniques_from_frame"""
        # case 1: unique entry
        df1 = pd.DataFrame(dict(period=["2012Q1", "2012Q1"]))
        val = get_uniques_from_frame(df1, "period")
        testing.assert_equal(val, "2012Q1")
        # case 2: There is more than one unique entry
        with self._caplog.at_level(logging.WARNING):
            df2 = pd.DataFrame(dict(period=["2012Q1", "2012Q2"]))
            get_uniques_from_frame(df2, "period")
            assert "Not a unique entry: period" in self._caplog.text

    def test_join_frames(self):
        """Test join_frames"""
        df1 = pd.DataFrame(dict(period=["2012Q1", "2012Q2"], vals1=[1, 2]))
        df2 = pd.DataFrame(dict(period=["2012Q1", "2012Q2"], vals2=[1, 2]))
        df3 = join_frames(df1, df2, ["period"])
        df4 = pd.DataFrame(
            dict(period=["2012Q1", "2012Q2"], vals1=[1, 2], vals2=[1, 2])
        )
        pd.testing.assert_frame_equal(df3, df4)


def test_snake_to_upper_camel():
    """Test the snake_to_upper_camel conversion routine"""
    assert snake_to_upper_camel("a_b_c") == "ABC"
    assert snake_to_upper_camel("type_") == "Type_"
    assert snake_to_upper_camel("just_some_words") == "JustSomeWords"


def test_ticks_counter():
    ticks_counter = TicksCounter()
    ticks_counter()
    ticks_counter(1, "Foo")
    ticks_counter(3, foo="Foo")
    assert ticks_counter.count == 3

    ticks_counter = TicksCounter()
    ticks_counter.tick_1_arg("some arg")
    assert ticks_counter.count == 1

    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        ticks_counter.tick_1_arg()  # NOSONAR


def test_parse_iso_ish_date_positive():
    year, month, day = 2001, 9, 6
    for fmt in ("{year:d}{month:02d}{day:02d}", "{year:d}-{month:d}-{day:d}"):
        date_str = fmt.format(year=year, month=month, day=day)
        assert parse_iso_ish_date(date_str) == datetime.date(year, month, day)


def test_parse_iso_ish_date_negative():
    with pytest.raises(ValueError):
        parse_iso_ish_date("2001-9-1T00:00:01")


def test_parse_iso_ish_datetime_positive():
    year, month, day = 2001, 9, 6
    for fmt in ("{year:d}{month:02d}{day:02d}", "{year:d}-{month:d}-{day:d}"):
        date_str = fmt.format(year=year, month=month, day=day)
        assert parse_iso_ish_datetime(date_str) == datetime.datetime(year, month, day)
    hours, mins = 1, 2
    for fmt in (
        "{year:d}-{month:d}-{day:d}T{hours:d}:{mins:d}",
        "{year:d}{month:02d}{day:02d}T{hours:02d}{mins:02d}",
    ):
        date_str = fmt.format(year=year, month=month, day=day, hours=hours, mins=mins)
        assert parse_iso_ish_datetime(date_str) == datetime.datetime(
            year, month, day, hours, mins
        )
    secs = 3
    for fmt in (
        "{year:d}-{month:d}-{day:d}T{hours:d}:{mins:d}:{secs:d}",
        "{year:d}{month:02d}{day:02d}T{hours:02d}{mins:02d}{secs:02d}",
    ):
        date_str = fmt.format(
            year=year, month=month, day=day, hours=hours, mins=mins, secs=secs
        )
        assert parse_iso_ish_datetime(date_str) == datetime.datetime(
            year, month, day, hours, mins, secs
        )


def test_parse_iso_ish_datetime_negative():
    with pytest.raises(ValueError):
        parse_iso_ish_datetime("20010906010203")


def test_nan2none() -> None:
    """Check whether `nan2none()` is functioning properly.

    It also checks whether it is working with `pd.Series` `NaN` values.
    """
    series = pd.Series(
        (2.0 ** exp for exp in range(4)),
        (datetime.datetime(year, 1, 1) for year in range(2010, 2014)),
    )
    series.values[2] = np.NaN
    assert pd.isna(series[2])
    assert math.isnan(series[2])
    assert [nan2none(value) for value in series] == [1.0, 2.0, None, 8.0]
    assert nan2none(series[2]) is None


def test_swagger_model_to_repr(static_blob_files_list) -> None:
    """Test if all attributes of a Swagger Model instance are displayed properly."""
    input_kwargs = dict(
        raw_scenario_id=1998,
        event_id=42,
        scenario_name="some_scenario_name",
        scenario_creator="some_scenario_creator",
        meister_version="1.2.3",
        calculation_date=datetime.datetime(1911, 11, 11, 11, 11, 11),
        scenario_description="some_scenario_description",
        is_lab=False,
        static_file_urls=static_blob_files_list,
    )
    job_settings = JobDefinition(**input_kwargs)
    the_repr = swagger_model_to_repr(job_settings)
    # Parse the result, using regular expressions
    full_match = re.match(r"^JobDefinition\((.*)\)$", the_repr)
    assert full_match
    args_repr = full_match[1]
    actual_repr_dict: Dict[str, str] = {}
    for item in re.split(r", (?=\w+=)", args_repr):
        item_match = re.match(r"(?P<key>\w+)=(?P<val_repr>.*)", item)
        key, val_repr = (
            item_match.group(subgroup_name) for subgroup_name in ("key", "val_repr")
        )
        actual_repr_dict[key] = val_repr
    expected_repr_dict = {key: repr(val) for key, val in input_kwargs.items()}
    assert actual_repr_dict == expected_repr_dict
