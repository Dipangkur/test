# -*- coding: utf-8 -*-
"""
The static data received from MES is read into a dictionary of data frames.
this test assert there is no mistakes in the given static data by MES.
"""
import pandas.api.types as ptypes
from scenario_calculator.settings import Settings


class TestStaticData:
    """
    Test that the given static data has the right columns name. Using fixture
    we read the the static data to the test.
    """

    def test_columns_arima(self, static_data_dict):
        """
        Test the reading of static_arima_params.csv columns
        """
        # Instantiating the expected list
        expected_arima_columns = [
            "time_series_code",
            "nigem_country_code",
            "variable_code",
            "corep_country_code",
            "model_param_beta_0",
            "model_param_beta_1",
            "model_param_d",
            "conversion_factor",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert static_data_dict["extension"].columns.tolist() == expected_arima_columns

    def test_columns_standardization(self, static_data_dict):
        """
        Test the reading of static_standardization_params.csv columns
        """
        # Instantiating the expected list
        expected_standardization_columns = [
            "time_series_code",
            "nigem_country_code",
            "variable_code",
            "unit",
            "model_param_mu",
            "model_param_sigma",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["standardization"].columns.tolist()
            == expected_standardization_columns
        )

    def test_columns_macroeconomic(self, static_data_dict):
        """
        Test the reading of static_macroeconomic_variable.csv columns
        """
        expected_macroeconomic_columns = [
            "variable_code",
            "description",
            "variable_type",
            "extension_transformation_type",
            "aggregation_transformation_type",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            expected_macroeconomic_columns
            == static_data_dict["variables"].columns.tolist()
        )

    def test_columns_nbrof_years(self, static_data_dict):
        """
        Test the reading of static_end_year_extension.csv columns
        """
        # Instantiating the expected list
        expected_number_year_columns = ["end_year_extension"]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["nbrof_years_extension"].columns.tolist()
            == expected_number_year_columns
        )

    def test_content_nbrof_years(self, static_data_dict):
        """
        Test the features of static_end_year_extension.csv
        """
        assert (
            static_data_dict["nbrof_years_extension"]["end_year_extension"].count() == 1
        )
        assert ptypes.is_integer_dtype(
            static_data_dict["nbrof_years_extension"]["end_year_extension"]
        )

    def test_columns_series_mapping(self, static_data_dict):
        """
        Test the reading of static_series_mapping.csv columns
        """
        # Instantiating the expected list
        expected_series_mapping_columns = [
            "time_series_code",
            "nigem_country_code",
            "corep_country_code",
            "mapped_to_time_series_code",
            "corep_description",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["missing_series_mapping"].columns.tolist()
            == expected_series_mapping_columns
        )

    def test_columns_countries_mapping(self, static_data_dict):
        """
        Test the reading of static_country_mapping.csv columns
        """
        # Instantiating the expected list
        expected_countries_mapping_columns = [
            "corep_country_code",
            "corep_description",
            "mapped_to_nigem_country_code",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["missing_countries_mapping"].columns.tolist()
            == expected_countries_mapping_columns
        )

    def test_columns_regression(self, static_data_dict):
        """
        Test the reading of static_regression_params.csv columns
        """
        # Instantiating the expected list
        expected_regression_columns = [
            "time_series_code",
            "nigem_code",
            "corep_country_code",
            "unit",
            "lag_coeff",
            "time_series_code1",
            "time_series_code2",
            "time_series_code3",
            "time_series_code4",
            "constant_coeff",
            "coeff1",
            "coeff2",
            "coeff3",
            "coeff4",
            "unit1",
            "unit2",
            "unit3",
            "unit4",
            "lag1",
            "lag2",
            "lag3",
            "lag4",
            "start_year",
            "aggr_type",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["regression_modelling"].columns.tolist()
            == expected_regression_columns
        )

    def test_columns_model_info(self, static_data_dict):
        """
        Test the reading of static_model_info.csv columns
        """
        # Instantiating the expected list
        expected_model_info_columns = ["model_version", "model_name"]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["model_info"].columns.tolist()
            == expected_model_info_columns
        )

    def test_columns_agriland(self, static_data_dict):
        """
        Test the reading of static_agriland_params.csv columns
        """
        # Instantiating the expected list
        expected_agriland_param_columns = [
            "time_series_code",
            "scenario_type",
            "shock_year_1",
            "shock_year_2",
            "shock_year_3",
            "shock_year_4",
            "shock_year_5",
        ]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["agriland_org"].columns.tolist()
            == expected_agriland_param_columns
        )

    def test_scenario_types_agriland(self, static_data_dict):
        """
        In the static_agriland_params.csv scenario_type column's unique set should be a
        subset of pre-defined scenario types
        """
        assert set(static_data_dict["agriland_org"].scenario_type.unique()).issubset(
            set(Settings.SCENARIO_TYPES)
        )

    def test_columns_euro_countries(self, static_data_dict):
        """
        Test the reading of static_euro_countries.csv columns
        """
        # Instantiating the expected list
        expected_euro_countries_columns = ["nigem_country_code"]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["other_country_euro_countries"].columns.tolist()
            == expected_euro_countries_columns
        )

    def test_columns_price_variables(self, static_data_dict):
        """
        Test the reading of static_price_variables.csv columns
        """
        # Instantiating the expected list
        expected_price_variables_columns = ["variable_code"]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["other_country_price_variables"].columns.tolist()
            == expected_price_variables_columns
        )

    def test_columns_start_year(self, static_data_dict):
        """
        Test the reading of static_start_year.csv columns
        """
        # Instantiating the expected list
        expected_static_start_year_columns = ["nigem_country_code", "start_year"]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["other_country_start_year"].columns.tolist()
            == expected_static_start_year_columns
        )

    def test_columns_weights(self, static_data_dict):
        """
        Test the reading of static_weights.csv columns
        """
        # Instantiating the expected list
        expected_static_weights_columns = ["nigem_country_code", "weight"]

        # Asserting that the name of the columns of the static data is the
        # expected
        assert (
            static_data_dict["other_country_weights"].columns.tolist()
            == expected_static_weights_columns
        )
