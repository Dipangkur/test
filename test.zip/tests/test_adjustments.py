# -*- coding: utf-8 -*-
"""@author: Jurgen.Tas@Rabobank.nl
Unit tests for adjustments.py module
"""

import datetime
import math
import logging
import unittest
from typing import Dict

import pandas as pd
from pandas.testing import assert_series_equal
import pytest
from numpy import random, testing, ones, nan, power

from scenario_calculator.modelling.adjustment import calculate_change
from scenario_calculator.modelling.adjustment import calculate_inverse_change
from scenario_calculator.modelling.adjustment import calculate_inverse_relative_change
from scenario_calculator.modelling.adjustment import calculate_ratio
from scenario_calculator.modelling.adjustment import calculate_real_interest_rate
from scenario_calculator.modelling.adjustment import calculate_relative_change
from scenario_calculator.modelling.adjustment import contains_gaps
from scenario_calculator.modelling.adjustment import correct_series
from scenario_calculator.modelling.adjustment import extrapolate_series
from scenario_calculator.modelling.adjustment import inverse_transform
from scenario_calculator.modelling.adjustment import linear_combination
from scenario_calculator.modelling.adjustment import sample_to_quarterly
from scenario_calculator.modelling.adjustment import sample_to_yearly
from scenario_calculator.modelling.adjustment import standardize
from scenario_calculator.modelling.adjustment import subset_per_quarter
from scenario_calculator.modelling.adjustment import transform
from scenario_calculator.modelling.adjustment import value_based_on_aggr_type

# Globals:
DATES = pd.date_range("2017", periods=12, freq="Q")
TIME_SERIES1 = pd.Series(1 * random.randn(12) + 0, index=DATES)
TIME_SERIES2 = pd.Series(1 * random.randn(12) + 0, index=DATES)
TIME_SERIES3 = pd.Series(1 * random.randn(12) + 0, index=DATES)
TIME_SERIES4 = pd.Series(1 * random.randn(12) + 0, index=DATES)
TIME_SERIES_ONES = pd.Series(ones(12), index=DATES)

# These series are created to test the calculate_ratio function in the case of the
# denominator is zero. For instance, when 4 non-zero ABS_ACT values coincidentally
# aggregate to a ABS value of zero
TIME_SERIES_ZERO = pd.Series(0.0, index=DATES)


class TestAdjustments(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def inject_fixture(self, caplog):
        self._caplog = caplog

    def test_return_instance(self):
        """Test if all methods return pandas.Series."""

        tmp1 = calculate_ratio(TIME_SERIES1, TIME_SERIES2)
        tmp2 = calculate_change(TIME_SERIES1)
        tmp3 = calculate_relative_change(TIME_SERIES1)
        tmp4 = calculate_inverse_change(TIME_SERIES1, 0)
        tmp5 = calculate_inverse_relative_change(TIME_SERIES1, 0)
        tmp6 = standardize(TIME_SERIES1, 0, 1)
        tmp7 = calculate_real_interest_rate(TIME_SERIES1, TIME_SERIES2, lag=1)
        tmp8 = transform_for_extension(TIME_SERIES1, "SUM", "YOY", "A-DEC")
        tmp9 = sample_to_yearly(TIME_SERIES1, "SUM")
        tmp10 = sample_to_quarterly(TIME_SERIES1, "YOY")
        tmp11 = transform(TIME_SERIES1, "YOY")
        tmp12 = inverse_transform(TIME_SERIES1, "YOY", 0)
        tmp13 = linear_combination(
            0, 0, TIME_SERIES1, TIME_SERIES2, TIME_SERIES3, TIME_SERIES4
        )
        tmp14 = extrapolate_series(TIME_SERIES1)
        tmp15 = correct_series(TIME_SERIES1, "")
        tmp16 = contains_gaps(TIME_SERIES1)
        tmp17 = subset_per_quarter(TIME_SERIES1, "A-MAR")

        self.assertIsInstance(tmp1, pd.Series)
        self.assertIsInstance(tmp2, pd.Series)
        self.assertIsInstance(tmp3, pd.Series)
        self.assertIsInstance(tmp4, pd.Series)
        self.assertIsInstance(tmp5, pd.Series)
        self.assertIsInstance(tmp6, pd.Series)
        self.assertIsInstance(tmp7, pd.Series)
        self.assertIsInstance(tmp8, pd.Series)
        self.assertIsInstance(tmp9, pd.Series)
        self.assertIsInstance(tmp10, pd.Series)
        self.assertIsInstance(tmp11, pd.Series)
        self.assertIsInstance(tmp12, pd.Series)
        self.assertIsInstance(tmp13, pd.Series)
        self.assertIsInstance(tmp14, pd.Series)
        self.assertIsInstance(tmp15, pd.Series)
        self.assertIsInstance(tmp16, bool)
        self.assertIsInstance(tmp17, pd.Series)

    def test_calculate_ratio(self):
        """testing whether ratios are correctly calculated for simple case 1/2=0.5"""
        result = calculate_ratio(TIME_SERIES1, TIME_SERIES1.mul(2))
        testing.assert_array_equal(result, TIME_SERIES_ONES.mul(0.5))

    def test_calculate_ratio_denom_zero(self):
        """testing whether ratios are correctly calculated.

        This test case is for zero in the denominator series. For instance, when 4
        non-zero ABS_ACT values coincidentally aggregate to a ABS value of zero.
        """
        result = calculate_ratio(TIME_SERIES_ZERO, TIME_SERIES_ZERO.shift(1))
        assert_series_equal(result, TIME_SERIES_ONES[1:])

    def test_standardization_sigma(self):
        """Test standardization calculation for simple case (1);
        i.e. sigma = 2, mu = 0"""
        result = standardize(TIME_SERIES1, 0, 2)
        tmp = TIME_SERIES1.mul(0.5)

        # testing if dates are unchanged:
        testing.assert_array_equal(result.index, tmp.index)
        # testing if values as expected:
        testing.assert_array_equal(result.values, tmp.values)

    def test_standardization_mu(self):
        """Test standardization calculation for simple case (2);
        i.e. sigma = 1, mu = 1."""
        result = standardize(TIME_SERIES1, 1.0, 1)
        tmp = TIME_SERIES1.sub(1.0)

        # testing if dates are unchanged:
        testing.assert_array_equal(result.index, tmp.index)
        # testing if values as expected:
        testing.assert_array_equal(result.values, tmp.values)

    def test_change(self):
        """Test difference (and inverse difference) calculation."""
        start = TIME_SERIES1.iloc[0]
        tmp = calculate_change(TIME_SERIES1)
        result = calculate_inverse_change(tmp, start)

        # testing if dates are unchanged:
        testing.assert_array_equal(TIME_SERIES1.index, result.index)
        # testing if values as expected:
        tmp = TIME_SERIES1.values
        testing.assert_almost_equal(tmp, result.values, decimal=7)

    def test_relative_change(self):
        """Test relative change (and inverse change) calculation for default case."""
        start = TIME_SERIES1.iloc[0]
        tmp = calculate_relative_change(TIME_SERIES1)
        result = calculate_inverse_relative_change(tmp, start)

        # testing if the functions calculate_relative_change and
        # calculate_inverse_relative_change activated successively leaves the series
        # unchanged:
        assert_series_equal(TIME_SERIES1, result)

    def test_relative_change_zeros(self):
        """Test relative change (and inverse) calculation for series containing zeros"""
        start = TIME_SERIES_ZERO.iloc[0]
        tmp = calculate_relative_change(TIME_SERIES_ZERO)
        result = calculate_inverse_relative_change(tmp, start)

        # testing if the functions calculate_relative_change and
        # calculate_inverse_relative_change activated successively leaves the series
        # unchanged for series containing zeros:
        assert_series_equal(TIME_SERIES_ZERO, result)

    def test_calculate_real_interest_rate1(self):
        """Test real interest calculation for simple case (1); i.e. no inflation."""

        # series1 with 0% inflation:
        tmp = pd.Series(1, index=DATES)
        result = calculate_real_interest_rate(TIME_SERIES1, tmp, lag=1)

        # Test expected compare to calculated
        assert_series_equal(TIME_SERIES1[1:], result)

    def test_calculate_real_interest_rate2(self):
        """Test real interest calculation for case (2); rate=0 inflation=10%."""
        inflation = 0.10
        nominal = 0.15
        deflator = [power(1 + inflation, i) for i in range(12)]
        target_real_rate = pd.Series(0.05, index=DATES)
        tmp1 = pd.Series(nominal, index=DATES)
        tmp2 = pd.Series(deflator, index=DATES)
        result = calculate_real_interest_rate(tmp1, tmp2, lag=1)

        # Test expected compare to calculated
        assert_series_equal(target_real_rate[1:], result)

    def test_calculate_real_interest_rate3(self):
        """Test real interest calculation for case (3).

        In this test case the rate=15%, inflation is growing 1% point every year.
        """
        tmp = [i for i in range(12)]

        inflation = pd.Series(tmp, index=DATES)
        deflator = calculate_inverse_relative_change(inflation, start_value=1.0)
        nominal = [15.0] * 12
        target_real_rate_values = [(15.0 - i) for i in range(1, 12)]
        target_real_rate = pd.Series(target_real_rate_values, index=DATES[1:])
        tmp1 = pd.Series(nominal, index=DATES)
        tmp2 = pd.Series(deflator, index=DATES)
        result = calculate_real_interest_rate(tmp1, tmp2, lag=1)

        # Test expected compare to calculated
        assert_series_equal(target_real_rate, result)

    def test_calculate_real_interest_rate4(self):
        """Test real interest calculation for case (4).

         In case an aggregated value of 4-non-zero ABS_ACT inflation data point is equal
         to zero, the division by CED_j-4 will lead to a division by zero, hence it is
         replaced with Epsilon.
         """

        # Random 3 months interest rate was picked:
        result = calculate_real_interest_rate(TIME_SERIES1, TIME_SERIES_ZERO, lag=1)

        assert_series_equal(TIME_SERIES1[1:], result)

    def test_calculate_linear_combination1(self):
        """"Test linear combination function for simple case (1): all series
        with zero values; param1 = 1, param2 = 0"""

        time_series1 = pd.Series(0, index=DATES)
        time_series2 = pd.Series(0, index=DATES)
        time_series3 = pd.Series(0, index=DATES)
        time_series4 = pd.Series(0, index=DATES)
        time_series5 = pd.Series(1, index=DATES)  # expected result
        param1 = 1
        param2 = 0
        result = linear_combination(
            param1, param2, time_series1, time_series2, time_series3, time_series4
        )
        testing.assert_almost_equal(result.values, time_series5.values, decimal=7)

    def test_calculate_linear_combination2(self):
        """"Test linear combination function for simple case (2): all series
        with zero values; param1 = 0, param2 = 1"""

        time_series1 = pd.Series(0, index=DATES)
        time_series2 = pd.Series(0, index=DATES)
        time_series3 = pd.Series(0, index=DATES)
        time_series4 = pd.Series(0, index=DATES)
        time_series5 = pd.Series(0, index=DATES)  # expected result
        param1 = 0
        param2 = 1

        result = linear_combination(
            param1, param2, time_series1, time_series2, time_series3, time_series4
        )
        testing.assert_almost_equal(result.values, time_series5.values, decimal=7)

    def test_calculate_linear_combination3(self):
        """"Test linear combination function for simple case (3): all series
        with 1 values; param1 = 0, param2 =0"""

        time_series1 = pd.Series(1, index=DATES)
        time_series2 = pd.Series(1, index=DATES)
        time_series3 = pd.Series(1, index=DATES)
        time_series4 = pd.Series(1, index=DATES)
        time_series5 = pd.Series(4, index=DATES)  # expected result
        param1 = 0
        param2 = 0

        result = linear_combination(
            param1, param2, time_series1, time_series2, time_series3, time_series4
        )
        testing.assert_almost_equal(result.values, time_series5.values, decimal=7)

    def test_calculate_linear_combination4(self):
        """"Test linear combination function for simple case (4): all series
        with 1 values; param1 = 1, param2 = 0"""

        time_series1 = pd.Series(1, index=DATES)
        time_series2 = pd.Series(1, index=DATES)
        time_series3 = pd.Series(1, index=DATES)
        time_series4 = pd.Series(1, index=DATES)
        time_series5 = pd.Series(5, index=DATES)  # expected result
        param1 = 1
        param2 = 0

        result = linear_combination(
            param1, param2, time_series1, time_series2, time_series3, time_series4
        )
        testing.assert_almost_equal(result.values, time_series5.values, decimal=7)

    def test_calculate_linear_combination5(self):
        """"Test linear combination function for simple case (4): all series
        with 0 values (expect for the first observation); param1 = 0,
        param2 = 1"""

        time_series1 = pd.Series(0, index=DATES)
        time_series2 = pd.Series(0, index=DATES)
        time_series3 = pd.Series(0, index=DATES)
        time_series4 = pd.Series(0, index=DATES)
        time_series5 = pd.Series(4, index=DATES)  # expected result

        # overwrite first observation
        time_series1.iloc[0] = 1
        time_series2.iloc[0] = 1
        time_series3.iloc[0] = 1
        time_series4.iloc[0] = 1

        param1 = 0
        param2 = 1

        result = linear_combination(
            param1, param2, time_series1, time_series2, time_series3, time_series4
        )
        testing.assert_almost_equal(result.values, time_series5.values, decimal=7)

    def test_derivation(self):
        """testing the derivation function for the simple case of a [100, 110,
        120, ...] array"""

        abs_series = pd.Series([100 + 10 * i for i in range(12)], index=DATES)
        dif_series = pd.Series([nan] + [10] * 11, index=DATES)
        yoy_series = pd.Series(10 / abs_series.shift(1), index=DATES)

        dictionary = derivation(abs_series, "ABS")
        testing.assert_almost_equal(dictionary["YOY"].values, yoy_series, decimal=7)
        testing.assert_almost_equal(dictionary["Y-Y"].values, dif_series, decimal=7)

        dictionary = derivation(yoy_series, "YOY")
        testing.assert_almost_equal(dictionary["ABS"].values, abs_series, decimal=7)
        testing.assert_almost_equal(dictionary["Y-Y"].values, dif_series, decimal=7)

        dictionary = derivation(dif_series, "Y-Y")
        testing.assert_almost_equal(dictionary["YOY"].values, yoy_series, decimal=7)
        testing.assert_almost_equal(dictionary["ABS"].values, abs_series, decimal=7)

    def test_exceptions(self):
        """Test exception handling."""
        keys = pd.to_datetime(["2017-12-31", "2018-03-31", "2017-09-30"])
        values = [2, 3, 1]
        series = pd.Series(values, index=keys)
        with pytest.raises(KeyError):
            subset_per_quarter(TIME_SERIES1, "")
        with pytest.raises(ValueError):
            linear_combination(0, 0, TIME_SERIES1, TIME_SERIES2, TIME_SERIES3, series),

    def test_correct_series1(self):
        """Test correct_series."""
        date1 = datetime.datetime(2012, 3, 31)
        date2 = datetime.datetime(2012, 9, 30)
        s = pd.Series([0, 0], index=[date1, date2])
        with self._caplog.at_level(logging.WARNING):
            correct_series(s, "")
            assert "Series contained gaps " in self._caplog.text
            assert "Series not ending at Q4 " in self._caplog.text

    def test_correct_series2(self):
        """Test correct_series."""
        idx = pd.date_range(str(1995), str(2005), freq="A-MAR")
        val = [1.0] * len(idx)
        s1 = pd.Series(val, index=idx)
        # result:
        s2 = correct_series(s1, "")
        idx = pd.date_range(str(1995), str(2005), freq="Q")
        # expected result:
        val = [1.0] * len(idx)
        s3 = pd.Series(val, index=idx)
        # test:
        pd.testing.assert_series_equal(s2, s3)

    def test_correct_series3(self):
        """Test correct_series."""
        idx = pd.date_range(str(1995), str(2005), freq="Q")
        val = [1.0] * len(idx)
        s1 = pd.Series(val, index=idx)
        # result:
        s2 = correct_series(s1, "")
        # test:
        pd.testing.assert_series_equal(s1, s2)

    def test_transform_for_extension(self):
        """Test transform() for extension for series that starts from 2nd quarter."""
        idx = pd.date_range(str(1995), str(2005), freq="Q")
        val = [1.0] * 40
        s1 = pd.Series(val, index=idx)
        s2 = s1.iloc[1:]  # remove first quarter from data
        # result:
        s3 = transform_for_extension(s2, "AVG", "YOY", "A-DEC")
        # expected result:
        idx = pd.date_range(str(1996), str(2005), freq="A-DEC")
        val = [0.0] * 9
        s4 = pd.Series(val, index=idx)
        s4.iloc[0] = math.nan
        # test:
        pd.testing.assert_series_equal(s3, s4)

    def test_transform_for_extension_zeros(self):
        """Test transform() for extension.

        This specific case is for 4 non-zero ABS_ACT values coincidentally sum-up to a
        ABS value of zero.
        """
        idx = pd.date_range(str(1995), str(1997), freq="Q")
        val = [1, 0.5, -1, -0.5, 1, 0.5, -1, -0.5]
        s1 = pd.Series(val, index=idx)
        # result:
        s2 = transform_for_extension(s1, "AVG", "YOY", "A-DEC")
        # expected result:
        idx = pd.date_range(str(1995), str(1997), freq="A-DEC")
        val = [0.0] * 2
        s3 = pd.Series(val, index=idx)
        s3.iloc[0] = math.nan
        # test:
        pd.testing.assert_series_equal(s2, s3)

    def test_sample_to_yearly(self):
        """Test sample of yearly function."""
        idx = pd.date_range(str(1995), str(2005), freq="Q")
        val = [1.0] * len(idx)
        s1 = pd.Series(val, index=idx)
        # result:
        s2 = sample_to_yearly(s1, "SUM", freq="A-MAR")
        idx = pd.date_range(str(1996), str(2005), freq="A-MAR")
        # expected result:
        val = [4.0] * len(idx)
        s3 = pd.Series(val, index=idx)
        # test:
        pd.testing.assert_series_equal(s2, s3)

    def test_value_based_on_aggr_type(self):
        """Test value_based_on_aggr_type."""
        # case 1:
        val1 = 1.0
        val2 = 2.0
        self.assertEqual(value_based_on_aggr_type(val1, val2, "SUM"), -1.0)
        # case 2:
        self.assertEqual(value_based_on_aggr_type(val1, val2), 2.0)


def transform_for_extension(
    series: pd.Series, aggr_type: str, trans_type: str, freq: str
) -> pd.Series:
    """Transforms time series to a suitable form for applying extension.

    This function is used in order to test the transform() function for the calculator
    module in stage [2] Extending TimeSeries. Note, transform() is also used in stage
    [8].

    :param series: original timeseries
    :param aggr_type: {"SUM", "AVG"}
    :param trans_type: {"YOY", "Y-Y"}
    :param freq: frequency strings {"A-MAR", "A-JUN", "A-SEP", "A-DEC"}
    :return: transformed series
    """
    year = series.index[0].year
    if series.index[0].quarter != 1:
        year += 1
    tmp = series[series.index.year >= year]
    result = sample_to_yearly(tmp, aggr_type, freq)
    result = transform(result, trans_type)
    return result


def derivation(
    series: pd.Series, unit_type: str, start: int = 100
) -> Dict[str, pd.Series]:
    """Creates a dict. containing the original timeseries in units ABS, YOY and Y-Y.

    If the original series is in YOY or Y-Y units, the index of
    ABS is normalized by default to 100 on the first year of the series.

    :param series: original timeseries
    :param unit_type: {"YOY", "Y-Y", "ABS"}
    :param start: start value of the series
    :return: dictionary containing original timeseries in units ABS, YOY and Y-Y
    """
    result = {}
    if unit_type != "ABS":
        # Make ABS series:
        series1 = inverse_transform(series, unit_type, start)
        type_ = "Y-Y" if unit_type == "YOY" else "YOY"
        result["ABS"] = series1
        result[type_] = transform(series1, type_)
    else:
        result["YOY"] = transform(series, "YOY")
        result["Y-Y"] = transform(series, "Y-Y")
    return result


if __name__ == "__main__":
    unittest.main()
