# -*- coding: utf-8 -*-
"""
Pandas DataFrame equivalents of the tests in test_timeseries.py module
"""
import unittest

import numpy as np
import pandas as pd

from scenario_calculator.processing import (
    Attributes,
    _overwrite_attributes,
    extend_series,
    get_output_date,
)
from scenario_calculator.timeseries import _calculate_arima_step


def _create_time_series_dataframe(
    series: pd.Series,
    param_beta0,
    param_beta1,
    param_d,
    transformation_type,
    aggregation_type,
):
    """"
    Create DataFrame with default test values
    """
    import datetime

    time_series_df = pd.DataFrame()
    time_series_df["id"] = 1
    time_series_df["series"] = series
    time_series_df["originating_raw_scenario_time_series_id"] = 1
    time_series_df["date"] = 20170420
    time_series_df["corep_code"] = ""
    time_series_df["corep_country_code"] = ""
    time_series_df["mapped_to_corep_code"] = ""
    time_series_df["mapped_to_variable_code"] = ""
    time_series_df["time_series_code"] = "NLAGR"
    time_series_df["nigem_code"] = "NL"
    time_series_df["variable_code"] = ""
    time_series_df["start_year_extension"] = 2017
    time_series_df["source"] = ""
    time_series_df["series_code"] = "AUY"
    time_series_df["period"] = "1996Q1"
    time_series_df["scenario"] = ""
    time_series_df["unit"] = "ABS"
    time_series_df["conversion_factor"] = 1
    time_series_df["model_param_beta_0"] = param_beta0
    time_series_df["model_param_beta_1"] = param_beta1
    time_series_df["model_param_d"] = param_d
    time_series_df["param_mu"] = 0
    time_series_df["param_sigma"] = 0
    time_series_df["transformation_type"] = transformation_type
    time_series_df["aggregation_type"] = aggregation_type
    date = datetime.date(2012, 12, 31)
    time_series_df["last_obs_date"] = date
    time_series_df["extension_transformation_type"] = transformation_type
    time_series_df["aggregation_transformation_type"] = aggregation_type

    return time_series_df


class TestDataFrameTimeSeries(unittest.TestCase):
    start = 1961
    end = 2017
    end_year_extension = 2023
    INDEX1 = pd.date_range(str(start), str(end), freq="Q")
    INDEX2 = pd.date_range(str(start), str(end_year_extension + 1), freq="Q")

    val1 = [1] * len(INDEX1)  # init. fixed size array
    val2 = [1] * len(INDEX2)  # init. fixed size array
    SERIES1 = pd.Series(val1, index=INDEX1)
    SERIES2 = pd.Series(val2, index=INDEX2)

    def test_extend_series1(self):
        """Test if method returns correct values for beta0 = 0 and beta1 = 0,
        and d = 0 for ("YOY", "AVG") combination.
        """

        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "YOY", "AVG"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        np.testing.assert_array_equal(series.values, self.SERIES2.values)

    def test_extend_series2(self):
        """Test if method returns correct values for beta0 = 0 and beta1 = 0,
        and d = 0 for ("YOY", "SUM") combination.
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "YOY", "SUM"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        np.testing.assert_array_equal(series.values, self.SERIES2.values)

    def test_extend_series3(self):
        """Test if method returns correct values for beta0 = 0 and beta1 = 0,
        and d = 0 for ("Y-Y", "AVG") combination.
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "Y-Y", "AVG"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        np.testing.assert_array_equal(series.values, self.SERIES2.values)

    def test_extend_series4(self):
        """Test if method returns correct values for beta0 = 0 and beta1 = 0,
        and d = 0 for ("Y-Y", "SUM") combination.
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "Y-Y", "SUM"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        np.testing.assert_array_equal(series.values, self.SERIES2.values)

    def test_extend_series5(self):
        """Test if method returns correct values for beta0 = 3 and beta1 = 0,
        and d = 0 for ("ABS", "SUM") combination.
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 3, 0, 0, "ABS", "SUM"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        in_extension = len(self.INDEX1)
        np.testing.assert_array_equal(
            series.values[in_extension:], 0.75 * self.SERIES2.values[in_extension:],
        )

    def test_extend_series6(self):
        """Test if method returns correct values for beta0 = 3 and beta1 = 0,
        and d = 0 for ("ABS", "AVG") combination.
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 3, 0, 0, "ABS", "AVG"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        in_extension = len(self.INDEX1)
        np.testing.assert_array_equal(
            series.values[in_extension:], 3 * self.SERIES2.values[in_extension:],
        )

    def test_extend_series7(self):
        """Test if method returns correct values for beta0 = 3 and beta1 = 1,
        and d = 0 for ("ABS", "AVG") combination. This is per se stationary
        starting from the last point. (=1)
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 3, 1, 0, "ABS", "AVG"
        )
        attrs = Attributes(time_series_df)
        attrs = _overwrite_attributes(attrs, attrs["time_series_code"])

        series, last_obs_date, start_year_extension, aggr_type = extend_series(
            time_series_df.series, attrs, self.end_year_extension
        )
        np.testing.assert_array_equal(series.index, self.SERIES2.index)
        in_extension = len(self.INDEX1)
        np.testing.assert_array_equal(
            series.values[in_extension:], self.SERIES2.values[in_extension:],
        )

    def test_calculate_arima(self):
        """Test arima method for three simple testing cases"""
        # case1:
        self.assertEqual(_calculate_arima_step(0, 0, 1, 0), 0)

        # case2:
        self.assertEqual(_calculate_arima_step(0, 1, 1, 0), 0)

        # case3:
        self.assertEqual(_calculate_arima_step(0, 1, 1, 1), 1)

    def test_date_format(self):
        """
        testing whether method returns compliant date format
        """
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "Y-Y", "SUM"
        )
        self.assertEqual(get_output_date(time_series_df.date.iloc[0]), "2017-04-20")

    def test_length(self):
        """Test length method."""
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "Y-Y", "SUM"
        )
        self.assertEqual(len(time_series_df), len(self.SERIES1))

    def test_magic_methods(self):
        """Test magic methods."""
        time_series_df = _create_time_series_dataframe(
            self.SERIES1, 0, 0, 0, "Y-Y", "SUM"
        )
        date = time_series_df["series"][-1]
        # case1:
        self.assertEqual(date, self.SERIES1[-1])
        # case2:
        time_series_df["date"] = 2.0
        self.assertEqual(time_series_df.date.iloc[0], 2.0)


if __name__ == "__main__":
    unittest.main()
