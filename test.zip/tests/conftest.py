# -*- coding: utf-8 -*-
"""Sharing PyTest fixtures between tests.

See https://docs.pytest.org/en/latest/fixture.html\
  #conftest-py-sharing-fixture-functions
"""
from datetime import datetime

import numpy as np
import pandas as pd
import pytest

from scenario_calculator.config import RunDefinition
from scenario_calculator.constants import INPUT_TEMPLATE_DYNAMIC_DF
from scenario_calculator.io.base_reader import read_dynamic_data, read_static_data
from scenario_calculator.io.pre_process import (
    get_reporting_date,
    get_scenario_end_date,
)
from scenario_calculator.settings import Settings
from tests.test_settings import TestSettings


base_line = "201809 Baseline"
plus_name = "201806 Plus"


@pytest.fixture()
def mock_db(mocker):
    """
    TODO [JHB]: Cloned from MSR.ScenarioCreator.Py project.
     PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
    """

    def _mock_db():
        mocker.patch(
            "scenario_calculator" + ".sql_alch_create_engine_args" + ".create_engine",
            autospec=True,
        )
        mocker.patch("scenario_calculator.db.sessionmaker", autospec=True)
        mocker.patch("scenario_calculator.db.automap_base", autospec=True)

    return _mock_db


@pytest.fixture
def m_scenario_df():
    dynamic_data_url_str = (
        TestSettings.TEST_DYNAMIC_DATA_DIR / INPUT_TEMPLATE_DYNAMIC_DF
    ).as_uri()
    return read_dynamic_data(dynamic_data_url_str)


@pytest.fixture
def static_data_dict():
    return read_static_data(Settings.STATIC_DATA_DIR, Settings.STANDARD_FILE_MAPPING)


@pytest.fixture
def static_test_data_dict():
    return read_static_data(
        TestSettings.TEST_STATIC_DATA_DIR, Settings.STANDARD_FILE_MAPPING
    )


@pytest.fixture
def static_test_data_oc_agriland():
    return read_static_data(
        TestSettings.TEST_STATIC_DATA_DIR, TestSettings.TEST_FILE_MAPPING
    )


@pytest.fixture
def extension_without_agriland_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1, 2, 3]),
            "date": np.array([20180930, 20180930, 20180930]),
            "source": np.array(["FAR", "RaboResearch", "FAR"]),
            "scenario": np.repeat(base_line, repeats=3),
            "time_series_code": np.array(["AUAGR", "AUC", "OTAGR"]),
            "period": np.array(["1996Q1", "1961Q1", "1996Q1"]),
            "value": np.array([1.0, 34.399, 1.0]).astype("float64"),
            "type": np.array(["Historical", "history", "Historical"]),
            "unit": np.array(["ABS_ACT", "ABS_ACT", "ABS_ACT"]),
            "date_index": np.array(["1996-03-31", "1961-03-31", "1996-03-31"]),
            "year": np.array([1996, 1961, 1996]),
            "quarter": np.array([1, 1, 1]),
            "nigem_country_code": np.array(["AU", "AU", np.nan]),
            "variable_code": np.array(["AGR", "C", np.nan]),
            "corep_country_code": np.array(["AU", "AU", np.nan]),
            "model_param_beta_0": np.array([0.064826143, 0.033931526000000004, np.nan]),
            "model_param_beta_1": np.array([0.5813437029999999, 0.0, np.nan]),
            "model_param_d": np.array([0, 0, np.nan]),
            "conversion_factor": np.array([1, 1, np.nan]),
            "variable_type": np.array(["modelled", "nigem", np.nan]),
            "extension_transformation_type": np.array(["YOY", "YOY", np.nan]),
            "aggregation_transformation_type": np.array(["AVG", "SUM", np.nan]),
        }
    )


@pytest.fixture
def end_date_test(m_scenario_df, static_test_data_dict):
    return get_scenario_end_date(
        get_reporting_date(m_scenario_df),
        static_test_data_dict["nbrof_years_extension"],
    )


@pytest.fixture
def some_batch_size():
    return 0


@pytest.fixture
def some_run_definition(static_blob_files_list):
    return RunDefinition(
        31415,
        100,
        "201212 Plus",
        "RABONETEU\\UnitT",
        "14.0.5-beta.1",
        datetime(2013, 9, 30, 13, 53, 5, 608),
        "Scenario for Unit Test",
        datetime.utcnow(),
        False,
        static_blob_files_list,
    )


@pytest.fixture
def expected_weights_df():
    return pd.DataFrame.from_dict(
        {
            "nigem_country_code": np.array(
                [
                    "AU",
                    "BG",
                    "BR",
                    "CH",
                    "CL",
                    "CN",
                    "FR",
                    "GE",
                    "ID",
                    "IN",
                    "IT",
                    "JP",
                    "MX",
                    "NL",
                    "NZ",
                    "SP",
                    "UK",
                    "US",
                ]
            ),
            "weight": np.array(
                [
                    0.024,
                    0.009,
                    0.028,
                    0.195,
                    0.004,
                    0.028,
                    0.048,
                    0.062,
                    0.013,
                    0.036,
                    0.034,
                    0.085,
                    0.017,
                    0.015,
                    0.003,
                    0.024,
                    0.048,
                    0.327,
                ]
            ),
        }
    )


@pytest.fixture
def expected_start_year_df():
    return pd.DataFrame.from_dict(
        {
            "nigem_country_code": np.array(
                [
                    "AU",
                    "BG",
                    "BR",
                    "CH",
                    "CL",
                    "CN",
                    "FR",
                    "GE",
                    "ID",
                    "IN",
                    "IT",
                    "JP",
                    "MX",
                    "NL",
                    "NZ",
                    "SP",
                    "UK",
                    "US",
                ]
            ),
            "start_year": np.array(
                [
                    1993,
                    1987,
                    2000,
                    2000,
                    2009,
                    1994,
                    1987,
                    1994,
                    2000,
                    2000,
                    1987,
                    1991,
                    1995,
                    1987,
                    1993,
                    1995,
                    2002,
                    1994,
                ]
            ).astype("int64"),
        }
    )


@pytest.fixture
def dynamic_with_elrx_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1, 2, 3, 4]).astype("int64"),
            "date": np.array([20180930, 20180930, 20180930, 20180930]).astype("int64"),
            "source": np.array(["FAR", "RaboResearch", "FAR", "FAR"]),
            "scenario": np.repeat(base_line, repeats=4),
            "time_series_code": np.array(["ELRX", "IDRX", "ELRX", "IDRX"]),
            "period": np.array(["1996Q1", "1996Q1", "1970Q1", "1970Q1"]),
            "value": np.array([0.2, 4, 4, 3]).astype("float64"),
            "type": np.array(["Historical", "history", "Historical", "Historical"]),
            "unit": np.array(["ABS_ACT", "ABS_ACT", "ABS_ACT", "ABS_ACT"]),
        }
    )


@pytest.fixture
def expected_dynamic_without_elrx_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1, 2, 3, 4]).astype("int64"),
            "date": np.array([20180930, 20180930, 20180930, 20180930]).astype("int64"),
            "source": np.array(["FAR", "RaboResearch", "FAR", "FAR"]),
            "scenario": np.repeat(base_line, repeats=4),
            "time_series_code": np.array(["USRXEU", "IDRXEU", "USRXEU", "IDRXEU"]),
            "period": np.array(["1996Q1", "1996Q1", "1970Q1", "1970Q1"]),
            "value": np.array([0.2, 0.05, 4, 4 / 3]).astype("float64"),
            "type": np.array(["Historical", "history", "Historical", "Historical"]),
            "unit": np.array(["ABS_ACT", "ABS_ACT", "ABS_ACT", "ABS_ACT"]),
        }
    )


@pytest.fixture
def dynamic_with_rxeu_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1, 2, 3, 4]).astype("int64"),
            "date": np.array([20180930, 20180930, 20180930, 20180930]).astype("int64"),
            "source": np.array(["FAR", "RaboResearch", "FAR", "FAR"]),
            "scenario": np.repeat(base_line, repeats=4),
            "time_series_code": np.array(["AUAGR", "AURXEU", "AUC", "AURXEU"]),
            "period": np.array(["1996Q1", "1996Q1", "1970Q1", "1970Q1"]),
            "value": np.array([1.0, 34.399, 2.5, 4]).astype("float64"),
            "type": np.array(["Historical", "history", "Historical", "Historical"]),
            "unit": np.array(["ABS_ACT", "ABS_ACT", "ABS_ACT", "ABS_ACT"]),
        }
    )


@pytest.fixture
def expected_truncated_dynamic_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1, 2]).astype("int64"),
            "date": np.array([20180930, 20180930]).astype("int64"),
            "source": np.array(["FAR", "RaboResearch"]),
            "scenario": np.repeat(base_line, repeats=2),
            "time_series_code": np.array(["AUAGR", "AURXEU"]),
            "period": np.array(["1996Q1", "1996Q1"]),
            "value": np.array([1.0, 34.399]).astype("float64"),
            "type": np.array(["Historical", "history"]),
            "unit": np.array(["ABS_ACT", "ABS_ACT"]),
        }
    )


@pytest.fixture
def expected_conversion_applied_dynamic_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1]).astype("int64"),
            "date": np.array([20180930]).astype("int64"),
            "source": np.array(["FAR"]),
            "scenario": np.array([base_line]),
            "time_series_code": np.array(["AUAGR"]),
            "period": np.array(["1996Q1"]),
            "value": np.array([1.0]).astype("float64"),
            "type": np.array(["Historical"]),
            "unit": np.array(["ABS_ACT"]),
        }
    )


@pytest.fixture
def expected_euro_converted_dynamic_df():
    return pd.DataFrame.from_dict(
        {
            "id": np.array([1, 2, 3, 4]).astype("int64"),
            "date": np.array([20180930, 20180930, 20180930, 20180930]).astype("int64"),
            "source": np.array(["FAR", "RaboResearch", "FAR", "FAR"]),
            "scenario": np.repeat(base_line, repeats=4),
            "time_series_code": np.array(["AUAGR", "AURXEU", "AUC", "AURXEU"]),
            "period": np.array(["1996Q1", "1996Q1", "1970Q1", "1970Q1"]),
            "value": np.array([1.0, 34.399, 10, 4]).astype("float64"),
            "type": np.array(["Historical", "history", "Historical", "Historical"]),
            "unit": np.array(["ABS_ACT", "ABS_ACT", "ABS_ACT", "ABS_ACT"]),
        }
    )


@pytest.fixture
def static_blob_files_list():
    base_directory = "https://meisterdevstorage.blob.core.windows.net/static-files/lab/"
    return [
        base_directory + "static_end_year_extension20200123154206637.csv",
        base_directory + "static_country_mapping20200124100528637.csv",
        base_directory + "static_euro_countries20200123154206644.csv",
    ]


@pytest.fixture
def expected_merged_mapping():
    base_directory = "https://meisterdevstorage.blob.core.windows.net/static-files/lab/"
    return pd.DataFrame(
        [
            ["agriland_org", "static_agriland_params.csv", 0],
            ["extension", "static_arima_params.csv", 0],
            [
                "missing_countries_mapping",
                base_directory + "static_country_mapping20200124100528637.csv",
                1,
            ],
            ["missing_series_mapping", "static_series_mapping.csv", 0],
            ["model_info", "static_model_info.csv", 0],
            [
                "nbrof_years_extension",
                base_directory + "static_end_year_extension20200123154206637.csv",
                1,
            ],
            [
                "other_country_euro_countries",
                base_directory + "static_euro_countries20200123154206644.csv",
                1,
            ],
            ["other_country_price_variables", "static_price_variables.csv", 0],
            ["other_country_start_year", "static_start_year.csv", 0],
            ["other_country_weights", "static_weights.csv", 0],
            ["regression_modelling", "static_regression_params.csv", 0],
            ["standardization", "static_standardization_params.csv", 0],
            ["variables", "static_macroeconomic_variable.csv", 0],
        ],
        columns=["df_name", "file_name", "is_blob"],
    )


@pytest.fixture
def base_agriland_without_value_df():
    return pd.DataFrame.from_dict(
        {
            "time_series_code": np.array(["AUAGR", "AUAGR", "AUAGR", "AUAGR", "AUAGR"]),
            "period": np.array(
                ["20210930", "20220930", "20230930", "20240930", "20250930"]
            ),
        }
    )


@pytest.fixture
def series_yoy_df(base_agriland_without_value_df):
    to_append_df = pd.DataFrame.from_dict(
        {"value": np.array([0.03, 0.04, 0.03, 0.01, 0.005]).astype("float64"),}  # noqa
    )

    return pd.concat([base_agriland_without_value_df, to_append_df], axis=1, sort=False)


@pytest.fixture
def expected_series_abs(base_agriland_without_value_df):
    to_append_df = pd.DataFrame.from_dict(
        {
            "value": np.array([100, 103, 107.12, 111.436936, 111.9941207]).astype(
                "float64"
            ),
        }
    )

    return pd.concat([base_agriland_without_value_df, to_append_df], axis=1, sort=False)


@pytest.fixture
def expected_series_yoy_df(base_agriland_without_value_df):
    to_append_df = pd.DataFrame.from_dict(
        {
            "value": np.array([0.03, 0.0712, 0.103336, 0.11436936, 0.119941207]).astype(
                "float64"
            ),
        }
    )

    return pd.concat([base_agriland_without_value_df, to_append_df], axis=1, sort=False)


@pytest.fixture
def expected_shocked_df(base_agriland_without_value_df):
    to_append_df = pd.DataFrame.from_dict(
        {
            "value": np.array([0.08, 0.1212, 0.153336, 0.13436936, 0.129941207]).astype(
                "float64"
            ),
        }
    )

    return pd.concat([base_agriland_without_value_df, to_append_df], axis=1, sort=False)


@pytest.fixture
def expected_inversed_cumulative_df(base_agriland_without_value_df):
    to_append_df = pd.DataFrame.from_dict(
        {
            "value": np.array(
                [0.08, 0.038148148, 0.028662148, -0.016445026, -0.003903626]
            ).astype("float64"),
        }
    )

    return pd.concat([base_agriland_without_value_df, to_append_df], axis=1, sort=False)


@pytest.fixture
def expected_abs_shocked_df(base_agriland_without_value_df):
    to_append_df = pd.DataFrame.from_dict(
        {
            "value": np.array([108, 112.12, 115.3336, 113.436936, 112.9941207]).astype(
                "float64"
            ),
        }
    )

    return pd.concat([base_agriland_without_value_df, to_append_df], axis=1, sort=False)


@pytest.fixture
def expected_agriland_model_applied_df():
    return pd.DataFrame.from_dict(
        {
            "time_series_code": np.array(
                [
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                    "AUAGR",
                ]
            ),
            "period": np.array(
                [
                    "2020Q4",
                    "2021Q1",
                    "2021Q2",
                    "2021Q3",
                    "2021Q4",
                    "2022Q1",
                    "2022Q2",
                    "2022Q3",
                    "2022Q4",
                    "2023Q1",
                    "2023Q2",
                    "2023Q3",
                    "2023Q4",
                    "2024Q1",
                    "2024Q2",
                    "2024Q3",
                    "2024Q4",
                    "2025Q1",
                    "2025Q2",
                    "2025Q3",
                ]
            ),
            "value": np.array(
                [
                    108,
                    108,
                    108,
                    108,
                    112.12,
                    112.12,
                    112.12,
                    112.12,
                    115.3336,
                    115.3336,
                    115.3336,
                    115.3336,
                    113.436936,
                    113.436936,
                    113.436936,
                    113.436936,
                    112.9941207,
                    112.9941207,
                    112.9941207,
                    112.9941207,
                ]
            ).astype("float64"),
        }
    )


@pytest.fixture
def filtered_agriland_df():
    return pd.DataFrame.from_dict(
        {
            "time_series_code": np.array(["AUAGR", "NLAGR"]),
            "scenario_type": np.array(["Plus", "Plus"]),
            "2021Q3": np.array([0.05, 0.119941207]).astype("float64"),
            "2022Q3": np.array([0.05, 0.119941207]).astype("float64"),
            "2023Q3": np.array([0.05, 0.119941207]).astype("float64"),
            "2024Q3": np.array([0.02, 0.119941207]).astype("float64"),
            "2025Q3": np.array([0.01, 0.119941207]).astype("float64"),
        }
    )


@pytest.fixture
def expected_filtered_static_agriland_df():
    return pd.DataFrame(
        [
            ["NLAGR", plus_name, 0.03746, 0.07633, 0.11665, 0.13310, 0.14238],
            ["USAGR", plus_name, 0.03762, 0.07665, 0.11715, 0.14243, 0.15968],
            ["BRAGR", plus_name, 0.03748, 0.07637, 0.11671, 0.13359, 0.14408],
            ["AUAGR", plus_name, 0.03849, 0.07756, 0.11810, 0.13313, 0.14129],
            ["NZAGR", plus_name, 0.05096, 0.10452, 0.16081, 0.17943, 0.18910],
        ],
        columns=[
            "time_series_code",
            "scenario",
            "2019Q4",
            "2020Q4",
            "2021Q4",
            "2022Q4",
            "2023Q4",
        ],
    )


@pytest.fixture
def missing_static_agriland_df():
    return pd.DataFrame(
        [
            ["NLAGR", plus_name, 0.04151, 0.08475, 0.12978, 0.14812, np.nan],
            ["USAGR", plus_name, 0.04186, 0.08547, 0.13091, 0.15938, 0.17861],
            ["BRAGR", plus_name, 0.04164, np.nan, np.nan, np.nan, np.nan],
            ["AUAGR", plus_name, 0.04175, 0.08525, 0.13056, 0.14720, 0.15612],
            ["NZAGR", plus_name, 0.05652, 0.11624, 0.17933, np.nan, np.nan],
        ],
        columns=[
            "time_series_code",
            "scenario",
            "2019Q4",
            "2020Q4",
            "2021Q4",
            "2022Q4",
            "2023Q4",
        ],
    )


@pytest.fixture
def expected_last_quarters_of_shock_df():
    return pd.DataFrame(
        [
            ["NLAGR", "2022Q4", "2019Q4"],
            ["USAGR", "2023Q4", "2019Q4"],
            ["BRAGR", "2019Q4", "2019Q4"],
            ["AUAGR", "2023Q4", "2019Q4"],
            ["NZAGR", "2021Q4", "2019Q4"],
        ],
        columns=["time_series_code", "last_shock_quarter", "first_shock_quarter"],
    )


@pytest.fixture
def complete_dynamic_df(expected_agriland_model_applied_df):
    to_append_df = pd.DataFrame.from_dict(
        {
            "time_series_code": np.array(
                ["AUAGR", "AUAGR", "AUAGR", "AUAGR", "AUAGR", "AUAGR", "AUAGR", "AUAGR"]
            ),
            "period": np.array(
                [
                    "2018Q4",
                    "2019Q1",
                    "2019Q2",
                    "2019Q3",
                    "2019Q4",
                    "2020Q1",
                    "2020Q2",
                    "2020Q3",
                ]
            ),
            "value": np.array([100, 100, 100, 100, 100, 100, 100, 100]).astype(
                "float64"
            ),
        }
    )

    return pd.concat(
        [to_append_df, expected_agriland_model_applied_df], axis=0, sort=False
    )


@pytest.fixture
def incomplete_dynamic_df(expected_agriland_model_applied_df):
    return expected_agriland_model_applied_df
