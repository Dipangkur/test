from pathlib import Path

TEST_DATA_DIR = Path(__file__).parent / "data_for_test"
