"""Unit tests for regression.py module."""

import logging
import unittest

import pandas as pd
import pytest


from scenario_calculator.modelling.regression import apply_model
from scenario_calculator.modelling.regression import compute_modelled_act_series
from scenario_calculator.modelling.regression import derive_index
from scenario_calculator.modelling.regression import preprocess


def get_regression_table():
    """Table with regression coefficients"""
    data = [
        [
            20180815,
            "NLY",
            "NL",
            "NL",
            "YOY",
            0,
            "NLC",
            "NLC",
            "NLC",
            "NLC",
            0.5,
            0.0,
            0.0,
            0,
            0,
            "ABS",
            "ABS",
            "ABS",
            "ABS",
            0,
            0,
            0,
            0,
            2000,
            "AVG",
        ]
    ]
    cols = [
        "valid_from",
        "time_series_code",
        "nigem_code",
        "corep_country_code",
        "unit",
        "lag_coeff",
        "time_series_code1",
        "time_series_code2",
        "time_series_code3",
        "time_series_code4",
        "constant_coeff",
        "coeff1",
        "coeff2",
        "coeff3",
        "coeff4",
        "unit1",
        "unit2",
        "unit3",
        "unit4",
        "lag1",
        "lag2",
        "lag3",
        "lag4",
        "start_year",
        "aggr_type",
    ]
    return pd.DataFrame(data, columns=cols)


def get_target_time_series():
    """Construct target time_series"""
    idx = pd.date_range(str(1995), str(2005), freq="Q")
    val = [1] * 40
    s = pd.Series(val, index=idx)
    time_series = pd.DataFrame()
    time_series["series"] = s
    time_series["originating_raw_scenario_time_series_id"] = 1
    time_series["date"] = 1
    time_series["corep_code"] = ""
    time_series["start_year_extension"] = 2017
    time_series["source"] = ""
    time_series["series_code"] = "NLY"
    time_series["period"] = "1996Q1"
    time_series["scenario"] = "test"
    time_series["unit"] = "ABS_ACT"
    time_series["conversion_factor"] = 1
    time_series["param_beta0"] = 0
    time_series["param_beta1"] = 0
    time_series["param_d"] = 0
    time_series["transformation_type"] = "YOY"
    time_series["aggregation_type"] = "AVG"
    time_series["last_obs_date"] = s.index[-1]
    return time_series


def get_source_time_series():
    """Construct source time_series"""
    idx = pd.date_range(str(2000), str(2020), freq="Q")
    val = [1] * 80
    s = pd.Series(val, index=idx)
    time_series = pd.DataFrame()
    time_series["id"] = 1
    time_series["series"] = s
    time_series["originating_raw_scenario_time_series_id"] = 1
    time_series["date"] = 1
    time_series["corep_code"] = ""
    time_series["mapped_to_corep_code"] = ""
    time_series["mapped_to_variable_code"] = ""
    time_series["time_series_code"] = "NLAGR"
    time_series["nigem_code"] = "NL"
    time_series["variable_code"] = ""
    time_series["start_year_extension"] = 2017
    time_series["source"] = ""
    time_series["series_code"] = "NLC"
    time_series["period"] = "1996Q1"
    time_series["scenario"] = "test"
    time_series["unit"] = "ABS_ACT"
    time_series["conversion_factor"] = 1
    time_series["param_beta0"] = 0
    time_series["param_beta1"] = 0
    time_series["param_d"] = 0
    time_series["param_mu"] = 0
    time_series["param_sigma"] = 0
    time_series["transformation_type"] = "YOY"
    time_series["aggregation_type"] = "AVG"
    time_series["last_obs_date"] = s.index[-1]
    time_series["extension_transformation_type"] = "YOY"
    time_series["aggregation_transformation_type"] = "AVG"
    time_series["adjustment"] = "derived"

    return time_series


class TestRegressionModelling(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def inject_fixture(self, caplog):
        self._caplog = caplog

    def test_apply_model(self):
        """Test for apply model function"""

        ts1_df = get_target_time_series()
        ts2_df = get_source_time_series()

        df_scenarios = pd.concat([ts1_df, ts2_df])

        df = get_regression_table()

        scenarios = apply_model(df_scenarios, df, "A-DEC")

        result = scenarios[
            (scenarios["series_code"] == "NLC") & (scenarios["unit"] == "ABS_ACT")
        ]

        # expected result:
        idx = pd.date_range(str(2000), str(2020), freq="Q")
        val = [1.0] * 80
        s = pd.Series(val, index=idx)

        pd.testing.assert_series_equal(result.series, s, check_names=False)

    def test_exception1(self):
        """Test exceptions"""
        ts1_df = get_target_time_series()
        ts2_df = get_source_time_series()

        scenarios = pd.concat([ts1_df, ts2_df])

        df = get_regression_table()
        row_nt = next(df.itertuples(index=False))

        with pytest.raises(IndexError):
            compute_modelled_act_series(row_nt, "NLY", scenarios, "YOY", "A-DEC", "")

    def test_exception2(self):
        """Test exception - KeyError"""

        ts1_df = get_target_time_series()
        ts2_df = get_source_time_series()

        scenarios = pd.concat([ts1_df, ts2_df])

        df = get_regression_table()
        row_nt = next(df.itertuples(index=False))

        with pytest.raises(IndexError):
            # with pytest.raises(KeyError):
            compute_modelled_act_series(row_nt, "NLY", scenarios, "YOY", "A-DEC", ""),

    def test_exception3(self):
        """Test exception - Incorrect StartYear"""
        idx = pd.date_range(str(1995), str(2005), freq="Q")
        val = [1] * 40
        series = pd.Series(val, index=idx)
        start_year = 2100
        with self._caplog.at_level(logging.ERROR):
            preprocess(series, start_year)
            assert "Invalid start year of series!" in self._caplog.text

    def test_exception4(self):
        """Test exception - Incorrect parameters for derive_index"""
        with self._caplog.at_level(logging.ERROR):
            # noinspection PyTypeChecker
            derive_index(None, None, None, None, None, None)  # NOSONAR
            assert (
                "unit (None), aggr_type (None), freq (None) must be valid\n"
                in self._caplog.text
            )
