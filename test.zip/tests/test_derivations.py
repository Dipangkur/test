# -*- coding: utf-8 -*-
"""@author: Jurgen.Tas@Rabobank.nl
Unit tests for derivations.py (test exceptions)
"""

# TODO [JHB]: Fix all abusive uses of self.assertRaises in this module
#  Either separate the callable from its arguments, or use the
#  contextmanager variant (see
#  https://docs.python.org/3.6/library/unittest.html\
#   #unittest.TestCase.assertRaises)
#  or use the pytest.raises variant.
#  PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469219
import unittest

import pandas as pd
import pytest

from scenario_calculator.modelling.derivations import get_gdp_per_cappopt
from scenario_calculator.modelling.derivations import get_gdp_per_popwa
from scenario_calculator.modelling.derivations import get_real_rate

IDX = pd.date_range(str(1995), str(2005), freq="Q")
VAL = [1.0] * 40


def construct_series_for_testing(series_code, idx=IDX, val=VAL):
    """Construct time_series"""
    s = pd.Series(val, index=idx)
    time_series = pd.DataFrame()
    time_series["id"] = 1
    time_series["series"] = s
    time_series["originating_raw_scenario_time_series_id"] = 1
    time_series["date"] = 1
    time_series["corep_code"] = series_code[0:2]
    time_series["mapped_to_corep_code"] = ""
    time_series["mapped_to_variable_code"] = ""
    time_series["time_series_code"] = series_code
    time_series["nigem_code"] = series_code[0:2]
    time_series["variable_code"] = series_code[2:]
    time_series["start_year_extension"] = 2005
    time_series["source"] = ""
    time_series["series_code"] = series_code
    time_series["period"] = "1996Q1"
    time_series["scenario"] = ""
    time_series["unit"] = "ABS_ACT"
    time_series["conversion_factor"] = 1
    time_series["param_beta0"] = 0
    time_series["param_beta1"] = 0
    time_series["param_d"] = 0
    time_series["param_mu"] = 0
    time_series["param_sigma"] = 0
    time_series["transformation_type"] = ""
    time_series["aggregation_type"] = ""
    time_series["last_obs_date"] = s.index[-1]
    time_series["extension_transformation_type"] = "YOY"
    time_series["aggregation_transformation_type"] = "AVG"
    time_series["adjustment"] = "derived"

    return time_series


def construct_scenario_for_testing():
    """Construct series_dict for testing"""
    s1 = construct_series_for_testing("NLY")
    s2 = construct_series_for_testing("NLPOPWA")
    s3 = construct_series_for_testing("NLPOPT")
    s4 = construct_series_for_testing("NLR3M")
    s5 = construct_series_for_testing("NLCED")
    s6 = construct_series_for_testing("CNY")
    s7 = construct_series_for_testing("CNPOPT")
    return pd.concat([s1, s2, s3, s4, s5, s6, s7])


class TestDerivations(unittest.TestCase):
    _single_scenario = construct_scenario_for_testing()
    _series = pd.Series(VAL, index=IDX)
    _df_variables = pd.DataFrame.from_dict(
        {
            "variable_code": ["GDPperCAPPOPT", "GDPperCAPPOPWA", "RR3M"],
            "aggregation_transformation_type": ["SUM", "SUM", "AVG"],
        }
    )

    def test_get_gdp_per_cappopt(self):
        """Test gdp_per_cappopt"""
        # TODO [JHB]: this test does not verify aggregation on specific typ
        #   PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/860905
        ts = get_gdp_per_cappopt(self._df_variables, "NL", "", self._single_scenario)
        pd.testing.assert_series_equal(self._series, ts.series, check_names=False)

    def test_get_gdp_per_cappopwa(self):
        """Test gdp_per_cappopwa"""
        # TODO [JHB]: this test does not verify aggregation on specific type
        #   PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/860905
        ts = get_gdp_per_popwa(self._df_variables, "NL", "", self._single_scenario)
        pd.testing.assert_series_equal(self._series, ts.series, check_names=False)

    def test_get_gdp_per_cappopwa_fallback(self):
        """Test gdp_per_cappopwa fallback situation"""
        with pytest.raises(ValueError):
            ts = get_gdp_per_popwa(self._df_variables, "CN", "", self._single_scenario)
            pd.testing.assert_series_equal(self._series, ts.series)

    def test_get_real_rate(self):
        """Test get_real_rate"""
        # TODO [JHB]: this test does not verify aggregation on specific type
        #   PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/860905
        ts = get_real_rate(self._df_variables, "NL", "", self._single_scenario)
        idx = pd.date_range(str(1996), str(2005), freq="Q")
        val = [1.0] * 36
        s = pd.Series(val, index=idx)
        pd.testing.assert_series_equal(s, ts.series, check_names=False)

    @pytest.mark.xfail(reason="To be solved with Product Backlog Item 535129")
    def test_exceptions(self):
        """Test exceptions"""
        # Exception 1:
        d = self._single_scenario
        with self.assertRaises(KeyError):
            get_gdp_per_cappopt(self._df_variables, "BE", "", d)
        with self.assertRaises(KeyError):
            get_gdp_per_popwa(self._df_variables, "BE", "", d)
        with self.assertRaises(KeyError):
            get_real_rate(self._df_variables, "BE", "", d)
