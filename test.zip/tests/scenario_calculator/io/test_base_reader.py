import pytest
from sqlalchemy.engine.url import make_url

from scenario_calculator.io.base_reader import read_dynamic_data, sqlalch_url2path
from scenario_calculator.sql_alch_create_engine_args import UnsupportedUrlSchemeError

_SOME_WRONG_URL_TEMPLATE = "some_scheme://username:{secret}@host/path"


def test_read_dynamic_data_scheme_unsupported():
    with pytest.raises(UnsupportedUrlSchemeError):
        # -1, 0 are just arbitrary values; not used for this test
        read_dynamic_data("some_scheme://some_user:some_pass@some_host/path", -1, 0)


def test_sqlalch_url2path_wrong_type():
    class UrlFaker:
        def __init__(self):
            self.drivername = "some_scheme"

    with pytest.raises(TypeError):
        sqlalch_url2path(UrlFaker())  # NOSONAR


def test_sqlalch_url2path_wrong_scheme():
    some_wrong_url = _SOME_WRONG_URL_TEMPLATE.format(secret="some_secret")
    wrong_url_displayed = _SOME_WRONG_URL_TEMPLATE.format(secret="***")
    some_sqlalch_url = make_url(some_wrong_url)
    with pytest.raises(ValueError) as value_exception:
        sqlalch_url2path(some_sqlalch_url)
    assert str(value_exception.value).endswith(wrong_url_displayed)
