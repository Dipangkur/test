# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import pytest
from hamcrest import assert_that, is_, equal_to
from pandas.testing import assert_frame_equal

from component_tests.features.steps.utility_component_tests import (
    make_diagnostic_report,
)
from scenario_calculator.constants import (
    INPUT_DYNAMIC_DF_WITH_MOCK_AGRILAND,
    EXPECTED_EXTENDED_DYNAMIC_DF_WITH_MOCK_AGRILAND,
    INPUT_DYNAMIC_DF_WITH_OC_AGR_BASELINE,
    EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC_AGR_BASELINE,
    INPUT_DYNAMIC_DF_WITH_OC_AGR_PLUS,
    EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC_AGR_PLUS,
    INPUT_TEMPLATE_DYNAMIC_DF,
)

from scenario_calculator.io.reader import read_and_extend_input
from scenario_calculator.settings import Settings
from tests.test_settings import TestSettings


def _read_and_extend_with_oc_settings(some_batch_size, some_run_definition, file_name):
    return read_and_extend_input(
        (TestSettings.TEST_DYNAMIC_DATA_DIR / file_name).as_uri(),
        TestSettings.TEST_STATIC_DATA_DIR,
        TestSettings.TEST_FILE_MAPPING_OTHER_COUNTRY,
        some_batch_size,
        some_run_definition,
    )


def _read_expected_dynamic_output(file_name):
    return pd.read_csv(
        (TestSettings.TEST_DYNAMIC_DATA_DIR / file_name).as_uri(),
        delimiter=";",
        encoding="utf-8",
    )


def _sort_by_mev_and_period(unsorted_df):
    unsorted_df = (
        unsorted_df.drop("id", axis=1)
        .sort_values(by=["time_series_code", "period"])
        .round({"value": 4})
    )
    return unsorted_df


class TestReader:
    """
    This class is made out of several tests. Each small test check the reading
    of static data given in a csv file to a data frame using fixtures.
    A mapping is used to switch the name of the files that CAS gets from
    MES. the mapping is needed to know the origin of the file i.e ARIMA
    etc. Yet, in the code it is transferred to the designated use. The
    mapping can be found in settings.py
    """

    def test_read_arima_df(self, static_test_data_dict):
        """
        Test the reading of static_arima_params.csv into a data frame
        """
        expected_arima_df = pd.DataFrame.from_dict(
            {
                "time_series_code": np.array(["AUAGR", "AUC"]),
                "nigem_country_code": np.array(["AU", "AU"]),
                "variable_code": np.array(["AGR", "C"]),
                "corep_country_code": np.array(["AU", "AU"]),
                "model_param_beta_0": np.array([0.064826143, 0.033931526]),
                "model_param_beta_1": np.array([0.581343703, 0]),
                "model_param_d": np.array([0, 0]).astype("int64"),
                "conversion_factor": np.array([1, 1]).astype("int64"),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(static_test_data_dict["extension"], expected_arima_df)

    def test_read_standardization_df(self, static_test_data_dict):
        """
        Test the reading of static_standardization_params.csv into a data frame
        """
        expected_standardization_df = pd.DataFrame.from_dict(
            {
                "time_series_code": np.array(["AUAGR", "AUAGR"]),
                "nigem_country_code": np.array(["AU", "AU"]),
                "variable_code": np.array(["AGR", "AGR"]),
                "unit": np.array(["ABS", "YOY"]),
                "model_param_mu": np.array([2.337267337, 0.0637809693]),
                "model_param_sigma": np.array([0.892476993, 0.061753802]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["standardization"], expected_standardization_df
        )

    def test_read_macroeconomic_df(self, static_test_data_dict):
        """
        Test the reading of static_macroeconomic_variable.csv into a data frame
        """
        expected_macroeconomic_df = pd.DataFrame.from_dict(
            {
                "variable_code": np.array(["AGR", "C"]),
                "description": np.array(["AGRILAND Index", "Private consumption"]),
                "variable_type": np.array(["modelled", "nigem"]),
                "extension_transformation_type": np.array(["YOY", "YOY"]),
                "aggregation_transformation_type": np.array(["AVG", "SUM"]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["variables"], expected_macroeconomic_df
        )

    def test_nbrof_years_df(self, static_test_data_dict):
        """
        Test the reading of static_end_year_extension.csv into a data frame
        """
        expected_nbrof_years_df = pd.DataFrame.from_dict(
            {"end_year_extension": np.array([30]).astype("int64")}
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["nbrof_years_extension"], expected_nbrof_years_df
        )

    def test_read_country_mapping_df(self, static_test_data_dict):
        """
        Test the reading of static_country_mapping.csv into a data frame
        """
        expected_country_mapping_df = pd.DataFrame.from_dict(
            {
                "corep_country_code": np.array(["CW", "TT"]),
                "corep_description": np.array(["CURAÇAO", "TRINIDAD & TOBAGO"]),
                "mapped_to_nigem_country_code": np.array(["BR", "RU"]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["missing_countries_mapping"],
            expected_country_mapping_df,
        )

    def test_read_regression_params_df(self, static_test_data_dict):
        """
        Test the reading of static_regression_params.csv into a data frame
        """
        expected_regression_params_df = pd.DataFrame.from_dict(
            {
                "time_series_code": np.array(["BGPH", "NLPCRE"]),
                "nigem_code": np.array(["BG", "NL"]),
                "corep_country_code": np.array(["BE", "NL"]),
                "unit": np.array(["YOY", "YOY"]),
                "lag_coeff": np.array([0.675643, 0]),
                "time_series_code1": np.array(["BGR3M", "NLPH"]),
                "time_series_code2": np.array(["BGR3M", "NLLR"]),
                "time_series_code3": np.array(["BGR3M", "NLPH"]),
                "time_series_code4": np.array(["BGR3M", "NLLR"]),
                "constant_coeff": np.array([0, 0]).astype("int64"),
                "coeff1": np.array([1.2044, 0.862]),
                "coeff2": np.array([-1.486, 1.2]),
                "coeff3": np.array([0, 0]).astype("int64"),
                "coeff4": np.array([0, 0]).astype("int64"),
                "unit1": np.array(["Y-Y", "YOY"]),
                "unit2": np.array(["Y-Y", "Y-Y"]),
                "unit3": np.array(["Y-Y", "YOY"]),
                "unit4": np.array(["Y-Y", "Y-Y"]),
                "lag1": np.array([0, 0]).astype("int64"),
                "lag2": np.array([1, 0]).astype("int64"),
                "lag3": np.array([0, 0]).astype("int64"),
                "lag4": np.array([0, 0]).astype("int64"),
                "start_year": np.array([1998, 1998]).astype("int64"),
                "aggr_type": np.array(["AVG", "AVG"]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["regression_modelling"], expected_regression_params_df
        )

    def test_read_series_mapping_df(self, static_test_data_dict):
        """
        Test the reading of static_series_mapping.csv into a data frame
        """
        expected_series_mapping_df = pd.DataFrame.from_dict(
            {
                "time_series_code": np.array(["IRAGR", "IDAGR"]),
                "nigem_country_code": np.array(["IR", "ID"]),
                "corep_country_code": np.array(["IE", "ID"]),
                "mapped_to_time_series_code": np.array(["NLAGR", "IDY"]),
                "corep_description": np.array(["IRELAND", "INDONESIA"]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["missing_series_mapping"], expected_series_mapping_df
        )

    def test_read_agriland_param_df(self, static_test_data_dict):
        """
        Test the reading of static_agriland_params.csv into a data frame
        """
        expected_agriland_param_df = pd.DataFrame.from_dict(
            {
                "time_series_code": np.array(["AUAGR", "AUAGR", "AUAGR", "NLAGR"]),
                "scenario_type": np.array(
                    ["Baseline", "Plus", "MY ST Adverse", "Minus"]
                ),
                "shock_year_1": np.array([1, 0.05, 0.8, 0.8836]),
                "shock_year_2": np.array([1, 0.05, 0.8, 0.8836]),
                "shock_year_3": np.array([1, 0.05, 0.8, 0.8836]),
                "shock_year_4": np.array([1, 0.02, 0.8, 0.8836]),
                "shock_year_5": np.array([1, 0.01, 0.8, 0.8836]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(
            static_test_data_dict["agriland_org"], expected_agriland_param_df
        )

    def test_read_model_info_df(self, static_test_data_dict):
        """
        Test the reading of static_model_info.csv into a data frame
        """
        expected_model_info_df = pd.DataFrame.from_dict(
            {
                "model_version": np.array(["Version 0.1"]),
                "model_name": np.array(["Meister Test Scenario Model"]),
            }
        )

        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        assert_frame_equal(static_test_data_dict["model_info"], expected_model_info_df)

    @pytest.mark.xfail(reason="No Reason for them to be equal, will be replaced")
    def test_read_oc_agriland_df(self, static_test_data_oc_agriland, static_data_dict):
        """
        Test the reading of static_agriland_params_oc.csv for the case
        it's equal to the original static_agriland_params file
        """
        # Use the keys of the file_mapping, since read_static_data apply a
        # mapping
        pd.testing.assert_frame_equal(
            static_test_data_oc_agriland["agriland_org"],
            static_data_dict["agriland_org"],
        )

    def test_read_and_extend_no_agriland(
        self, extension_without_agriland_df, some_batch_size, some_run_definition,
    ):
        """
        Test read_and_extend_input() using fixtures for the case Agriland
        static data is empty.
        """
        # Use the keys of the file_mapping since read_static_data
        # apply a mapping and random batch_size and random_run_definition fixtures

        extension_df = read_and_extend_input(
            (TestSettings.TEST_DYNAMIC_DATA_DIR / INPUT_TEMPLATE_DYNAMIC_DF).as_uri(),
            TestSettings.TEST_STATIC_DATA_DIR,
            TestSettings.TEST_FILE_MAPPING,
            some_batch_size,
            some_run_definition,
        ).frames["extension"]

        extension_without_agriland_df = extension_without_agriland_df.astype(
            extension_df.dtypes.to_dict()
        )

        df1 = extension_df
        df2 = extension_without_agriland_df

        df2 = df2.replace({np.nan: None})
        df2 = df2.replace({"nan": None})

        assert ((df1 == df2) | ((df1 != df1) & (df2 != df2))).values.all()  # NOSONAR

    def test_read_and_extend_with_agriland(
        self, some_batch_size, some_run_definition,
    ):
        """
        Test read_and_extend_input() using fixtures for the case Agriland
        static data is not empty.
        """
        # Use the keys of the file_mapping since read_static_data
        # apply a mapping and random batch_size and random_run_definition fixtures
        extension_df = read_and_extend_input(
            (
                TestSettings.TEST_DYNAMIC_DATA_DIR / INPUT_DYNAMIC_DF_WITH_MOCK_AGRILAND
            ).as_uri(),
            TestSettings.TEST_STATIC_DATA_DIR,
            Settings.STANDARD_FILE_MAPPING,
            some_batch_size,
            some_run_definition,
        ).frames["extension"]

        expected_extension_df = pd.read_csv(
            (
                TestSettings.TEST_DYNAMIC_DATA_DIR
                / EXPECTED_EXTENDED_DYNAMIC_DF_WITH_MOCK_AGRILAND
            ).as_uri(),
        )
        expected_extension_df = expected_extension_df.astype(
            extension_df.dtypes.to_dict()
        )
        assert_frame_equal(extension_df, expected_extension_df)

    def test_read_euro_countries_df(self, static_test_data_dict):
        """
        Test the reading of static_euro_countries.csv into a data frame
        """
        expected_euro_countries_df = pd.DataFrame.from_dict(
            {"nigem_country_code": np.array(["BG", "FR", "GE", "IT", "NL", "SP"])}
        )

        assert_frame_equal(
            static_test_data_dict["other_country_euro_countries"],
            expected_euro_countries_df,
        )

    def test_read_price_variables_df(self, static_test_data_dict):
        """
        Test the reading of static_price_variables.csv into a data frame
        """
        expected_price_variables_df = pd.DataFrame.from_dict(
            {"variable_code": np.array(["C", "DD", "PSI", "RPDI", "XVOL", "Y"])}
        )

        assert_frame_equal(
            static_test_data_dict["other_country_price_variables"],
            expected_price_variables_df,
        )

    def test_read_start_year_df(self, expected_start_year_df, static_test_data_dict):
        """
        Test the reading of static_start_year.csv into a data frame
        """
        assert_frame_equal(
            static_test_data_dict["other_country_start_year"], expected_start_year_df
        )

    def test_read_weights_df(self, expected_weights_df, static_test_data_dict):
        """
        Test the reading of static_weights.csv into a data frame
        """
        assert_frame_equal(
            static_test_data_dict["other_country_weights"], expected_weights_df
        )

    def test_read_and_extend_with_other_country(
        self, some_batch_size, some_run_definition
    ):
        """
        Test read_and_extend_input() with other country
        """

        extended_input_with_oc = _read_and_extend_with_oc_settings(
            some_batch_size, some_run_definition, INPUT_DYNAMIC_DF_WITH_OC_AGR_BASELINE,
        )

        df_calculated = extended_input_with_oc.frames["oc_appended_dynamic_df"]

        df_expected = _read_expected_dynamic_output(
            EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC_AGR_BASELINE
        )

        # Check the data frame column names are matching
        assert_that(
            list(df_calculated.columns),
            is_(equal_to(list(df_expected.columns))),
            "DataFrame column names are different",
        )
        # Check the column dtypes
        assert_that(
            list(df_calculated.dtypes),
            is_(equal_to(list(df_expected.dtypes))),
            "DataFrame column dtypes are different",
        )

        df_calculated = _sort_by_mev_and_period(df_calculated)

        df_expected = _sort_by_mev_and_period(df_expected)

        try:
            assert_frame_equal(
                df_calculated.reset_index(drop=True).transpose(),
                df_expected.reset_index(drop=True).transpose(),
                check_exact=True,
            )

        except AssertionError:
            make_diagnostic_report(
                df_calculated, df_expected, list(df_calculated.columns),
            )
            raise

    def test_read_and_extend_with_other_country_plus(
        self, some_batch_size, some_run_definition
    ):
        """
        Test read_and_extend_input() with other country for plus scenario
        """

        extended_input_with_oc = _read_and_extend_with_oc_settings(
            some_batch_size, some_run_definition, INPUT_DYNAMIC_DF_WITH_OC_AGR_PLUS
        )

        df_calculated = extended_input_with_oc.frames["oc_appended_dynamic_df"]

        df_expected = _read_expected_dynamic_output(
            EXPECTED_OUTPUT_DYNAMIC_DF_WITH_OC_AGR_PLUS
        )

        # Check the data frame column names are matching
        assert_that(
            list(df_calculated.columns),
            is_(equal_to(list(df_expected.columns))),
            "DataFrame column names are different",
        )
        # Check the column dtypes
        df_calculated = df_calculated.astype(df_expected.dtypes.to_dict())
        assert_that(
            list(df_calculated.dtypes),
            is_(equal_to(list(df_expected.dtypes))),
            "DataFrame column dtypes are different",
        )

        df_calculated = _sort_by_mev_and_period(df_calculated)

        df_expected = _sort_by_mev_and_period(df_expected)
        try:
            assert_frame_equal(
                df_calculated.reset_index(drop=True).transpose(),
                df_expected.reset_index(drop=True).transpose(),
                check_exact=True,
            )
        except AssertionError:
            make_diagnostic_report(
                df_calculated, df_expected, list(df_calculated.columns),
            )
            raise
