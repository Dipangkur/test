import pytest
from pandas.testing import assert_frame_equal

import scenario_calculator
from scenario_calculator.io.blobstorage import BlobReaderBackend
from scenario_calculator.io.file_reader import (
    BlobReader,
    extract_blob_file_name,
    create_merged_mapping,
    FileReader,
)
from scenario_calculator.settings import Settings


class TestBlobReaderBackend:
    def test_as_contextmanager(self, mocker):
        service = mocker.patch(
            "scenario_calculator.io.blobstorage.BlockBlobService"
        ).return_value

        service.get_blob_to_stream = lambda _a, _b, _stream: _stream.write(b"data")

        url = "https://funaccount.blob.core.windows.net/funcontainer/fun file.csv"
        with BlobReaderBackend("some_account_key", url) as stream:
            assert stream.read() == "data"

    def test_invalid_url(self, mocker):
        mocker.patch("scenario_calculator.io.blobstorage.BlockBlobService")

        with pytest.raises(ValueError) as excinfo:
            BlobReaderBackend("account_key", "invalidurl")
        assert "Invalid url" in str(excinfo.value)

    def test_blob_wo_account_key(self, mocker):
        mocker.patch("scenario_calculator.io.blobstorage.BlobReaderBackend")

        with pytest.raises(ValueError):
            BlobReader("https://bla.blob.core.windows.net/container/filename")

    def test_extract_blob_file_name(self):
        test_directory = "https://bla.blob.core.windows.net/"
        test_file_name = "container/34geg/9090353 file name20200115155735400.csv"
        file_base_name, file_extension = extract_blob_file_name(
            test_directory + test_file_name
        )
        assert file_base_name == "file name" and file_extension == ".csv"

    def test_backend_call(self, mocker):
        mocker.patch("scenario_calculator.io.file_reader.BlobReaderBackend")

        class TestBlobReader(FileReader):
            def read(self, buf, default_na):
                """"This is a override method"""
                pass

        TestBlobReader.set_account_key("some account key")
        test_directory = "https://bla.blob.core.windows.net/"
        test_file_name = "container/34geg/9090353 file name20200115155735400.csv"
        file_reader = TestBlobReader(test_directory + test_file_name)
        file_reader.read_blob(True)
        assert scenario_calculator.io.file_reader.BlobReaderBackend.call_count == 1

    def test_create_merged_mapping(
        self, static_blob_files_list, expected_merged_mapping
    ):
        assert_frame_equal(
            create_merged_mapping(
                static_blob_files_list, Settings.STANDARD_FILE_MAPPING
            ),
            expected_merged_mapping,
        )
