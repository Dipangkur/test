from collections import namedtuple
from copy import deepcopy
from datetime import datetime
from unittest.mock import MagicMock, NonCallableMagicMock

import pandas as pd
import pytest
from numpy import float64
from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm.attributes import InstrumentedAttribute

from scenario_calculator.data_attr_rename_and_xform import ATTR_MAPPING_DESC
from scenario_calculator.io.db_conv_utils import DbInputTransformer

NAMEDTUPLE_FIELDS_1 = ("foo", "bar", "bletch")
NAMEDTUPLE_VALUES_1 = [
    ("str_111", "str_112", 113),
    ("str_121", "str_122", 123),
    ("str_131", "str_132", 133),
]
NamedTupleEx1 = namedtuple("NamedTupleEx1", NAMEDTUPLE_FIELDS_1)

NAMEDTUPLE_EX_1_LIST = [
    NamedTupleEx1._make(tuple_row) for tuple_row in NAMEDTUPLE_VALUES_1
]

NAMEDTUPLE_FIELDS_2 = ("baz", "spam", "eggs")
NAMEDTUPLE_VALUES_2 = (
    ("str_211", "str_212", 213),
    ("str_221", "str_222", 223),
    ("str_231", "str_232", 233),
)
NamedTupleEx2 = namedtuple("NamedTupleEx2", NAMEDTUPLE_FIELDS_2)

NAMEDTUPLE_EX_2_LIST = [
    NamedTupleEx2._make(tuple_row) for tuple_row in NAMEDTUPLE_VALUES_2
]


@pytest.fixture
def m_model_cls():
    m_model_cls = NonCallableMagicMock(spec=DeclarativeMeta)
    m_model_cls.Field1 = MagicMock(spec=InstrumentedAttribute)
    m_model_cls.Field2 = MagicMock(spec=InstrumentedAttribute)
    m_model_cls.Field3 = MagicMock(spec=InstrumentedAttribute)
    m_model_cls.Field4 = MagicMock(spec=InstrumentedAttribute)
    m_model_cls.__name__ = "MockedDbModel"
    return m_model_cls


TEST_SQL_DF_COLUMN_MAP: ATTR_MAPPING_DESC = {
    "Field1": None,
    "Field2": "new_field2_name",
    "Field3": ("new_field3_name", float64),
    "Field4": ("new_field4_name", None, lambda s: datetime.strptime(s, "%Y%m%d")),
}


def test_db_input_conv_make_orm_query_fields(m_model_cls) -> None:
    """Check whether a proper list of ORM field is generated."""
    db_input_conv = DbInputTransformer(m_model_cls, TEST_SQL_DF_COLUMN_MAP)
    orm_query_fields = db_input_conv.make_orm_query_fields()
    assert orm_query_fields == [
        m_model_cls.Field2,
        m_model_cls.Field3,
        m_model_cls.Field4,
    ]


def test_db_input_conv_rejects_too_long_sequence(m_model_cls) -> None:
    """Check whether spots input not cf. TARGET_ATTR_DESC format."""
    test_wrong_df_column_map = deepcopy(TEST_SQL_DF_COLUMN_MAP)
    test_wrong_df_column_map["Field4"] = test_wrong_df_column_map["Field4"] + ("",)
    with pytest.raises(ValueError):
        DbInputTransformer(m_model_cls, test_wrong_df_column_map)


def test_db_input_conv_rejects_non_sequence(m_model_cls) -> None:
    """Check whether spots input not cf. TARGET_ATTR_DESC format."""
    test_wrong_df_column_map = deepcopy(TEST_SQL_DF_COLUMN_MAP)
    test_wrong_df_column_map["Field4"] = dict()
    with pytest.raises(TypeError):
        DbInputTransformer(m_model_cls, test_wrong_df_column_map)


CURDATETIME = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
TEST_DF = pd.DataFrame(
    {
        "Field2": ["Str1", "Str2", "Str3"],
        "Field3": [31, 23, 33],
        "Field4": ["20120131", "20110812", "19800608"],
    }
)


def test_db_input_conv_rename_columns_heading(m_model_cls) -> None:
    """Check whether renaming of columns heading is correct."""
    db_input_conv = DbInputTransformer(m_model_cls, TEST_SQL_DF_COLUMN_MAP)
    result = db_input_conv.rename_columns_heading(TEST_DF)
    assert list(result.columns) == [
        "new_field2_name",
        "new_field3_name",
        "new_field4_name",
    ]


def test_db_input_conv_xform_data_and_change_data_type(m_model_cls) -> None:
    """Check whether data transformation and type are changing correctly."""
    db_input_conv = DbInputTransformer(m_model_cls, TEST_SQL_DF_COLUMN_MAP)
    result = db_input_conv.xform_data_and_change_data_type(TEST_DF)
    assert type(result["Field3"][0]) == float64
    assert type(result["Field3"][1]) == float64
    assert type(result["Field3"][2]) == float64
    assert result["Field4"][0] == datetime(2012, 1, 31)
    assert result["Field4"][1] == datetime(2011, 8, 12)
    assert result["Field4"][2] == datetime(1980, 6, 8)
