"""@author: Jurgen.Tas@Rabobank.nl
Unit tests for agriland_parameters.py
"""
from pytest import raises
import pandas as pd

from scenario_calculator.io.agriland_parameters import (
    get_original_agriland_frame,
    get_unique_scenario_type,
    increment_date,
    get_total_shock_years,
)


class TestRegressionModelling:
    def test_get_unique_scenario_type(self):
        scenario = "201206 ICAAP Baseline"
        result = get_unique_scenario_type(scenario)
        assert result == "ICAAP Baseline"

    def test_get_unique_scenario_type_exception(self):
        scenario = "201206 Test Test"
        with raises(ValueError):
            get_unique_scenario_type(scenario)

    def test_increment_date(self):
        string_date = "2018Q4"
        delta_in_years = 2
        result = increment_date(string_date, delta_in_years)
        assert result == "2020Q4"

    def test_get_original_agriland_frame(
        self, static_data_dict, expected_filtered_static_agriland_df
    ):
        start_date_of_shock_period = "2018Q4"

        result = get_original_agriland_frame(
            static_data_dict["agriland_org"], "201806 Plus", start_date_of_shock_period
        )
        pd.testing.assert_frame_equal(result, expected_filtered_static_agriland_df)

    def test_empty_get_original_agriland_frame(self):
        """
        Agriland prices are an important variable for Rabobank, however not
        always provided. This test makes sure that the
        function get_original_agriland_frame() will return empty dataframe in
        case we are not provided with Agriland information from RaboResearch.

        :return: True, we have an empty dataframe else False
        :rtype: boolean
        """
        assert get_original_agriland_frame(
            pd.DataFrame(), "201806 Plus", "2018Q4"
        ).empty

    def test_get_total_shock_years(self, static_data_dict):
        assert isinstance(
            get_total_shock_years(static_data_dict["agriland_org"], "shock_year_"), int
        )
