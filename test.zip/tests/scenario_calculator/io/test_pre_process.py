# -*- coding: utf-8 -*-
from scenario_calculator.io.pre_process import (
    calc_scenario_start_date,
    get_reporting_date,
    get_end_year_extension,
    get_frequency,
    get_scenario_name,
)


class TestReader:
    """
    This class is made out of several tests. Each small test checks the
    performance of characters of a function in the pre_process.py
    """

    def test_get_scenario_name(self, m_scenario_df):
        """
        Test the calculation of get_scenario_name using a mocked dynamic df
        """
        assert get_scenario_name(m_scenario_df) == "201809 Baseline"

    def test_get_reporting_date(self, m_scenario_df):
        """
        Test the calculation of get_reporting_date using a fixture
        """
        # The reporting date is taken from the mocked dynamic file
        assert get_reporting_date(m_scenario_df) == 20180930

    def test_calc_scenario_start_date(self):
        """Test the calculation of the scenario start date."""
        assert calc_scenario_start_date(20180930) == 20181231
        assert calc_scenario_start_date(20181231) == 20190331

    def test_get_end_year_extension(self, end_date_test):
        """
        Test the calculation of get_end_year_extension using a fixture
        """
        assert get_end_year_extension(end_date_test) == 2048

    def test_scenario_end_date(self, end_date_test):
        """Test the calculation of scenario end date."""
        assert end_date_test == 20480930

    def test_get_frequency(self):
        """
        Test the calculation of get_frequency for the four quarters
        """
        assert get_frequency(20180331) == "A-MAR"
        assert get_frequency(20180630) == "A-JUN"
        assert get_frequency(20180930) == "A-SEP"
        assert get_frequency(20181231) == "A-DEC"
