import typing
from unittest.mock import Mock

import pytest
from msrestazure.azure_active_directory import MSIAuthentication

from scenario_calculator import db_connect_utils
from scenario_calculator.db_connect_utils import (
    str2mswin_bstr,
    get_msi_authentication_access_token,
    fill_sql_alchemy_url_template,
    odbc_attr_val_quote,
)


def test_fill_sql_alchemy_url_template(mocker) -> None:
    plain_template = "just some plain text"
    msi_auth_func_mock: Mock = mocker.Mock(spec_set=get_msi_authentication_access_token)

    result = fill_sql_alchemy_url_template(plain_template, msi_auth_func_mock)
    assert result == plain_template
    assert not msi_auth_func_mock.called

    msi_auth_func_mock.reset_mock()
    result = fill_sql_alchemy_url_template(plain_template + "{{}}", msi_auth_func_mock)
    assert result == plain_template + "{}"
    assert not msi_auth_func_mock.called

    msi_auth_func_mock.reset_mock()
    msi_auth_func_mock.return_value = "some token val and a +-sign"
    result = fill_sql_alchemy_url_template(
        plain_template + "{token}", msi_auth_func_mock
    )
    assert result == (
        plain_template
        + "some+token+val+and+a+%{plus_code:02X}-sign".format(plus_code=ord("+"))
    )
    msi_auth_func_mock.assert_called_once_with()

    msi_auth_func_mock.reset_mock(return_value=True)
    msi_auth_func_mock.return_value = "some_db_token_val"
    result = fill_sql_alchemy_url_template(
        plain_template + "{database_token}", msi_auth_func_mock
    )
    assert result == plain_template + "some_db_token_val"
    msi_auth_func_mock.assert_called_once_with("https://database.windows.net/")

    msi_auth_func_mock.reset_mock(return_value=True)
    with pytest.raises(KeyError):
        fill_sql_alchemy_url_template(
            plain_template + "{unknown_key}", msi_auth_func_mock
        )


def test_str2mswin_bstr() -> None:
    input_str = "abcd\x00\x11\x7E\x7F"
    expected = _alt_bstr_encoding_impl(input_str)
    assert str2mswin_bstr(input_str) == expected


def _alt_bstr_encoding_impl(input_str):
    """An alternative implementation for test purposes of the ms-bstr.

    :param input_str: the string to convert
    :return: the ms-bstr encoded equivalent
    """
    encoded_value = b"".join(bytes((ord(char), 0)) for char in input_str)
    bytes_len = len(encoded_value)
    encoded_len_bytevals = []
    for _ in range(4):
        byteval, bytes_len = bytes_len & 0xFF, bytes_len >> 8
        encoded_len_bytevals.append(byteval)
    expected = bytes(encoded_len_bytevals) + encoded_value
    return expected


def test_odbc_attr_val_quote() -> None:
    """Test if `odbc_attr_val_quote` properly quotes."""
    assert odbc_attr_val_quote("some.domain.name") == "some.domain.name"
    assert (
        odbc_attr_val_quote("ODBC Driver 17 for SQL Server")
        == "{ODBC Driver 17 for SQL Server}"
    )


def test_odbc_attr_val_quote_raises() -> None:
    """Test proper exception raising of `odbc_attr_val_quote`."""
    with pytest.raises(ValueError):
        odbc_attr_val_quote("$}")


@pytest.mark.parametrize(
    ["msi_resource_arg", "access_token_value"],
    [
        ("https://some.resource.net", "some_resource_token_value"),
        (None, "general_resource_token_value"),
    ],
)
def test_get_msi_authentication_access_token(
    msi_resource_arg: typing.Optional[str], access_token_value: str, mocker
) -> None:
    # Mock & patch the `MSIAuthentication` class
    msi_auth_cls_mock: typing.Union[
        typing.Type[MSIAuthentication], Mock
    ] = mocker.patch(
        ".".join(
            (db_connect_utils.__name__, db_connect_utils.MSIAuthentication.__name__)
        ),
        autospec=True,
    )
    # And prepare the returned instance that the `token` attr has some
    # magic value
    msi_auth_inst_mock: typing.Union[
        MSIAuthentication, Mock
    ] = msi_auth_cls_mock.return_value
    msi_auth_inst_mock.token = {"access_token": access_token_value}
    # Call the function under test
    if msi_resource_arg is None:
        retval = get_msi_authentication_access_token()
    else:
        retval = get_msi_authentication_access_token(msi_resource_arg)
    # Check the returned value
    assert retval == access_token_value
    # Check the `MSIAuthentication` has been called correctly
    if msi_resource_arg is None:
        msi_auth_cls_mock.assert_called_once_with()
    else:
        msi_auth_cls_mock.assert_called_once_with(resource=msi_resource_arg)
