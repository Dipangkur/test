import typing
from functools import partial
from urllib.parse import quote_plus

import pyodbc
import pytest
from sqlalchemy.engine.url import URL

from scenario_calculator import sql_alch_create_engine_args
from scenario_calculator.db_connect_utils import odbc_attr_val_quote, str2mswin_bstr
from scenario_calculator.sql_alch_create_engine_args import (
    SqlAlchCreateEngineArgs,
    UnsupportedUrlSchemeError,
)

sql_driver_name = "ODBC Driver 17 for SQL Server"
extra_param1 = "foo bar bletch"


def test_sacea_extract_and_convert_url_pseudo_params() -> None:
    input_str = (
        "mssql+pyodbc://some_username:some_passwd@some_host:1234/dbname"
        "?driver=ODBC+Driver+17+for+SQL+Server"
        "&param1=foo+bar+bletch"
        "&SQL_COPT_SS_ACCESS_TOKEN=abcd"
        "&authentication=Foo"
    )
    expected_new_url = URL(
        "mssql+pyodbc",
        username="some_username",
        password="some_passwd",
        host="some_host",
        port=1234,
        database="dbname",
        query=dict(authentication="Foo", driver=sql_driver_name, param1=extra_param1,),
    )
    expected_connect_args = {
        "attrs_before": {1256: b"\x08\x00\x00\x00a\x00b\x00c\x00d\x00"}
    }
    sacea = SqlAlchCreateEngineArgs(input_str)
    sacea.extract_and_convert_url_pseudo_params()
    _assert_url_equal(sacea.url, expected_new_url)
    assert sacea.kwargs == {"connect_args": expected_connect_args}


def test_extract_and_convert_url_pseudo_params_type_error() -> None:
    some_sql_alch_conn = (
        "sqlite:///dbname"
        + "?SQL_COPT_SS_ACCESS_TOKEN=foo&SQL_COPT_SS_ACCESS_TOKEN=bar"
    )
    sacea = SqlAlchCreateEngineArgs(some_sql_alch_conn)
    with pytest.raises(TypeError) as type_error:
        sacea.extract_and_convert_url_pseudo_params()
    assert "Unexpected multiple values for key" in str(type_error.value)


def test_extract_and_convert_url_pseudo_params_value_error() -> None:
    some_sql_alch_conn = "sqlite:///dbname" + "?SQL_COPT_SS_ACCESS_TOKEN=foo"
    create_kwargs = {"connect_args": {"attrs_before": {1256: bytes(range(16))}}}
    sacea = SqlAlchCreateEngineArgs(some_sql_alch_conn, **create_kwargs)
    with pytest.raises(ValueError) as value_error:
        sacea.extract_and_convert_url_pseudo_params()
    error_str = str(value_error.value)
    assert error_str.startswith("Value for ")
    assert error_str.endswith(" for `create_engine` call")


@pytest.mark.parametrize(
    ["overrule_attrs", "expected_odbc_or_exc", "expected_url"],
    [
        # Check if all attrs are converted
        (
            {},
            (
                "UID={username_attrval}"
                ";PWD={password_attrval}"
                ";SERVER={host_attrval}"
                ";PORT={port_attrval}"
                ";DATABASE={database_attrval}"
                ";DRIVER={driver_spec_value}"
                ";Authentication={authentication_spec_value}"
            ),
            URL("mssql+pyodbc", query={"some_param": extra_param1}),
        ),
        # Check when not all attrs are converted
        (
            {"password_attrval": "", "uid_pwd_colon": ""},
            (
                "UID={username_attrval}"
                ";SERVER={host_attrval}"
                ";PORT={port_attrval}"
                ";DATABASE={database_attrval}"
                ";DRIVER={driver_spec_value}"
                ";Authentication={authentication_spec_value}"
            ),
            URL("mssql+pyodbc", query={"some_param": extra_param1}),
        ),
        # Check that ValueError is raised when "odbc_connect" already present
        (
            {
                "extra_query_param_name": "odbc_connect",
                "extra_query_param_value": "some_value",
            },
            ValueError,
            None,
        ),
        # Check nothing is done when no "pyodbc"
        (
            {"drivername": "sqlite", "driver_spec_value": "some driver spec"},
            None,
            URL(
                "sqlite",
                username="some_user",
                password="some_password",
                host="some_host",
                port=1234,
                database="some_dbname",
                query={
                    "some_param": extra_param1,
                    "driver": "some driver spec",
                    "authentication": "Foo",
                },
            ),
        ),
    ],
)
def test_convert_url_attrs_into_odbc_attrs(
    overrule_attrs: typing.Dict[str, typing.Any],
    expected_odbc_or_exc: typing.Optional[typing.Union[str, Exception]],
    expected_url: typing.Optional[URL],
) -> None:
    all_attrs = dict(
        drivername="mssql+pyodbc",
        username_attrval="some_user",
        uid_pwd_colon=":",
        password_attrval="some_password",
        host_attrval="some_host",
        port_attrval=1234,
        database_attrval="some_dbname",
        driver_spec_value=sql_driver_name,
        extra_query_param_name="some_param",
        extra_query_param_value=extra_param1,
        authentication_spec_value="Foo",
    )
    all_attrs.update(overrule_attrs)
    sql_alch_conn = (
        "{drivername}"
        "://{username_attrval}{uid_pwd_colon}{password_attrval}"
        "@{host_attrval}:{port_attrval}"
        "/{database_attrval}"
        "?driver={driver_spec_value}"
        "&{extra_query_param_name}={extra_query_param_value}"
        "&authentication={authentication_spec_value}"
    ).format_map(
        {
            key: (
                quote_plus(str(val))
                if key.endswith("_value") or key.endswith("_attrval")
                else val
            )
            for key, val in all_attrs.items()
        }
    )
    sacea = SqlAlchCreateEngineArgs(sql_alch_conn)
    if isinstance(expected_odbc_or_exc, type) and issubclass(
        expected_odbc_or_exc, Exception
    ):
        with pytest.raises(expected_odbc_or_exc):
            sacea.convert_url_attrs_into_odbc_attrs()
        return
    if isinstance(expected_odbc_or_exc, str):
        odbc_attr = expected_odbc_or_exc.format_map(
            {
                attr_name: odbc_attr_val_quote(str(attr_val))
                for attr_name, attr_val in all_attrs.items()
            }
        )
        expected_url.query["odbc_connect"] = odbc_attr
    sacea.convert_url_attrs_into_odbc_attrs()
    _assert_url_equal(sacea.url, expected_url)


def _assert_url_equal(result: URL, expected: URL) -> None:
    """Helper routine that makes it easier to find any difference."""
    if result == expected:
        return
    for attr_name in (
        "drivername",
        "username",
        "password",
        "host",
        "port",
        "database",
        "query",
    ):
        assert getattr(result, attr_name) == getattr(expected, attr_name)


def test_maybe_convert_to_creator_arg() -> None:
    """Test whether the conversion to driver call is correctly done."""
    odbc_connect_val = (
        "SERVER=some_host;"
        "PORT=1234;"
        "DATABASE=dbname;"
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "Authentication=Foo"
    )
    param1_val = extra_param1
    sql_alch_conn = "".join(
        (
            "mssql+pyodbc:///some_db_ignored",
            "?odbc_connect=",
            quote_plus(odbc_connect_val),
            "&param1=",
            quote_plus(param1_val),
        )
    )
    connect_args = {"attrs_before": {1234: "some_token"}}
    create_kwargs: typing.Dict[str, typing.Any] = {
        "connect_args": connect_args,
        "echo": "debug",
    }
    sacea = SqlAlchCreateEngineArgs(sql_alch_conn, **create_kwargs)
    sacea.maybe_convert_to_creator_arg()
    # Check whether "+pyodbc" has been removed
    assert sacea.url.drivername == "mssql"
    # Check whether "odbc_connect" has been removed
    assert sacea.url.query == {"param1": param1_val}
    # Check whether all other attributes remain "unset"
    assert sacea.url.database == "some_db_ignored"
    for sql_alch_url_attrname in ("username", "password", "host", "port"):
        assert getattr(sacea.url, sql_alch_url_attrname) is None
    # Check whether "connect_args" is replaced by "creator"
    assert sacea.kwargs.keys() == {"creator", "echo"}
    assert sacea.kwargs["echo"] == "debug"
    partial_obj: partial = sacea.kwargs["creator"]
    assert partial_obj.func == pyodbc.connect
    assert partial_obj.args == (odbc_connect_val,)
    assert partial_obj.keywords == connect_args


def test_sql_alch_create_engine_args(mocker) -> None:
    """A higher level test combining the tests from above.

    Also to create better maintainability/understandability of the
    code under test.
    """
    # Specify all the parts in an SqlAlchemy connection string separately,
    # so that input and expected outcome can be constructed from the same
    # source
    all_attrs = dict(
        sql_dialect="mssql",
        driver_name="pyodbc",
        username_attrval="some_user",
        password_attrval="some_password",
        host_attrval="some_host",
        port_attrval=1234,
        database_attrval="some_dbname",
        driver_spec_value=sql_driver_name,
        extra_query_param_name="some_param",
        extra_query_param_value=extra_param1,
        db_access_token_value="some db-access token value",
        authentication_spec_value="Foo",
    )

    # Construct the input SqlAlchemy connection string template out
    # of all the specified parts in `all_attrs`...
    # The query parameter values need to be '+'-quoted, though
    # Please note that this tests performs a illogical combination of
    # features (username/password, together with SQL_COPT_SS_ACCESS_TOKEN=...
    # together with authentication=...), but that's fine for testing.
    conn_str = (
        "{sql_dialect}+{driver_name}"
        "://{username_attrval}:{password_attrval}"
        "@{host_attrval}:{port_attrval}"
        "/{database_attrval}"
        "?driver={driver_spec_value}"
        "&{extra_query_param_name}={extra_query_param_value}"
        "&SQL_COPT_SS_ACCESS_TOKEN={db_access_token_value}"
        "&authentication={authentication_spec_value}"
    ).format_map(
        {
            key: (quote_plus(val) if key.endswith("_value") else val)
            for key, val in all_attrs.items()
        }
    )

    # Now use the class under test...
    create_engine_mock = mocker.patch(
        ".".join(
            (
                sql_alch_create_engine_args.__name__,
                sql_alch_create_engine_args.create_engine.__name__,
            )
        ),
        autospec=True,
    )
    SqlAlchCreateEngineArgs(conn_str).create_engine()
    create_engine_mock.assert_called_once()
    (url, *_), kwargs = create_engine_mock.call_args
    # Check all the attributes of the SqlAlchemy URL
    #   check whether the "+pyodbc" has been removed
    assert url.drivername == all_attrs["sql_dialect"]
    # Check that only "unknown" query parameters remain and
    # that all other attributes have been removed (i.e.
    # moved to the DbApi connection attributes)
    assert url.username is None
    assert url.password is None
    assert url.host is None
    assert url.port is None
    assert url.database is None
    assert url.query == {
        all_attrs["extra_query_param_name"]: all_attrs["extra_query_param_value"]
    }

    # We expect only the "creator" keyword_argument
    assert kwargs.keys() == {"creator"}
    creator_kw_val = kwargs["creator"]
    # ... and that should be a `partial` instance
    assert isinstance(creator_kw_val, partial)
    expected_connect_arg = (
        "UID={username_attrval};"
        "PWD={password_attrval};"
        "SERVER={host_attrval};"
        "PORT={port_attrval!s};"
        "DATABASE={database_attrval};"
        "DRIVER={{{driver_spec_value}}};"
        "Authentication={authentication_spec_value}"
    ).format_map(all_attrs)
    expected_token_bytes = str2mswin_bstr(all_attrs["db_access_token_value"])
    expected_connect_kwargs = {"attrs_before": {1256: expected_token_bytes}}
    # In the partial instance, check the function to call...
    assert creator_kw_val.func == pyodbc.connect
    # with positional arguments...
    assert creator_kw_val.args == (expected_connect_arg,)
    # with keyword arguments...
    assert creator_kw_val.keywords == expected_connect_kwargs


def test_sql_alch_create_engine_args_raises() -> None:
    """Test whether non-existing database scheme is signalled."""
    with pytest.raises(UnsupportedUrlSchemeError):
        SqlAlchCreateEngineArgs("no_real_scheme:///foo/bar")
