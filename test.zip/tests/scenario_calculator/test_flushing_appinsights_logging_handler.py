import logging
from logging import LogRecord

from applicationinsights.logging import LoggingHandler

from scenario_calculator.flushing_appinsights_logging_handler import (
    FlushingAppinsightsLoggingHandler,
)


def test_falh_emit(mocker):

    m_appinsights_logging_handler_init = mocker.patch.object(
        LoggingHandler, LoggingHandler.__init__.__name__, return_value=None
    )

    m_appinsights_logging_handler_emit = mocker.patch.object(
        LoggingHandler, LoggingHandler.emit.__name__, return_value=None
    )
    m_appinsights_logging_handler_flush = mocker.patch.object(
        LoggingHandler, LoggingHandler.flush.__name__, return_value=None
    )
    log_record = LogRecord(
        "some.module",
        logging.WARNING,
        "/some/pathname",
        42,
        "some %s message",
        ("log,"),
        None,
    )
    falh = FlushingAppinsightsLoggingHandler("some_instrumentation_key")
    m_appinsights_logging_handler_init.assert_called_once_with(
        "some_instrumentation_key"
    )
    falh.emit(log_record)
    m_appinsights_logging_handler_emit.assert_called_once_with(log_record)
    m_appinsights_logging_handler_flush.assert_called_once_with()
