"""Test the EventLogger.

TODO [JHB]: Cloned from MSR.ScenarioCreator.Py project.
 PBI https://raboweb.visualstudio.com/CAS/_workitems/edit/469217
"""
import json
import logging

import pytest

from scenario_calculator.event_logger import EventLogger
from scenario_calculator.events import (
    CALCULATE_SCENARIO_EVENT,
    RETRIEVE_INPUT_DATA_EVENT,
)


class TestEventLogger:
    def test_successful_read(self, mock_db):
        mock_db()

        conn_str = "sqlite://"

        event_logger = EventLogger(conn_str, event_id=-1)

        with event_logger.log_event(CALCULATE_SCENARIO_EVENT) as item:
            assert (
                event_logger.event_model.call_args[1]["EventType"]
                == "CalculateScenario"
            )  # noqa: E501

        assert item.Status == "Success"

    def test_when_user_code_fails(self, mock_db):
        mock_db()

        conn_str = "sqlite://"
        event_logger = EventLogger(conn_str, event_id=-1)

        with pytest.raises(TypeError), event_logger.log_event(
            RETRIEVE_INPUT_DATA_EVENT
        ) as item:
            raise TypeError("Some TypeError description")

        assert (
            event_logger.event_model.call_args[1]["EventType"] == "RetrieveInputData"
        )  # noqa: E501

        assert item.Status == "Failure"

        stack_bt_info = json.loads(item.EventData)
        assert isinstance(stack_bt_info, dict)
        assert stack_bt_info.keys() == {
            "formatted_exception_only",
            "formatted_exception_info",
        }
        assert (
            "TypeError: Some TypeError description"
            in stack_bt_info["formatted_exception_only"][0]
        )
        assert (
            "Traceback (most recent call last):"
            in stack_bt_info["formatted_exception_info"][0]
        )

    def test_memory_db_failing_context(self):
        """Assert the event logger works when no connection string is given"""
        event_logger = EventLogger()
        with pytest.raises(TypeError), event_logger.log_event(
            RETRIEVE_INPUT_DATA_EVENT
        ):
            raise TypeError("Some TypeError description")

    def test_2nd_event_logger(self):
        """Check for a second instance of the in-memory event logger."""
        EventLogger()

    def test_memory_dump(self, caplog):
        event_logger = EventLogger()
        with pytest.raises(TypeError), event_logger.log_event(
            RETRIEVE_INPUT_DATA_EVENT
        ) as log_event:
            raise TypeError("Some other TypeError description")
        caplog.clear()
        with caplog.at_level(logging.DEBUG):
            event_logger.dump_to_log(logging.DEBUG)
        assert len(caplog.records) == 2
        assert caplog.records[0].msg == "A dump of the event log follows:"
        assert caplog.records[1].args[0] is log_event
