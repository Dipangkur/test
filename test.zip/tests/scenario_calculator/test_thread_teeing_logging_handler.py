import logging
import threading
from itertools import zip_longest
from typing import ContextManager, List, Tuple

import pytest

from scenario_calculator.thread_teeing_logging_handler import ThreadTeeingLoggingHandler

_MODULE_NAME = __name__
_logger = logging.getLogger(__name__)
_TMP_ROOT_LEVEL = logging.DEBUG


@pytest.fixture()
def thread_teeing_logging_handler_installed() -> ContextManager[
    ThreadTeeingLoggingHandler
]:
    """PyTest fixture that temporarily installs a special logging handler.

    :yield: the installed ThreadTeeingLoggingHandler
    """
    _logger.debug("Creating ThreadTeeingLoggingHandler")
    thread_teeing_logging_handler = ThreadTeeingLoggingHandler()
    root_logger = logging.getLogger()
    old_level = root_logger.level
    _logger.debug(
        "Adding it to the root logger while changing its level from %s to %s",
        logging.getLevelName(old_level),
        logging.getLevelName(_TMP_ROOT_LEVEL),
    )
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(thread_teeing_logging_handler)
    yield thread_teeing_logging_handler  # NOSONAR
    _logger.debug(
        "Resetting root logger to level %s and removing ThreadTeeingLoggingHandler"
        " instance from it",
        logging.getLevelName(old_level),
    )
    root_logger.setLevel(old_level)
    root_logger.removeHandler(thread_teeing_logging_handler)


_NBROF_EXTRA_THREADS = 2
_DISCRIMINATING_KEYWORDS = ("First", "Second")


def test_teeing_logging_handler(thread_teeing_logging_handler_installed) -> None:
    """Test whether thread specific logs are tee'd into an additional output.

    :param thread_teeing_logging_handler_installed: the logging handler under test
    """
    barrier = threading.Barrier(_NBROF_EXTRA_THREADS)
    threads_info: List[Tuple[threading.Thread, List[str]]] = []
    # Create the threads and start the function in it...
    for _ in range(_NBROF_EXTRA_THREADS):
        # Create a new log_list for this thread
        log_list: List[str] = []
        thread = threading.Thread(
            target=_some_logging_thread_function,
            args=(thread_teeing_logging_handler_installed, log_list, barrier),
        )
        _logger.debug("Created thread %r", thread.name)
        thread.start()
        _logger.debug("Started thread %r", thread.name)
        threads_info.append((thread, log_list))
    # Wait for the threads to finish...
    for thread, _ in threads_info:
        _logger.debug("Joining thread %r", thread.name)
        thread.join()
    _logger.debug("All threads joined")
    # Now do the actual testing
    for thread, log_list in threads_info:
        assert len(log_list) == 2, "expecting 2 logs per thread"
        for log_str, discr_keyword in zip_longest(log_list, _DISCRIMINATING_KEYWORDS):
            _logger.debug("Thread %r: log_str: %s", thread.name, log_str)
            assert (
                f"{discr_keyword} captured log (INFO) from thread {thread.name!r}"
                in log_str
            )


def _some_logging_thread_function(
    thread_teeing_logging_handler: ThreadTeeingLoggingHandler,
    logs_list: List[str],
    joint_barrier: threading.Barrier,
) -> None:
    """A simple function that issues some logs, with synchronization in between.

    :param thread_teeing_logging_handler: the logging handler under test
    :param logs_list: list to collect the captured log lines in
    :param joint_barrier: the barrier to pass, for synchronization purposes
    """
    thread_name = threading.current_thread().name
    thread_id = threading.get_ident()
    _logger.info(
        "First not-captured log (INFO) from thread %r, id %d", thread_name, thread_id
    )
    # Capture on level INFO and higher
    with thread_teeing_logging_handler.capture_log_lines_for_current_thread(
        logs_list.append, logging.INFO
    ):
        _logger.info(
            "First captured log (INFO) from thread %r, id %d", thread_name, thread_id
        )
        _logger.debug("Thread %d waiting for next step", thread_id)
        # Make sure the logs are intermixed with each other
        joint_barrier.wait()
        _logger.info(
            "Second captured log (INFO) from thread %r, id %d", thread_name, thread_id
        )
    # Now capture on level INFO and higher
    with thread_teeing_logging_handler.capture_log_lines_for_current_thread(
        logs_list.append, logging.WARNING
    ):
        _logger.info(
            "Second not-captured log (INFO) from thread (level-filtering) %r, id %d",
            thread_name,
            thread_id,
        )

    _logger.info(
        "Third not-captured log (INFO) from thread %r, id %d", thread_name, thread_id
    )
