# -*- coding: utf-8 -*-
import pandas as pd
from pandas.testing import assert_frame_equal
from scenario_calculator.io.base_reader import read_static_data
from scenario_calculator.other_country import (
    apply_conversion_factor,
    apply_currency_conversion,
    truncate_dynamic_df,
    add_missing_rxeu_values,
)
from tests.test_settings import TestSettings


class TestOtherCountry:
    """
    This class is made out of several tests for testing the other country functionality.
    """

    def test_add_missing_rxeu_values(
        self, expected_dynamic_without_elrx_df, dynamic_with_elrx_df
    ):
        """
        Test other_country add_idrxeu_usrxeu function comparing with the expected
        data frame
        """

        converted_dynamic_df = add_missing_rxeu_values(dynamic_with_elrx_df)

        assert_frame_equal(converted_dynamic_df, expected_dynamic_without_elrx_df)

    def test_truncate_dynamic_df(
        self, expected_truncated_dynamic_df, dynamic_with_rxeu_df
    ):
        """
        Test other_country truncate_extension_df function comparing with the expected
        data frame
        """
        static_data = read_static_data(
            TestSettings.TEST_STATIC_DATA_DIR, TestSettings.TEST_FILE_MAPPING
        )

        truncated_dynamic_df = truncate_dynamic_df(
            dynamic_with_rxeu_df, static_data["other_country_start_year"]
        )

        assert_frame_equal(truncated_dynamic_df, expected_truncated_dynamic_df)

    def test_apply_conversion_factor(
        self, expected_conversion_applied_dynamic_df, expected_truncated_dynamic_df
    ):
        """
        Test other_country apply_conversion_factor function comparing with the expected
        data frame
        """

        static_data = read_static_data(
            TestSettings.TEST_STATIC_DATA_DIR, TestSettings.TEST_FILE_MAPPING
        )

        conversion_applied_dynamic_df = apply_conversion_factor(
            expected_truncated_dynamic_df, static_data["extension"]
        )

        assert_frame_equal(
            conversion_applied_dynamic_df, expected_conversion_applied_dynamic_df
        )

    def test_apply_currency_conversion(
        self,
        dynamic_with_rxeu_df: pd.DataFrame,
        static_test_data_dict,
        expected_euro_converted_dynamic_df: pd.DataFrame,
    ):
        """
        Test other_country apply_currency_conversion function comparing with the
        expected data frame
        """

        assert_frame_equal(
            apply_currency_conversion(
                dynamic_with_rxeu_df,
                static_test_data_dict["other_country_price_variables"],
                static_test_data_dict["other_country_euro_countries"],
            ),
            expected_euro_converted_dynamic_df,
        )
