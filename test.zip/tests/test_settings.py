"""Settings for Test(s)"""
from scenario_calculator.settings import Settings
from tests.fixture import TEST_DATA_DIR


class TestSettings:
    DATA_FOR_TEST = TEST_DATA_DIR
    TEST_STATIC_DATA_DIR = DATA_FOR_TEST / "static"
    TEST_DYNAMIC_DATA_DIR = DATA_FOR_TEST / "dynamic"

    # A dict. we use to give the right name for each static data csv file for
    # test purposes
    TEST_FILE_MAPPING = Settings.STANDARD_FILE_MAPPING.copy()
    TEST_FILE_MAPPING["agriland_org"] = "static_agriland_params_oc.csv"

    TEST_FILE_MAPPING_OTHER_COUNTRY = TEST_FILE_MAPPING.copy()
    TEST_FILE_MAPPING_OTHER_COUNTRY[
        "extension"
    ] = "static_arima_params_for_other_country.csv"
