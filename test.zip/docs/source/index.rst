.. MSR.ScenarioCalculator.Py documentation master file, created by
   sphinx-quickstart on Wed Sep  4 10:51:29 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MSR.ScenarioCalculator.Py's documentation!
=====================================================
Overview
^^^^^^^^

 MSR.ScenarioCalculator.Py is mainly based on the following packages:

* packages


Content
^^^^^^^

.. toctree::
   :maxdepth: 3


   _modules/modules

Indices
^^^^^^^^^^^^^^^^^^

* :ref:`modindex`
* :ref:`genindex`

Readme
^^^^^^^^^^^^^^^^^^
.. mdinclude:: ../../README.md